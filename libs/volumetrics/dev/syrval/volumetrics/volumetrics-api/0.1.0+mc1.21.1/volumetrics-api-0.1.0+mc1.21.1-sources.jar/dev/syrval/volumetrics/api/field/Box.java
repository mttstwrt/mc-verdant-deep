package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import net.minecraft.world.phys.Vec3;

/**
 * A box along the world's axes, between two corners in blocks, as the signed distance to its surface:
 * {@code {"type": "volumetrics:box", "min": {"x": -8, "y": 60, "z": -8}, "max": {"x": 8, "y": 72, "z": 8}}}.
 */
public record Box(Vec3 min, Vec3 max) implements Field {
    public static final MapCodec<Box> MAP_CODEC = RecordCodecBuilder.<Box>mapCodec(instance -> instance.group(
            VolumetricsCodecs.XYZ.fieldOf("min").forGetter(Box::min),
            VolumetricsCodecs.XYZ.fieldOf("max").forGetter(Box::max)
    ).apply(instance, Box::of)).validate(box -> box == null
            ? DataResult.error(() -> "box.max must be above box.min on every axis") : DataResult.success(box));

    public Box {
        Check.position(min, "box.min");
        Check.position(max, "box.max");
        if (!(max.x > min.x && max.y > min.y && max.z > min.z)) {
            throw new IllegalArgumentException("box.max must be above box.min on every axis, got " + min + " and " + max);
        }
    }

    /** For the codec: null for corners the wrong way round, which it reports as a data error. */
    private static Box of(Vec3 min, Vec3 max) {
        return max.x > min.x && max.y > min.y && max.z > min.z ? new Box(min, max) : null;
    }

    @Override
    public FieldType type() {
        return FieldTypes.BOX;
    }

    @Override
    public FieldBounds bounds() {
        return new FieldBounds(min.x, min.y, min.z, max.x, max.y, max.z);
    }

    @Override
    public float minimum() {
        return (float) -Math.min(Math.min(max.x - min.x, max.y - min.y), max.z - min.z) / 2;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
