package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * A profile in a straight line: {@code start} at {@code from}, {@code end} at {@code to}, held at its ends beyond
 * them. The input is the altitude unless another field is given.
 * {@code {"type": "volumetrics:linear", "from": 62, "to": 90, "start": 0.5, "end": 0}}.
 */
public record Linear(Field input, float from, float to, float start, float end) implements Field {
    public static final MapCodec<Linear> MAP_CODEC = RecordCodecBuilder.<Linear>mapCodec(instance -> instance.group(
            Field.CODEC.optionalFieldOf("input", Altitude.INSTANCE).forGetter(Linear::input),
            Check.number("linear.from").fieldOf("from").forGetter(Linear::from),
            Check.number("linear.to").fieldOf("to").forGetter(Linear::to),
            Check.number("linear.start").fieldOf("start").forGetter(Linear::start),
            Check.number("linear.end").fieldOf("end").forGetter(Linear::end)
    ).apply(instance, (input, from, to, start, end) -> from != to ? new Linear(input, from, to, start, end) : null))
            .validate(linear -> linear == null ? DataResult.error(() -> "linear.from and linear.to must differ")
                    : DataResult.success(linear));

    public Linear {
        Objects.requireNonNull(input, "linear.input");
        Check.number(from, "linear.from");
        Check.number(to, "linear.to");
        Check.number(start, "linear.start");
        Check.number(end, "linear.end");
        if (from == to) {
            throw new IllegalArgumentException("linear.from and linear.to must differ, got " + from);
        }
    }

    /** The value at the input {@code x}. */
    public float at(float x) {
        float t = Math.clamp((x - from) / (to - from), 0f, 1f);
        return start + (end - start) * t;
    }

    @Override
    public FieldType type() {
        return FieldTypes.LINEAR;
    }

    @Override
    public FieldBounds bounds() {
        return maximum() > 0 ? FieldBounds.EVERYWHERE : FieldBounds.NOWHERE;
    }

    @Override
    public float minimum() {
        return Math.min(start, end);
    }

    @Override
    public float maximum() {
        return Math.max(start, end);
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
