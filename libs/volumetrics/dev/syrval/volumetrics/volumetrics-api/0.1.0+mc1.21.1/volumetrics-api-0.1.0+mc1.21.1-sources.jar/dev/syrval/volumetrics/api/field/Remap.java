package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * The input moved and stretched in a straight line, so {@code from_min} becomes {@code to_min} and {@code from_max}
 * becomes {@code to_max}; not held at the ends (a {@link Clamp} does that).
 * {@code {"type": "volumetrics:remap", "input": {...}, "from_min": 0, "from_max": 1, "to_min": 0.2, "to_max": 0.6}}.
 */
public record Remap(Field input, float fromMin, float fromMax, float toMin, float toMax) implements Field {
    public static final MapCodec<Remap> MAP_CODEC = RecordCodecBuilder.<Remap>mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("input").forGetter(Remap::input),
            Check.number("remap.from_min").fieldOf("from_min").forGetter(Remap::fromMin),
            Check.number("remap.from_max").fieldOf("from_max").forGetter(Remap::fromMax),
            Check.number("remap.to_min").fieldOf("to_min").forGetter(Remap::toMin),
            Check.number("remap.to_max").fieldOf("to_max").forGetter(Remap::toMax)
    ).apply(instance, (input, fromMin, fromMax, toMin, toMax) -> fromMin != fromMax
            ? new Remap(input, fromMin, fromMax, toMin, toMax) : null)).validate(remap -> remap == null
            ? DataResult.error(() -> "remap.from_min and remap.from_max must differ") : DataResult.success(remap));

    public Remap {
        Objects.requireNonNull(input, "remap.input");
        Check.number(fromMin, "remap.from_min");
        Check.number(fromMax, "remap.from_max");
        Check.number(toMin, "remap.to_min");
        Check.number(toMax, "remap.to_max");
        if (fromMin == fromMax) {
            throw new IllegalArgumentException("remap.from_min and remap.from_max must differ, got " + fromMin);
        }
    }

    /** What an input of 1 more adds. */
    public float slope() {
        return (toMax - toMin) / (fromMax - fromMin);
    }

    /** The value at an input of 0. */
    public float offset() {
        return toMin - fromMin * slope();
    }

    @Override
    public FieldType type() {
        return FieldTypes.REMAP;
    }

    @Override
    public FieldBounds bounds() {
        return slope() >= 0f && offset() <= 0f && !input.distance() ? input.bounds() : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return Math.min(map(input.minimum()), map(input.maximum()));
    }

    @Override
    public float maximum() {
        return Math.max(map(input.minimum()), map(input.maximum()));
    }

    private float map(float x) {
        float slope = slope();
        if (slope == 0f || Float.isNaN(x)) {
            return offset();
        }
        return x * slope + offset();
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
