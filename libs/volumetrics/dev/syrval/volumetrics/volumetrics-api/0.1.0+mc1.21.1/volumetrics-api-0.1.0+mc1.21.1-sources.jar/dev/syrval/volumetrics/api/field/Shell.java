package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * The surface of a shape as gas: 1 on it, thinning to 0 at {@code width} blocks from it on either side. A bubble, a
 * ring of mist round a pool. {@code {"type": "volumetrics:shell", "shape": {...}, "width": 2}}.
 */
public record Shell(Field shape, float width) implements Field {
    public static final MapCodec<Shell> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("shape").forGetter(Shell::shape),
            Check.positive("shell.width").fieldOf("width").forGetter(Shell::width)
    ).apply(instance, Shell::new));

    public Shell {
        Objects.requireNonNull(shape, "shell.shape");
        Check.positive(width, "shell.width");
    }

    @Override
    public FieldType type() {
        return FieldTypes.SHELL;
    }

    @Override
    public FieldBounds bounds() {
        return shape.distance() ? shape.bounds().expand(width) : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }

    @Override
    public List<Field> children() {
        return List.of(shape);
    }
}
