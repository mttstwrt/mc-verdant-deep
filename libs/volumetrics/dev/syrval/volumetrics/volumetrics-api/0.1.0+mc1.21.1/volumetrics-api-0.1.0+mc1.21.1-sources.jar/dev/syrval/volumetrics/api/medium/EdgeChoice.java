package dev.syrval.volumetrics.api.medium;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceKey;

/**
 * The edge a medium is drawn with: a preset of the {@code volumetrics:edge} registry, fields of its own laid over one,
 * or fields alone, over {@link Edge#NONE}. Written {@code "edge": "volumetrics:puffy"}, or
 * {@code "edge": {"preset": "volumetrics:puffy", "turbulence": 0}}, or {@code "edge": {"erosion": 0.4}}.
 *
 * <p>The preset is named, not copied: the engine looks it up when it compiles the medium, so a datapack that changes a
 * preset changes every medium that names it. A preset that is not there leaves {@link Edge#NONE} under the fields
 * (logged once).
 *
 * @param preset    the preset the fields are laid over; empty for {@link Edge#NONE}
 * @param overrides fields in place of the preset's
 */
public record EdgeChoice(Optional<ResourceKey<Edge>> preset, Edge.Overrides overrides) {
    /** Nothing shaped. */
    public static final EdgeChoice NONE = new EdgeChoice(Optional.empty(), Edge.Overrides.NONE);

    private static final Codec<ResourceKey<Edge>> PRESET_CODEC = ResourceKey.codec(VolumetricsRegistries.EDGE);

    private static final Codec<EdgeChoice> OBJECT_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            PRESET_CODEC.optionalFieldOf("preset").forGetter(EdgeChoice::preset),
            Edge.Overrides.MAP_CODEC.forGetter(EdgeChoice::overrides)
    ).apply(instance, EdgeChoice::new));

    /** A preset's id alone, or an object; a preset without fields of its own is written as its id. */
    public static final Codec<EdgeChoice> CODEC = Codec.either(PRESET_CODEC, OBJECT_CODEC).xmap(
            either -> either.map(EdgeChoice::ofPreset, choice -> choice),
            choice -> choice.preset.isPresent() && choice.overrides.isEmpty()
                    ? Either.left(choice.preset.get()) : Either.right(choice));

    public EdgeChoice {
        Objects.requireNonNull(preset, "preset");
        Objects.requireNonNull(overrides, "overrides");
    }

    /** The preset as it is. */
    public static EdgeChoice ofPreset(ResourceKey<Edge> preset) {
        return new EdgeChoice(Optional.of(preset), Edge.Overrides.NONE);
    }

    /** An edge of its own, whatever any preset says. */
    public static EdgeChoice of(Edge edge) {
        return new EdgeChoice(Optional.empty(), Edge.Overrides.of(edge));
    }
}
