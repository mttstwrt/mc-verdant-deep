package dev.syrval.volumetrics.api.field;

/**
 * A box in world blocks, possibly unbounded on any side, that a field node states of itself: outside it the node
 * contributes nothing (see {@link Field#bounds}). Conservative: the node may be nothing in much of the box as well.
 * Engines cull by it, per ray or per froxel, and skip the parts of the simulation's windows it leaves out.
 */
public record FieldBounds(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
    /** No bounds: the node may be anything anywhere. */
    public static final FieldBounds EVERYWHERE = new FieldBounds(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY,
            Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
    /** Empty: the node is nothing anywhere. */
    public static final FieldBounds NOWHERE = new FieldBounds(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY,
            Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);

    public FieldBounds {
        if (Double.isNaN(minX) || Double.isNaN(minY) || Double.isNaN(minZ) || Double.isNaN(maxX) || Double.isNaN(maxY)
                || Double.isNaN(maxZ)) {
            throw new IllegalArgumentException("Field bounds must be numbers");
        }
    }

    /** Unbounded sideways, from {@code bottom} to {@code top}. */
    public static FieldBounds layer(double bottom, double top) {
        return new FieldBounds(Double.NEGATIVE_INFINITY, bottom, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, top,
                Double.POSITIVE_INFINITY);
    }

    public boolean isEmpty() {
        return !(minX <= maxX && minY <= maxY && minZ <= maxZ);
    }

    /** Whether every side is finite. */
    public boolean isFinite() {
        return Double.isFinite(minX) && Double.isFinite(minY) && Double.isFinite(minZ) && Double.isFinite(maxX)
                && Double.isFinite(maxY) && Double.isFinite(maxZ);
    }

    public FieldBounds intersect(FieldBounds other) {
        FieldBounds both = new FieldBounds(Math.max(minX, other.minX), Math.max(minY, other.minY), Math.max(minZ, other.minZ),
                Math.min(maxX, other.maxX), Math.min(maxY, other.maxY), Math.min(maxZ, other.maxZ));
        return both.isEmpty() ? NOWHERE : both;
    }

    public FieldBounds union(FieldBounds other) {
        if (isEmpty()) {
            return other;
        }
        if (other.isEmpty()) {
            return this;
        }
        return new FieldBounds(Math.min(minX, other.minX), Math.min(minY, other.minY), Math.min(minZ, other.minZ),
                Math.max(maxX, other.maxX), Math.max(maxY, other.maxY), Math.max(maxZ, other.maxZ));
    }

    /** Grown by {@code blocks} on every side. */
    public FieldBounds expand(double blocks) {
        if (isEmpty()) {
            return this;
        }
        return new FieldBounds(minX - blocks, minY - blocks, minZ - blocks, maxX + blocks, maxY + blocks, maxZ + blocks);
    }

    /** Moved by an offset in blocks. */
    public FieldBounds offset(double x, double y, double z) {
        if (isEmpty()) {
            return this;
        }
        return new FieldBounds(minX + x, minY + y, minZ + z, maxX + x, maxY + y, maxZ + z);
    }

    /** Whether a point in blocks is inside, sides included. */
    public boolean contains(double x, double y, double z) {
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    /** From a point to the nearest point of the box, in blocks: 0 inside, infinite for an empty box. */
    public double distanceTo(double x, double y, double z) {
        if (isEmpty()) {
            return Double.POSITIVE_INFINITY;
        }
        double dx = Math.max(0, Math.max(minX - x, x - maxX));
        double dy = Math.max(0, Math.max(minY - y, y - maxY));
        double dz = Math.max(0, Math.max(minZ - z, z - maxZ));
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
