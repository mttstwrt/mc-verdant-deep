package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

/** The bounds of an event's numbers, named as written, so data and a record built in Java fail alike. */
record Limits(String name, float min, float max) {
    Codec<Float> codec() {
        return Codec.FLOAT.validate(value -> within(value) ? DataResult.success(value) : DataResult.error(() -> message(value)));
    }

    float check(float value) {
        if (!within(value)) {
            throw new IllegalArgumentException(message(value));
        }
        return value;
    }

    private boolean within(float value) {
        return value >= min && value <= max;
    }

    private String message(float value) {
        return name + " must be from " + min + " to " + max + ", got " + value;
    }
}
