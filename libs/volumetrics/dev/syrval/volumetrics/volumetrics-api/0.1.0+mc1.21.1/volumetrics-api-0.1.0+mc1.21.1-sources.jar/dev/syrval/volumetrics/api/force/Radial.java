package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.field.Field;

/**
 * A push straight out of the attachment's point at {@code speed} blocks per second, or with a negative speed a pull
 * into it, slowing to nothing over the last {@code taper} blocks to the point: a geyser's breath, a sinkhole's draw.
 * {@code {"type": "volumetrics:radial", "speed": -2, "shape": {"type": "volumetrics:sphere", "radius": 8}}}.
 */
public record Radial(float speed, Field shape, float reach, float taper) implements ForceKind {
    private static final Limits SPEED = Limits.speed("radial.speed");
    private static final Limits TAPER = Limits.distance("radial.taper", 64f);

    public static final MapCodec<Radial> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            SPEED.codec().fieldOf("speed").forGetter(Radial::speed),
            Field.CODEC.fieldOf("shape").forGetter(Radial::shape),
            Region.reach("radial").optionalFieldOf("reach", 0f).forGetter(Radial::reach),
            TAPER.codec().optionalFieldOf("taper", 2f).forGetter(Radial::taper)
    ).apply(instance, Radial::new));

    public Radial {
        SPEED.check(speed);
        Region.shape(shape, "radial");
        Region.reach(reach, "radial");
        TAPER.check(taper);
    }

    @Override
    public ForceType type() {
        return ForceKinds.RADIAL;
    }
}
