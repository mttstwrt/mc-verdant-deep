package dev.syrval.volumetrics.api.condition;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;

/**
 * The library's built-in conditions (spec decision D6): generic reads of the game's own state, so a datapack names
 * them in a {@code volumetrics:condition} node or a source's {@code conditions} with no code. Each is 0 to 1; what it
 * means for a gas (fog with rain, mist at dawn) is the field's arithmetic: {@code mul}, {@code remap},
 * {@code smoothstep}. These ids cannot be registered by a mod.
 *
 * <ul>
 *   <li>{@code volumetrics:time_of_day}: the time on a 24-hour clock as a fraction of the day, 0 at midnight, 0.25 at
 *       sunrise (vanilla's day time 0), 0.5 at noon, 0.75 at sunset; the whole level alike. A dimension without a day
 *       cycle reads what the game gives it: its fixed time on 1.21.1 (the Nether's midnight, the End's noon), day time
 *       0 (sunrise) from 26.1 on, where such a dimension has no clock.</li>
 *   <li>{@code volumetrics:daylight}: the same as a smooth day curve, 0 at midnight, 0.5 at sunrise and sunset, 1 at
 *       noon ({@code (1 - cos(2π time_of_day)) / 2}); not the sky's brightness, which also follows the weather.</li>
 *   <li>{@code volumetrics:rain}: the level's rain, 0 to 1 as the game fades it in and out over a few seconds; the
 *       whole level alike, dry biomes too (multiply by a biome tag to leave deserts out).</li>
 *   <li>{@code volumetrics:thunder}: the level's thunder, the same way; never above the rain.</li>
 *   <li>{@code volumetrics:biome/<namespace>/<path>}: 1 where the biome at the column's surface (its top block) is in
 *       the biome tag {@code #<namespace>:<path>}, else 0; 0 beyond the loaded chunks. {@code
 *       volumetrics:biome/minecraft/is_ocean}, {@code volumetrics:biome/c/is_swamp}. A tag nobody defines is empty,
 *       so 0. {@link #biome} makes the id.</li>
 * </ul>
 */
public final class Conditions {
    public static final ResourceLocation TIME_OF_DAY = id("time_of_day");
    public static final ResourceLocation DAYLIGHT = id("daylight");
    public static final ResourceLocation RAIN = id("rain");
    public static final ResourceLocation THUNDER = id("thunder");
    /** What every biome tag condition's path starts with. */
    public static final String BIOME_PREFIX = "biome/";

    private Conditions() {}

    /** The condition that is 1 where the column's surface biome is in the tag. */
    public static ResourceLocation biome(TagKey<Biome> tag) {
        Objects.requireNonNull(tag, "tag");
        return id(BIOME_PREFIX + tag.location().getNamespace() + "/" + tag.location().getPath());
    }

    /** The biome tag a built-in biome condition reads; empty for any other id, or one with no tag after the prefix. */
    public static Optional<TagKey<Biome>> biomeTag(ResourceLocation condition) {
        if (!condition.getNamespace().equals("volumetrics") || !condition.getPath().startsWith(BIOME_PREFIX)) {
            return Optional.empty();
        }
        String rest = condition.getPath().substring(BIOME_PREFIX.length());
        int slash = rest.indexOf('/');
        if (slash <= 0 || slash == rest.length() - 1) {
            return Optional.empty();
        }
        ResourceLocation tag = ResourceLocation.tryBuild(rest.substring(0, slash), rest.substring(slash + 1));
        return tag == null ? Optional.empty() : Optional.of(TagKey.create(Registries.BIOME, tag));
    }

    /** Whether an id is a built-in condition's, valid or not: one a mod may not register. */
    public static boolean builtIn(ResourceLocation condition) {
        return condition.equals(TIME_OF_DAY) || condition.equals(DAYLIGHT) || condition.equals(RAIN)
                || condition.equals(THUNDER)
                || condition.getNamespace().equals("volumetrics") && condition.getPath().startsWith(BIOME_PREFIX);
    }

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("volumetrics", path);
    }
}
