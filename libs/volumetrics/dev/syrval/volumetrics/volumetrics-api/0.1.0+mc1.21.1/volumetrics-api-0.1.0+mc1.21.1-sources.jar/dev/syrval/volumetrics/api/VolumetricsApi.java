package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.spi.VolumetricsEngine;
import java.util.Objects;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * Where a mod reaches Volumetrics: {@link #owner} gives it the {@link Owner} that everything it adds hangs from, and
 * {@link #capabilities} says what this install supports.
 *
 * <p>The API jar is for compiling against and holds no engine. At run time these classes come inside the library's
 * jar, with the engine, which this finds once, on first use. A mod declares the library as a dependency (or keeps the
 * one class that calls this loaded only when the library is present) and never bundles the API: a newer API over an
 * older engine would fail on the first missing method, where a declared version range has the loader name the
 * version needed.
 *
 * <p>Any thread.
 */
public final class VolumetricsApi {
    private VolumetricsApi() {}

    /**
     * The owner for a mod: the same one on every call with the same id.
     *
     * @param modId the calling mod's id
     * @throws IllegalArgumentException if {@code modId} is not a valid namespace
     * @throws IllegalStateException    if no engine is installed
     */
    public static Owner owner(String modId) {
        Objects.requireNonNull(modId, "modId");
        if (!ResourceLocation.isValidNamespace(modId)) {
            throw new IllegalArgumentException("Not a valid mod id: '" + modId + "'");
        }
        return engine().owner(modId);
    }

    /** @throws IllegalStateException if no engine is installed */
    public static Capabilities capabilities() {
        return engine().capabilities();
    }

    private static VolumetricsEngine engine() {
        VolumetricsEngine engine = Lookup.ENGINE;
        if (engine == null) {
            throw new IllegalStateException("No Volumetrics engine: the Volumetrics mod is not installed, or its jar is "
                    + "damaged. The volumetrics-api jar is only for compiling against; install the mod and declare it as "
                    + "a dependency instead of bundling the API.", Lookup.FAILURE);
        }
        return engine;
    }

    /**
     * Looks the engine up the first time it is wanted, once: class initialisation runs once, and every thread sees
     * its result. A failure is kept rather than thrown here, where it would leave this class unusable with a less
     * telling error on every later call.
     *
     * <p>The lookup goes through the API's own class loader, not the caller's: at run time the engine is in the
     * same jar as these classes, so that loader sees it whichever mod is asking.
     */
    private static final class Lookup {
        static final @Nullable VolumetricsEngine ENGINE;
        static final @Nullable ServiceConfigurationError FAILURE;

        static {
            VolumetricsEngine engine = null;
            ServiceConfigurationError failure = null;
            try {
                engine = ServiceLoader.load(VolumetricsEngine.class, VolumetricsApi.class.getClassLoader())
                        .findFirst().orElse(null);
            } catch (ServiceConfigurationError e) {
                failure = e;
            }
            ENGINE = engine;
            FAILURE = failure;
        }
    }
}
