/**
 * Forces: what moves the air, and with it the gas. A {@link dev.syrval.volumetrics.api.force.Force} is one of the
 * kinds of {@link dev.syrval.volumetrics.api.force.ForceKinds}, with a filter of the media it moves;
 * {@link dev.syrval.volumetrics.api.force.ForcePlacement} is the entry of the {@code volumetrics:force} registry that
 * places one by a rule. Records only: immutable, side-neutral, any thread. The engine compiles a force when it is
 * added; nothing here is read while gas is simulated.
 */
package dev.syrval.volumetrics.api.force;
