package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * A loaded chunk as a {@link PlacementRule} reads it: its blocks and heights, and nothing it could change. The library
 * reuses one view, so it works only during the call it is given to, on the level's thread. Coordinates are the
 * world's, in blocks, and must be in this chunk.
 */
@Experimental
public interface ChunkView {
    /** The level the chunk is in, for what the rule knows of it (its dimension, its time). Not to be changed. */
    Level level();

    ChunkPos pos();

    /** The lowest block y of the chunk. */
    int minY();

    /** The highest block y of the chunk, inclusive. */
    int maxY();

    /**
     * The block there; air above {@link #maxY} and below {@link #minY}.
     *
     * @throws IllegalArgumentException if x or z is outside the chunk
     */
    BlockState blockState(int x, int y, int z);

    /**
     * The y of the top block of a column of the chunk by one of the chunk's heightmaps, one below {@link #minY} if
     * the column has none. A client has only the heightmaps its server sends; another is worked out when first asked.
     *
     * @throws IllegalArgumentException if x or z is outside the chunk
     */
    int height(Heightmap.Types type, int x, int z);

    /**
     * Visits the blocks that pass the rule's {@link PlacementRule#looksFor}, from the bottom up (by y, then z, then x),
     * reading only the sections whose palette may hold one; visits nothing for a rule that looks for nothing. Stops
     * when the visitor returns false.
     */
    void forEachMatch(BlockVisitor visitor);

    /** One block of {@link #forEachMatch}. */
    @FunctionalInterface
    interface BlockVisitor {
        /** @return whether to go on */
        boolean visit(int x, int y, int z, BlockState state);
    }
}
