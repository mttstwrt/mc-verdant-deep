package dev.syrval.volumetrics.api;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

/**
 * Block tags the engine reads, so a mod or datapack fixes how its own blocks meet gas without code. Without either,
 * gas is kept out of fluids and out of anything that is a full block to walk into or to look at, and passes everything
 * else (slabs, fences, plants). The library ships both empty; the engine reads them when a level's gas starts.
 */
public final class VolumetricsTags {
    /** {@code #volumetrics:blocks_gas}: kept out of, whatever their shape (closed doors, glass panes, leaves). */
    public static final TagKey<Block> BLOCKS_GAS = block("blocks_gas");
    /** {@code #volumetrics:passes_gas}: let through, whatever their shape (a grate, a mesh); wins over blocks_gas. */
    public static final TagKey<Block> PASSES_GAS = block("passes_gas");

    private VolumetricsTags() {}

    private static TagKey<Block> block(String name) {
        return TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("volumetrics", name));
    }
}
