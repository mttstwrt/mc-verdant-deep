package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceKey;

/**
 * Gas of a medium turning into another as it goes: steam cooling into mist, smoke settling into ash, a potion's cloud
 * fading into plain haze. One entry of a medium's {@code converts}:
 * {@code "converts": [{"into": "verdant_deep:mist", "rate": 0.12, "above": 40}]}.
 *
 * <ul>
 *   <li>{@code into}: the medium it becomes, as that medium is, without the variant (tint, emission) of the gas it
 *   came from.</li>
 *   <li>{@code rate}: the share that turns each second, 0 to 20: at 0.12 about a ninth of the gas turns in a second,
 *   and half of it in six. Nothing is lost: what one medium loses the other gains, up to its full density.</li>
 *   <li>{@code above}, {@code below}: only where the gas is above (or below) that height, in blocks; anywhere unless
 *   written. Steam that cools into mist as it rises out of a hollow.</li>
 * </ul>
 *
 * <p>Gas turns where it is simulated: on each client for cosmetic gas, near the camera. A medium that turns into one
 * that turns again goes on down the chain. Turning after a delay (gas older than so many seconds) is not here yet: it
 * needs the age of the gas carried with it, which comes with temperature.
 *
 * @param into  what it becomes
 * @param rate  the share that turns each second
 * @param above the height above which it turns, in blocks; empty for no floor
 * @param below the height below which it turns, in blocks; empty for no ceiling
 */
public record Conversion(ResourceKey<Medium> into, float rate, Optional<Float> above, Optional<Float> below) {
    public static final Codec<Conversion> CODEC = RecordCodecBuilder.<Conversion>create(instance -> instance.group(
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).fieldOf("into").forGetter(Conversion::into),
            Ranges.CONVERSION_RATE.codec().fieldOf("rate").forGetter(Conversion::rate),
            Codec.FLOAT.optionalFieldOf("above").forGetter(Conversion::above),
            Codec.FLOAT.optionalFieldOf("below").forGetter(Conversion::below)
    ).apply(instance, Conversion::new)).validate(Conversion::checkBand);

    public Conversion {
        Objects.requireNonNull(into, "converts.into");
        Ranges.CONVERSION_RATE.check(rate);
        Objects.requireNonNull(above, "converts.above");
        Objects.requireNonNull(below, "converts.below");
        String problem = bandProblem(above, below);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }
    }

    /** Anywhere, at {@code rate} a second. */
    public static Conversion into(ResourceKey<Medium> into, float rate) {
        return new Conversion(into, rate, Optional.empty(), Optional.empty());
    }

    /** Only above {@code y}. */
    public Conversion above(float y) {
        return new Conversion(into, rate, Optional.of(y), below);
    }

    /** Only below {@code y}. */
    public Conversion below(float y) {
        return new Conversion(into, rate, above, Optional.of(y));
    }

    private static DataResult<Conversion> checkBand(Conversion conversion) {
        String problem = bandProblem(conversion.above, conversion.below);
        return problem == null ? DataResult.success(conversion) : DataResult.error(() -> problem);
    }

    private static String bandProblem(Optional<Float> above, Optional<Float> below) {
        if (above.isPresent() && !Float.isFinite(above.get()) || below.isPresent() && !Float.isFinite(below.get())) {
            return "converts.above and below must be finite heights";
        }
        if (above.isPresent() && below.isPresent() && above.get() >= below.get()) {
            return "converts.above must be under converts.below, got " + above.get() + " and " + below.get();
        }
        return null;
    }
}
