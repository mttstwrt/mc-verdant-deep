package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.field.Field;
import dev.syrval.volumetrics.api.medium.Medium;
import dev.syrval.volumetrics.api.medium.Variant;
import java.util.List;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * Gas of one medium added at once over a shape: {@code density} where the shape is 1 (a signed distance counts as 1
 * inside), in proportion elsewhere, on top of what is there, up to the medium's full density. The shape is written
 * relative to where the puff is fired, bounded and no more than 256 blocks across, as a source's is.
 * {@code {"type": "volumetrics:puff", "medium": "volumetrics:smoke", "density": 0.6,
 * "shape": {"type": "volumetrics:sphere", "radius": 4}}}.
 *
 * @param density a density from 0 to 1, the medium's full density being its own cap
 * @param variant its medium's look changed for this puff alone ({@code tint}, {@code emission})
 */
public record Puff(ResourceKey<Medium> medium, Field shape, float density, Variant variant) implements Event {
    private static final Limits DENSITY = new Limits("puff.density", 0f, 1f);

    public static final MapCodec<Puff> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).fieldOf("medium").forGetter(Puff::medium),
            Field.CODEC.fieldOf("shape").forGetter(Puff::shape),
            DENSITY.codec().fieldOf("density").forGetter(Puff::density),
            Variant.MAP_CODEC.forGetter(Puff::variant)
    ).apply(instance, Puff::new));

    public Puff {
        Objects.requireNonNull(medium, "puff.medium");
        Objects.requireNonNull(shape, "puff.shape");
        DENSITY.check(density);
        Objects.requireNonNull(variant, "puff.variant");
    }

    /** Of the medium as it is. */
    public Puff(ResourceKey<Medium> medium, Field shape, float density) {
        this(medium, shape, density, Variant.NONE);
    }

    /** Its medium's look changed for this puff alone. */
    public Puff withVariant(Variant variant) {
        return new Puff(medium, shape, density, variant);
    }

    /** Its one medium. */
    @Override
    public List<ResourceKey<Medium>> media() {
        return List.of(medium);
    }

    @Override
    public ResourceLocation type() {
        return Events.PUFF;
    }
}
