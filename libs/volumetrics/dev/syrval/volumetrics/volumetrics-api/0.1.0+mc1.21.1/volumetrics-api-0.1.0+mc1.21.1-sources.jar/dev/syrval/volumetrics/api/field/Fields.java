package dev.syrval.volumetrics.api.field;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.Vec3;

/**
 * Field nodes built in Java: shorter than their records' constructors, and the same records a file would give.
 *
 * <pre>{@code
 * Field clouds = Fields.mul(
 *         Fields.inside(Fields.slab(180, 230), 12),
 *         Fields.coverage(Fields.noise(160).withOctaves(3).withFrame(NoiseFrame.WIND), 0.45f, 0.2f),
 *         Fields.condition(ResourceLocation.fromNamespaceAndPath("weather", "cloudiness")));
 * }</pre>
 */
public final class Fields {
    private Fields() {}

    public static Constant constant(float value) {
        return new Constant(value);
    }

    public static Altitude altitude() {
        return Altitude.INSTANCE;
    }

    /** The height above the ground under the trees ({@link HeightAboveSurface.Surface#MOTION_BLOCKING_NO_LEAVES}). */
    public static HeightAboveSurface heightAboveSurface() {
        return HeightAboveSurface.GROUND;
    }

    public static HeightAboveSurface heightAboveSurface(HeightAboveSurface.Surface surface) {
        return new HeightAboveSurface(surface);
    }

    public static Time time() {
        return Time.INSTANCE;
    }

    public static Condition condition(ResourceLocation id) {
        return new Condition(id);
    }

    public static Ref ref(ResourceKey<Field> id) {
        return new Ref(id);
    }

    public static Sphere sphere(Vec3 center, float radius) {
        return new Sphere(center, radius);
    }

    public static Box box(Vec3 min, Vec3 max) {
        return new Box(min, max);
    }

    /** A box {@code width} along x and {@code depth} along z, standing on {@code base}, the middle of its bottom. */
    public static Box box(Vec3 base, float width, float height, float depth) {
        return new Box(base.add(-width / 2.0, 0, -depth / 2.0), base.add(width / 2.0, height, depth / 2.0));
    }

    public static Cylinder cylinder(Vec3 base, float height, float radius) {
        return new Cylinder(base, height, radius);
    }

    /** A cone, funnel or bowl: the radius going from {@code bottomRadius} to {@code topRadius}. */
    public static Cylinder cone(Vec3 base, float height, float bottomRadius, float topRadius) {
        return new Cylinder(base, height, bottomRadius, topRadius);
    }

    public static Capsule capsule(Vec3 from, Vec3 to, float radius) {
        return new Capsule(from, to, radius);
    }

    public static Slab slab(double bottom, double top) {
        return new Slab(bottom, top);
    }

    public static Inside inside(Field shape, float edge) {
        return new Inside(shape, edge);
    }

    public static Shell shell(Field shape, float width) {
        return new Shell(shape, width);
    }

    /** Over the altitude: {@code start} at {@code from}, thinning by e every {@code scaleHeight} blocks up. */
    public static Exponential exponential(float from, float start, float scaleHeight) {
        return new Exponential(from, start, scaleHeight);
    }

    /** Over the altitude: {@code start} at {@code from}, {@code end} at {@code to}. */
    public static Linear linear(float from, float to, float start, float end) {
        return new Linear(Altitude.INSTANCE, from, to, start, end);
    }

    /** Over the altitude, peaking at 1. */
    public static Gaussian gaussian(float center, float width) {
        return new Gaussian(Altitude.INSTANCE, center, width, 1f);
    }

    /** Value noise of one octave, still in the world; see {@link Noise#withOctaves} and {@link Noise#withFrame}. */
    public static Noise noise(float scale) {
        return new Noise(scale);
    }

    public static Coverage coverage(Field noise, float coverage, float softness) {
        return new Coverage(noise, coverage, softness);
    }

    public static Clamp clamp(Field input, float min, float max) {
        return new Clamp(input, min, max);
    }

    public static Remap remap(Field input, float fromMin, float fromMax, float toMin, float toMax) {
        return new Remap(input, fromMin, fromMax, toMin, toMax);
    }

    public static Smoothstep smoothstep(Field input, float from, float to) {
        return new Smoothstep(input, from, to);
    }

    public static Add add(Field... args) {
        return new Add(List.of(args));
    }

    public static Mul mul(Field... args) {
        return new Mul(List.of(args));
    }

    public static Min min(Field... args) {
        return new Min(List.of(args));
    }

    public static Max max(Field... args) {
        return new Max(List.of(args));
    }

    public static SmoothMin smoothMin(float smoothness, Field... args) {
        return new SmoothMin(List.of(args), smoothness);
    }

    public static SmoothMax smoothMax(float smoothness, Field... args) {
        return new SmoothMax(List.of(args), smoothness);
    }

    public static Lerp lerp(Field from, Field to, Field amount) {
        return new Lerp(from, to, amount);
    }

    public static Translate translate(Vec3 offset, Field field) {
        return new Translate(offset, field);
    }

    public static Scale scale(float factor, Vec3 pivot, Field field) {
        return new Scale(factor, pivot, field);
    }

    public static RotateY rotateY(float degrees, Vec3 pivot, Field field) {
        return new RotateY(degrees, pivot, field);
    }

    public static Warp warp(Noise noise, float strength, Field field) {
        return new Warp(noise, strength, field);
    }
}
