package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/** A kind of force: the id it is written with ({@code "type"}) and the codec of its fields. See {@link ForceKinds}. */
public record ForceType(ResourceLocation id, MapCodec<? extends ForceKind> codec) {
    public ForceType {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(codec, "codec");
    }
}
