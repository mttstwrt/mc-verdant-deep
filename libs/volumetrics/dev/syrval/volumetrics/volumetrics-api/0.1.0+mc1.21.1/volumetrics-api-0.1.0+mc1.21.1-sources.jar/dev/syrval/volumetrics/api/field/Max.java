package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.List;

/**
 * The most of its fields: over shapes, their intersection (inside all of them); over densities, where any is.
 * {@code {"type": "volumetrics:max", "args": [{...}, {...}]}}.
 */
public record Max(List<Field> args) implements Field {
    public static final MapCodec<Max> MAP_CODEC = Check.args("max.args", 1).fieldOf("args").xmap(Max::new, Max::args);

    public Max {
        args = Check.args(args, 1, "max.args");
    }

    @Override
    public FieldType type() {
        return FieldTypes.MAX;
    }

    @Override
    public FieldBounds bounds() {
        return Bounds.maxOf(args);
    }

    @Override
    public float minimum() {
        float least = Float.NEGATIVE_INFINITY;
        for (Field arg : args) {
            least = Math.max(least, arg.minimum());
        }
        return least;
    }

    @Override
    public float maximum() {
        float most = Float.NEGATIVE_INFINITY;
        for (Field arg : args) {
            most = Math.max(most, arg.maximum());
        }
        return most;
    }

    @Override
    public boolean distance() {
        return Check.allDistances(args);
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
