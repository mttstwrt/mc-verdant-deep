/**
 * Lamps: the colour of the light blocks give off, as gas near them takes it. {@link dev.syrval.volumetrics.api.lamp.Lamp},
 * the entry of the {@code volumetrics:lamp} registry. Records only: immutable, side-neutral, any thread.
 */
package dev.syrval.volumetrics.api.lamp;
