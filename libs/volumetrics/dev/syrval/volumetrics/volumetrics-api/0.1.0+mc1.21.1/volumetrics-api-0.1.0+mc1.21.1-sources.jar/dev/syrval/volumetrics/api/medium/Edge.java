package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import java.util.Optional;

/**
 * How the edge of a medium's gas is drawn, relative to its local peak (the densest the gas is nearby), so a thin
 * cloud and a thick one get the same outline. Drawn only; the simulation does not see it. By default gas thins out
 * softly over the simulation's last cells ({@link #NONE}).
 *
 * <p>An edge preset is an entry of the {@code volumetrics:edge} registry,
 * {@code data/<namespace>/volumetrics/edge/<name>.json}, holding these fields (each optional, {@link #NONE}'s when
 * left out); a medium names one, or writes the fields inline over one ({@link EdgeChoice}).
 *
 * @param threshold      0 to 1: where the outline is, as a share of the local peak. Gas at that share is drawn half
 *                       there, thinner gas less and less, denser gas more and more. 0 for no outline.
 * @param softness       0 to 1: how far, as a share of the local peak, the gas takes to go from not drawn to fully
 *                       drawn, centred on {@code threshold}. Small gives a crisp outline, large a soft one.
 * @param fill           0 to 1: how much the gas inside the outline is drawn as dense as its local peak, so the body
 *                       reads solid; 0 leaves its density as it is
 * @param erosion        0 to 1: how much the wisps, with a finer pattern on top, eat into the gas where it is thin for
 *                       its peak, leaving the dense body whole
 * @param turbulence     blocks: how far the gas is pushed about at a place by an ever-changing swirl, so its edge
 *                       billows; 0 for none
 * @param turbulenceScale swirls per block: 0.25 gives swirls about four blocks across
 * @param turbulenceSpeed how fast the swirls change, in their own size per second
 */
public record Edge(float threshold, float softness, float fill, float erosion, float turbulence, float turbulenceScale,
                   float turbulenceSpeed) {
    /** The soft fade of the simulation's cells: nothing shaped. */
    public static final Edge NONE = new Edge(0f, 0f, 0f, 0f, 0f, 0.25f, 0.5f);

    /** A preset file: the fields given, over {@link #NONE}'s. Written back with every field. */
    public static final Codec<Edge> CODEC = Overrides.MAP_CODEC.codec().xmap(overrides -> overrides.over(NONE), Overrides::of);

    public Edge {
        Ranges.EDGE_THRESHOLD.check(threshold);
        Ranges.EDGE_SOFTNESS.check(softness);
        Ranges.EDGE_FILL.check(fill);
        Ranges.EDGE_EROSION.check(erosion);
        Ranges.EDGE_TURBULENCE.check(turbulence);
        Ranges.EDGE_TURBULENCE_SCALE.check(turbulenceScale);
        Ranges.EDGE_TURBULENCE_SPEED.check(turbulenceSpeed);
    }

    /**
     * Some of an edge's fields, to be laid over a preset's: what a medium writes inline, and how a preset file is read.
     * An empty field keeps the preset's.
     */
    public record Overrides(Optional<Float> threshold, Optional<Float> softness, Optional<Float> fill,
                            Optional<Float> erosion, Optional<Float> turbulence, Optional<Float> turbulenceScale,
                            Optional<Float> turbulenceSpeed) {
        /** Changes nothing. */
        public static final Overrides NONE = new Overrides(Optional.empty(), Optional.empty(), Optional.empty(),
                Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty());

        /** The fields as an object's, every one optional; a medium's inline edge adds {@code preset} beside them. */
        public static final MapCodec<Overrides> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Ranges.EDGE_THRESHOLD.codec().optionalFieldOf("threshold").forGetter(Overrides::threshold),
                Ranges.EDGE_SOFTNESS.codec().optionalFieldOf("softness").forGetter(Overrides::softness),
                Ranges.EDGE_FILL.codec().optionalFieldOf("fill").forGetter(Overrides::fill),
                Ranges.EDGE_EROSION.codec().optionalFieldOf("erosion").forGetter(Overrides::erosion),
                Ranges.EDGE_TURBULENCE.codec().optionalFieldOf("turbulence").forGetter(Overrides::turbulence),
                Ranges.EDGE_TURBULENCE_SCALE.codec().optionalFieldOf("turbulence_scale").forGetter(Overrides::turbulenceScale),
                Ranges.EDGE_TURBULENCE_SPEED.codec().optionalFieldOf("turbulence_speed").forGetter(Overrides::turbulenceSpeed)
        ).apply(instance, Overrides::new));

        public Overrides {
            Objects.requireNonNull(threshold, "threshold").ifPresent(Ranges.EDGE_THRESHOLD::check);
            Objects.requireNonNull(softness, "softness").ifPresent(Ranges.EDGE_SOFTNESS::check);
            Objects.requireNonNull(fill, "fill").ifPresent(Ranges.EDGE_FILL::check);
            Objects.requireNonNull(erosion, "erosion").ifPresent(Ranges.EDGE_EROSION::check);
            Objects.requireNonNull(turbulence, "turbulence").ifPresent(Ranges.EDGE_TURBULENCE::check);
            Objects.requireNonNull(turbulenceScale, "turbulenceScale").ifPresent(Ranges.EDGE_TURBULENCE_SCALE::check);
            Objects.requireNonNull(turbulenceSpeed, "turbulenceSpeed").ifPresent(Ranges.EDGE_TURBULENCE_SPEED::check);
        }

        /** Every field of {@code edge}: laid over anything, gives {@code edge}. */
        public static Overrides of(Edge edge) {
            return new Overrides(Optional.of(edge.threshold), Optional.of(edge.softness), Optional.of(edge.fill),
                    Optional.of(edge.erosion), Optional.of(edge.turbulence), Optional.of(edge.turbulenceScale),
                    Optional.of(edge.turbulenceSpeed));
        }

        /** {@code base} with the fields given here in place of its own. */
        public Edge over(Edge base) {
            return new Edge(threshold.orElse(base.threshold), softness.orElse(base.softness), fill.orElse(base.fill),
                    erosion.orElse(base.erosion), turbulence.orElse(base.turbulence),
                    turbulenceScale.orElse(base.turbulenceScale), turbulenceSpeed.orElse(base.turbulenceSpeed));
        }

        public boolean isEmpty() {
            return equals(NONE);
        }
    }
}
