package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.field.Field;

/**
 * A swirl about the attachment's upright axis (its frame's y): a dust devil, a whirlpool, a cauldron's swirl. Air goes
 * round at {@code speed} blocks per second at {@code core} blocks from the axis (positive is anticlockwise seen from
 * above), in proportion to the distance inside the core and falling off as 1 / distance outside it, as a Rankine
 * vortex does. {@code inflow} draws it in towards the axis, slowing inside the core, and {@code lift} carries it
 * along the axis, both in blocks per second.
 * {@code {"type": "volumetrics:vortex", "speed": 4, "core": 1.5, "lift": 1, "shape": {...}}}.
 */
public record Vortex(float speed, float core, float inflow, float lift, Field shape, float reach) implements ForceKind {
    private static final Limits SPEED = Limits.speed("vortex.speed");
    private static final Limits CORE = new Limits("vortex.core", 0.1f, 64f);
    private static final Limits INFLOW = Limits.speed("vortex.inflow");
    private static final Limits LIFT = Limits.speed("vortex.lift");

    public static final MapCodec<Vortex> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            SPEED.codec().fieldOf("speed").forGetter(Vortex::speed),
            CORE.codec().optionalFieldOf("core", 1f).forGetter(Vortex::core),
            INFLOW.codec().optionalFieldOf("inflow", 0f).forGetter(Vortex::inflow),
            LIFT.codec().optionalFieldOf("lift", 0f).forGetter(Vortex::lift),
            Field.CODEC.fieldOf("shape").forGetter(Vortex::shape),
            Region.reach("vortex").optionalFieldOf("reach", 0f).forGetter(Vortex::reach)
    ).apply(instance, Vortex::new));

    public Vortex {
        SPEED.check(speed);
        CORE.check(core);
        INFLOW.check(inflow);
        LIFT.check(lift);
        Region.shape(shape, "vortex");
        Region.reach(reach, "vortex");
    }

    @Override
    public ForceType type() {
        return ForceKinds.VORTEX;
    }
}
