package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.List;

/**
 * The least of its fields: over shapes, their union (the nearest surface); over densities, where all of them are.
 * {@code {"type": "volumetrics:min", "args": [{...}, {...}]}}.
 */
public record Min(List<Field> args) implements Field {
    public static final MapCodec<Min> MAP_CODEC = Check.args("min.args", 1).fieldOf("args").xmap(Min::new, Min::args);

    public Min {
        args = Check.args(args, 1, "min.args");
    }

    @Override
    public FieldType type() {
        return FieldTypes.MIN;
    }

    @Override
    public FieldBounds bounds() {
        return Bounds.minOf(args, 0f);
    }

    @Override
    public float minimum() {
        float least = Float.POSITIVE_INFINITY;
        for (Field arg : args) {
            least = Math.min(least, arg.minimum());
        }
        return least;
    }

    @Override
    public float maximum() {
        float most = Float.POSITIVE_INFINITY;
        for (Field arg : args) {
            most = Math.min(most, arg.maximum());
        }
        return most;
    }

    @Override
    public boolean distance() {
        return Check.allDistances(args);
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
