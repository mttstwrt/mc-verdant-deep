package dev.syrval.volumetrics.api.lamp;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Objects;
//? if >=26.1 {
/*import net.minecraft.core.registries.codec.RegistryCodecs;
*///?} else {
import net.minecraft.core.RegistryCodecs;
//?}
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;

/**
 * The colour of the light that {@code blocks} (a list, one id, or a {@code #tag}) give off, as gas lit by them takes
 * it: an entry of the {@code volumetrics:lamp} registry, {@code data/<namespace>/volumetrics/lamp/<name>.json}.
 *
 * <pre>{@code
 * { "blocks": ["minecraft:soul_torch", "minecraft:soul_lantern"], "colour": "#5ACCF0" }
 * }</pre>
 *
 * <p>Only the hue and saturation of {@code colour} count: how bright the gas is stays the game's block light, with its
 * falloff and walls, so gas is as bright as the blocks beside it. White ({@code #FFFFFF}) is the game's own lamp
 * colour, which the lightmap makes warm. A block that gives off light and has no entry takes its map colour, or white
 * if it has none. The library ships entries for the vanilla blocks whose light is not the game's warm default (soul
 * fire, amethyst, sculk, redstone, portals and the like) and white ones for those whose map colour is not their light's
 * (fire, campfires, candles). Where entries name the same block, a pack's wins over the library's, and among the
 * others the last by id. Where lamps of different colours meet, the brighter light's colour wins. Read by clients when
 * their gas starts; a renderer without {@code volumetrics:coloured_lamps} ({@code Capabilities.has}) lights gas with the
 * game's lamp colour alone.
 *
 * @param colour {@code 0xRRGGBB}, written {@code "#RRGGBB"}
 */
public record Lamp(HolderSet<Block> blocks, int colour) {
    public static final Codec<Lamp> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            //? if >=26.1 {
            /*RegistryCodecs.holderSet(Registries.BLOCK).fieldOf("blocks").forGetter(Lamp::blocks),
            *///?} else {
            RegistryCodecs.homogeneousList(Registries.BLOCK).fieldOf("blocks").forGetter(Lamp::blocks),
            //?}
            VolumetricsCodecs.RGB.fieldOf("colour").forGetter(Lamp::colour)
    ).apply(instance, Lamp::new));

    public Lamp {
        Objects.requireNonNull(blocks, "blocks");
        VolumetricsCodecs.requireRgb(colour, "colour");
    }
}
