package dev.syrval.volumetrics.api.query;

import dev.syrval.volumetrics.api.Experimental;
import dev.syrval.volumetrics.api.medium.Medium;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * How much gas there is in one level, on the side it was asked of ({@link
 * dev.syrval.volumetrics.api.VolumetricsApi#queries}). Made for hot paths: a mod may ask per entity per tick.
 * {@link #density} allocates nothing; the others make their answer.
 *
 * <p><b>On a client</b>, any thread, never waiting: near the camera the answer is the simulation's newest step (at most
 * a step, a tenth of a second, old) read at the cell the point is in as it is drawn (a byte of the medium's full
 * density, so thin gas is rounded to steps of 1/255 of it), plus the drawn fields over it; beyond the
 * simulation it is the placed fields' formula alone (drawn and simulated ones). Placed fields count as their formula,
 * whether or not today's renderer manages to draw them. A client simulates {@code analytic} media near its camera as
 * it does cosmetic ones, so its answer there includes that detail.
 *
 * <p><b>On a server</b>, the server thread only (else {@link IllegalStateException}): for {@code analytic} media, exactly
 * their placed fields' formula, with the same conditions and surface a client evaluates them with, from every field the
 * server knows of: the level's ambient fields and those placed through {@code owner.server}. Fields a client placed
 * for itself ({@code owner.client}) are not the server's to know. Cosmetic media have no answer there: their density
 * is 0, a sample leaves them out, and an integration of one is {@link GasStats#EMPTY}. So, for now, do {@code
 * gameplay} media, until the server simulates them (VOL-060).
 *
 * <p>Costs and limits: {@link #transmittance} marches at most {@value #MAX_MARCH_STEPS} steps; {@link #integrate}
 * reads at most {@value #MAX_SAMPLES} points of a box no larger than {@value #MAX_BOX_SIDE} blocks on a side.
 */
@Experimental
public interface GasQueries {
    /** The most steps {@link #transmittance} takes along its line: a longer line takes longer steps. */
    int MAX_MARCH_STEPS = 256;
    /**
     * The step {@link #transmittance} takes where there is no simulation to step through, in blocks: the size of the
     * finest simulation cells, so a server's answer is as fine as a client's near its camera.
     */
    double FIELD_STEP = 2.0;
    /** The most points {@link #integrate} reads: a larger box is read on a coarser lattice. */
    int MAX_SAMPLES = 32_768;
    /** The largest side of a box {@link #integrate} reads, in blocks: a larger box is cut to this round its centre. */
    double MAX_BOX_SIDE = 1024.0;

    /** A medium's density at a point, 1 being pure gas; 0 where it is not, or where this side does not know it. */
    float density(ResourceKey<Medium> medium, Vec3 at);

    /** Every medium's gas at a point, with the light it stops and where it moves. */
    GasSample sample(Vec3 at);

    /**
     * The share of light that comes through the gas along a line, 1 through clear air and towards 0 through thick gas:
     * {@code exp} of minus the extinction summed along it.
     *
     * <p>Marched in steps of the cell size of the simulation level the step starts in (where the gas cannot change
     * within a step), else {@link #FIELD_STEP}; no more than {@value #MAX_MARCH_STEPS} of them, longer when the line
     * is too long for that. Each step reads its middle. It ends early once almost no light (under 1e-4) is left.
     */
    float transmittance(Vec3 from, Vec3 to);

    /**
     * The gas of one medium, or of all with {@code null}, in a box. Near the camera it sums the simulation's cells that
     * the box overlaps, each by how much of it is in the box; elsewhere it samples the fields on a lattice of
     * {@link #FIELD_STEP}. Costs in proportion to the cells or lattice points in the box, at most {@value
     * #MAX_SAMPLES}: past that the lattice is coarser. A box larger than {@value #MAX_BOX_SIDE} blocks on a side is
     * cut to that round its centre.
     */
    GasStats integrate(AABB box, @Nullable ResourceKey<Medium> medium);
}
