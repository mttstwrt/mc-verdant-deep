package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.field.Field;
import net.minecraft.world.phys.Vec3;

/**
 * One velocity over a shape, in blocks per second in the attachment's frame: a draught through a corridor, a current
 * down a chasm. {@code {"type": "volumetrics:uniform", "velocity": {"x": 3}, "shape": {...}, "reach": 2}}.
 */
public record Uniform(Vec3 velocity, Field shape, float reach) implements ForceKind {
    public static final MapCodec<Uniform> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Limits.velocity("uniform.velocity").fieldOf("velocity").forGetter(Uniform::velocity),
            Field.CODEC.fieldOf("shape").forGetter(Uniform::shape),
            Region.reach("uniform").optionalFieldOf("reach", 0f).forGetter(Uniform::reach)
    ).apply(instance, Uniform::new));

    public Uniform {
        Limits.checkVelocity(velocity, "uniform.velocity");
        Region.shape(shape, "uniform");
        Region.reach(reach, "uniform");
    }

    @Override
    public ForceType type() {
        return ForceKinds.UNIFORM;
    }
}
