/**
 * Fields: density composed from primitives, as data. {@link dev.syrval.volumetrics.api.field.Field} and its nodes
 * ({@link dev.syrval.volumetrics.api.field.FieldTypes}), {@link dev.syrval.volumetrics.api.field.Fields} to build them
 * in Java, and placed fields: {@link dev.syrval.volumetrics.api.field.PlacedField}, and
 * {@link dev.syrval.volumetrics.api.field.Ambient} for those a dimension's data places. The codecs are the format of
 * {@code data/<namespace>/volumetrics/field/} and {@code data/<namespace>/volumetrics/ambient/} files. Records only:
 * immutable, side-neutral, any thread. The engine compiles a field into a program of its own; nothing here names how
 * a renderer or a simulation evaluates it.
 */
package dev.syrval.volumetrics.api.field;
