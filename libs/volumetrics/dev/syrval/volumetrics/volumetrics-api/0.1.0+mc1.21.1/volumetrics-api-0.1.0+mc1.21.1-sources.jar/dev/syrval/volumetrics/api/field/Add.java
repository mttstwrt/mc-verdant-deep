package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.List;

/** The sum of its fields: {@code {"type": "volumetrics:add", "args": [{...}, {...}]}}. */
public record Add(List<Field> args) implements Field {
    public static final MapCodec<Add> MAP_CODEC = Check.args("add.args", 1).fieldOf("args").xmap(Add::new, Add::args);

    public Add {
        args = Check.args(args, 1, "add.args");
    }

    @Override
    public FieldType type() {
        return FieldTypes.ADD;
    }

    /** Where any of them is above 0. */
    @Override
    public FieldBounds bounds() {
        if (Check.anyDistance(args)) {
            return FieldBounds.EVERYWHERE;
        }
        FieldBounds union = FieldBounds.NOWHERE;
        for (Field arg : args) {
            union = union.union(arg.bounds());
        }
        return union;
    }

    @Override
    public float minimum() {
        float sum = 0f;
        for (Field arg : args) {
            sum += arg.minimum();
        }
        return Float.isNaN(sum) ? Float.NEGATIVE_INFINITY : sum;
    }

    @Override
    public float maximum() {
        float sum = 0f;
        for (Field arg : args) {
            sum += arg.maximum();
        }
        return Float.isNaN(sum) ? Float.POSITIVE_INFINITY : sum;
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
