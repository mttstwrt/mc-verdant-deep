package dev.syrval.volumetrics.api.medium;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Which way a medium scatters the light that falls on it: a Henyey-Greenstein lobe, or two of them blended. A lobe's
 * anisotropy {@code g} runs from -0.9 to 0.9: towards 0.9 most light goes on forwards, so the gas glows seen against
 * the sun; towards -0.9 most comes back the way it came; at 0 it goes every way alike. Written as one number for a
 * single lobe, {@code "phase": 0.6}, or as {@code {"forward": 0.6, "back": -0.3, "blend": 0.25}}: clouds, steam and
 * smoke send most light forwards and a little back, which a single lobe cannot.
 *
 * @param forward the first lobe's anisotropy, usually the forward one
 * @param back    the second lobe's anisotropy, usually negative; unused at a {@code blend} of 0
 * @param blend   how much of the light the second lobe takes, 0 to 1
 */
public record Phase(float forward, float back, float blend) {
    /** Cloud-like: half of the way forwards, with a quarter of the light going back at half that. */
    public static final Phase DEFAULT = new Phase(0.5f, -0.25f, 0.25f);

    private static final Codec<Phase> LOBES_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.PHASE_LOBE.codec().fieldOf("forward").forGetter(Phase::forward),
            Ranges.PHASE_LOBE.codec().fieldOf("back").forGetter(Phase::back),
            Ranges.PHASE_BLEND.codec().fieldOf("blend").forGetter(Phase::blend)
    ).apply(instance, Phase::new));

    /** A number for one lobe, an object for two; a phase with no second lobe is written as its number. */
    public static final Codec<Phase> CODEC = Codec.either(Ranges.PHASE_LOBE.codec(), LOBES_CODEC).xmap(
            either -> either.map(Phase::single, phase -> phase),
            phase -> phase.blend == 0f ? Either.left(phase.forward) : Either.right(phase));

    public Phase {
        Ranges.PHASE_LOBE.check(forward);
        Ranges.PHASE_LOBE.check(back);
        Ranges.PHASE_BLEND.check(blend);
    }

    /** One lobe of anisotropy {@code g}. */
    public static Phase single(float g) {
        return new Phase(g, 0f, 0f);
    }
}
