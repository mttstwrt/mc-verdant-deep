package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import net.minecraft.world.phys.Vec3;

/** The bounds of a force file's numbers, named as written, so a file and a record built in Java fail alike. */
record Limits(String name, float min, float max) {
    /** Speeds, in blocks per second: the most anything pushes gas in the engines. */
    static final float MAX_SPEED = 16f;

    static Limits speed(String name) {
        return new Limits(name, -MAX_SPEED, MAX_SPEED);
    }

    static Limits distance(String name, float max) {
        return new Limits(name, 0f, max);
    }

    static Codec<Vec3> velocity(String name) {
        return VolumetricsCodecs.XYZ.validate(vector -> vector.length() <= MAX_SPEED ? DataResult.success(vector)
                : DataResult.error(() -> name + " must be at most " + MAX_SPEED + " blocks per second, got " + vector.length()));
    }

    static Vec3 checkVelocity(Vec3 vector, String name) {
        if (vector == null || !(vector.length() <= MAX_SPEED)) {
            throw new IllegalArgumentException(name + " must be at most " + MAX_SPEED + " blocks per second, got " + vector);
        }
        return vector;
    }

    Codec<Float> codec() {
        return Codec.FLOAT.validate(value -> within(value) ? DataResult.success(value) : DataResult.error(() -> message(value)));
    }

    float check(float value) {
        if (!within(value)) {
            throw new IllegalArgumentException(message(value));
        }
        return value;
    }

    private boolean within(float value) {
        return value >= min && value <= max;
    }

    private String message(float value) {
        return name + " must be from " + min + " to " + max + ", got " + value;
    }
}
