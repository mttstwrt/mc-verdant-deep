package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.List;
import java.util.Objects;
import java.util.function.DoublePredicate;

/**
 * The checks of field nodes' numbers, each naming the node and field as written ({@code sphere.radius}), so a file
 * and a record built in Java are refused with the same message: in the codec as a data error, in a constructor as an
 * exception. Also the interval sums and products the arithmetic nodes state their ranges with.
 */
final class Check {
    private Check() {}

    static Codec<Float> number(String name) {
        return floats(name, value -> Double.isFinite(value), "a finite number");
    }

    static Codec<Float> positive(String name) {
        return floats(name, value -> value > 0 && Double.isFinite(value), "a positive number");
    }

    static Codec<Float> notNegative(String name) {
        return floats(name, value -> value >= 0 && Double.isFinite(value), "a number of 0 or more");
    }

    static Codec<Float> share(String name) {
        return floats(name, value -> value >= 0 && value <= 1, "from 0 to 1");
    }

    static Codec<Double> position(String name) {
        return Codec.DOUBLE.validate(value -> Double.isFinite(value) ? DataResult.success(value)
                : DataResult.error(() -> name + " must be a finite number, got " + value));
    }

    static float number(float value, String name) {
        return require(value, Float.isFinite(value), name, "a finite number");
    }

    static float positive(float value, String name) {
        return require(value, value > 0 && Float.isFinite(value), name, "a positive number");
    }

    static float notNegative(float value, String name) {
        return require(value, value >= 0 && Float.isFinite(value), name, "a number of 0 or more");
    }

    static float share(float value, String name) {
        return require(value, value >= 0 && value <= 1, name, "from 0 to 1");
    }

    static double position(double value, String name) {
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException(name + " must be a finite number, got " + value);
        }
        return value;
    }

    static net.minecraft.world.phys.Vec3 position(net.minecraft.world.phys.Vec3 value, String name) {
        Objects.requireNonNull(value, name);
        position(value.x, name + ".x");
        position(value.y, name + ".y");
        position(value.z, name + ".z");
        return value;
    }

    /** A copy of a node's list of fields, at least {@code least} of them. */
    static List<Field> args(List<Field> args, int least, String name) {
        List<Field> copy = List.copyOf(Objects.requireNonNull(args, name));
        if (copy.size() < least) {
            throw new IllegalArgumentException(name + " needs at least " + least + " fields, got " + copy.size());
        }
        return copy;
    }

    static Codec<List<Field>> args(String name, int least) {
        return Field.CODEC.listOf().validate(list -> list.size() >= least ? DataResult.success(list)
                : DataResult.error(() -> name + " needs at least " + least + " fields, got " + list.size()));
    }

    private static Codec<Float> floats(String name, DoublePredicate valid, String what) {
        return Codec.FLOAT.validate(value -> valid.test(value) ? DataResult.success(value)
                : DataResult.error(() -> name + " must be " + what + ", got " + value));
    }

    private static float require(float value, boolean valid, String name, String what) {
        if (!valid) {
            throw new IllegalArgumentException(name + " must be " + what + ", got " + value);
        }
        return value;
    }

    /** Whether any of the fields is a distance. */
    static boolean anyDistance(List<Field> fields) {
        for (Field field : fields) {
            if (field.distance()) {
                return true;
            }
        }
        return false;
    }

    static boolean allDistances(List<Field> fields) {
        for (Field field : fields) {
            if (!field.distance()) {
                return false;
            }
        }
        return true;
    }

    /** The least and most of a product of two ranges; infinities and zeros make no NaN. */
    static float[] product(float aMin, float aMax, float bMin, float bMax) {
        float p1 = times(aMin, bMin);
        float p2 = times(aMin, bMax);
        float p3 = times(aMax, bMin);
        float p4 = times(aMax, bMax);
        return new float[] {Math.min(Math.min(p1, p2), Math.min(p3, p4)), Math.max(Math.max(p1, p2), Math.max(p3, p4))};
    }

    /** a * b, with 0 * infinity as 0: a range that is exactly 0 stays 0 whatever it is multiplied by. */
    private static float times(float a, float b) {
        return a == 0f || b == 0f ? 0f : a * b;
    }
}
