package dev.syrval.volumetrics.api;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * API that may change in any minor release of the API, even once it is 1.0, where the rest changes only in a major
 * one: the code tier (callbacks the engine runs), and features whose engine side is still settling. Using it is fine;
 * expect to follow it when the API's version moves.
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE,
        ElementType.RECORD_COMPONENT})
public @interface Experimental {
}
