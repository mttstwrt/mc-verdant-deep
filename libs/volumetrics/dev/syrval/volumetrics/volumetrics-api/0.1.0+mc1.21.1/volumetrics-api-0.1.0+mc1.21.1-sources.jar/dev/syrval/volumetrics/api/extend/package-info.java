/**
 * The code tier: callbacks the engine runs, for what data cannot say. {@link dev.syrval.volumetrics.api.extend.PlacementRule}
 * places gas per chunk as chunks load; {@link dev.syrval.volumetrics.api.extend.ObstacleProvider} is reserved. {@link dev.syrval.volumetrics.api.Experimental}
 * throughout: these follow the engine and may change in a minor release.
 */
@Experimental
package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
