/**
 * The code tier: callbacks the engine runs, for what data cannot say. {@link dev.syrval.volumetrics.api.Experimental}
 * throughout: these follow the engine and may change in a minor release.
 */
@Experimental
package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
