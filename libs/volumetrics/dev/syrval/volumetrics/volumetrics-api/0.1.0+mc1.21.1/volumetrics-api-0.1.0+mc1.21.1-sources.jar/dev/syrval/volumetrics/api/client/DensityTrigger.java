package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.Experimental;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.Objects;
import net.minecraft.resources.ResourceKey;

/**
 * What a density trigger watches ({@link ClientInputs#onDensity}): one medium's density, as the client's queries
 * answer it, crossing a threshold anywhere within a reach of the camera.
 *
 * @param threshold a density, above 0 and at most 1 (the engine's cap on a medium's full density)
 * @param reach     blocks from the camera, 1 to {@value #MAX_REACH}
 */
@Experimental
public record DensityTrigger(ResourceKey<Medium> medium, float threshold, float reach) {
    public static final float MAX_REACH = 32f;

    public DensityTrigger {
        Objects.requireNonNull(medium, "medium");
        if (!(threshold > 0f && threshold <= 1f)) {
            throw new IllegalArgumentException("A trigger's threshold must be above 0 and at most 1, got " + threshold);
        }
        if (!(reach >= 1f && reach <= MAX_REACH)) {
            throw new IllegalArgumentException("A trigger's reach must be from 1 to " + MAX_REACH + " blocks, got " + reach);
        }
    }
}
