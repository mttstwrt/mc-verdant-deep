package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.List;
import java.util.Objects;
import net.minecraft.world.phys.Vec3;

/**
 * A field turned about the upright line through {@code pivot} (the origin unless given) by {@code degrees}, from east
 * towards south, its noises with it. {@code {"type": "volumetrics:rotate_y", "degrees": 30, "pivot": {...},
 * "field": {...}}}.
 */
public record RotateY(float degrees, Vec3 pivot, Field field) implements Field {
    public static final MapCodec<RotateY> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Check.number("rotate_y.degrees").fieldOf("degrees").forGetter(RotateY::degrees),
            VolumetricsCodecs.XYZ.optionalFieldOf("pivot", Vec3.ZERO).forGetter(RotateY::pivot),
            Field.CODEC.fieldOf("field").forGetter(RotateY::field)
    ).apply(instance, RotateY::new));

    public RotateY {
        Check.number(degrees, "rotate_y.degrees");
        Check.position(pivot, "rotate_y.pivot");
        Objects.requireNonNull(field, "rotate_y.field");
    }

    @Override
    public FieldType type() {
        return FieldTypes.ROTATE_Y;
    }

    /** The box round the turned corners of the field's; unbounded sideways if the field's is on any side. */
    @Override
    public FieldBounds bounds() {
        FieldBounds inner = field.bounds();
        if (inner.isEmpty()) {
            return inner;
        }
        if (!Double.isFinite(inner.minX()) || !Double.isFinite(inner.maxX()) || !Double.isFinite(inner.minZ())
                || !Double.isFinite(inner.maxZ())) {
            return FieldBounds.layer(inner.minY(), inner.maxY());
        }
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double minX = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double minZ = Double.POSITIVE_INFINITY;
        double maxZ = Double.NEGATIVE_INFINITY;
        for (double x : new double[] {inner.minX(), inner.maxX()}) {
            for (double z : new double[] {inner.minZ(), inner.maxZ()}) {
                double dx = x - pivot.x;
                double dz = z - pivot.z;
                double turnedX = pivot.x + dx * cos - dz * sin;
                double turnedZ = pivot.z + dx * sin + dz * cos;
                minX = Math.min(minX, turnedX);
                maxX = Math.max(maxX, turnedX);
                minZ = Math.min(minZ, turnedZ);
                maxZ = Math.max(maxZ, turnedZ);
            }
        }
        return new FieldBounds(minX, inner.minY(), minZ, maxX, inner.maxY(), maxZ);
    }

    @Override
    public float minimum() {
        return field.minimum();
    }

    @Override
    public float maximum() {
        return field.maximum();
    }

    @Override
    public boolean distance() {
        return field.distance();
    }

    @Override
    public List<Field> children() {
        return List.of(field);
    }
}
