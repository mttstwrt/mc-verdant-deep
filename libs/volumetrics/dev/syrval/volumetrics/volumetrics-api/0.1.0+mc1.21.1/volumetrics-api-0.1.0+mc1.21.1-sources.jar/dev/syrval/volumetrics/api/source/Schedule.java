package dev.syrval.volumetrics.api.source;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * When a source gives off gas, as a share of its rate from moment to moment. Times are in seconds.
 * <ul>
 *   <li>{@code volumetrics:always}, the default.</li>
 *   <li>{@code volumetrics:pulse}: {@code on} seconds at the full rate, then {@code off} seconds of nothing, over and
 *   over. The beat is the level's game time moved by {@code offset}, so every player sees the same puffs.</li>
 *   <li>{@code volumetrics:once}: for {@code seconds} after the source is placed (a puff), then nothing until it goes.</li>
 *   <li>{@code volumetrics:curve}: a share of the rate (0 to 16) at times since the source was placed, straight lines
 *   between them, held at the last; with {@code loop} the curve starts again after its last point.</li>
 * </ul>
 * <pre>{@code
 * "schedule": { "type": "volumetrics:pulse", "on": 2, "off": 6 }
 * "schedule": { "type": "volumetrics:curve", "points": [[0, 0], [1, 2], [5, 0]] }
 * }</pre>
 */
public sealed interface Schedule permits Schedule.Always, Schedule.Pulse, Schedule.Once, Schedule.Curve {
    Codec<Schedule> CODEC = Codec.STRING.dispatch("type", Schedule::type, Schedule::codecFor);

    Always ALWAYS = new Always();

    String type();

    static Schedule pulse(float on, float off) {
        return new Pulse(on, off, 0f);
    }

    static Schedule once(float seconds) {
        return new Once(seconds);
    }

    record Always() implements Schedule {
        // A supplier: Schedule.ALWAYS is still being made while this class is first set up.
        static final MapCodec<Always> CODEC = MapCodec.unit(() -> Schedule.ALWAYS);

        @Override
        public String type() {
            return "volumetrics:always";
        }
    }

    /** @param offset seconds the beat is moved by against the game time */
    record Pulse(float on, float off, float offset) implements Schedule {
        static final MapCodec<Pulse> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Limits.SECONDS.codec().fieldOf("on").forGetter(Pulse::on),
                Limits.SECONDS.codec().fieldOf("off").forGetter(Pulse::off),
                Limits.SECONDS.codec().optionalFieldOf("offset", 0f).forGetter(Pulse::offset)
        ).apply(instance, Pulse::new));

        public Pulse {
            Limits.SECONDS.check(on);
            Limits.SECONDS.check(off);
            Limits.SECONDS.check(offset);
            if (!(on + off > 0)) {
                throw new IllegalArgumentException("A pulse needs on + off above 0 seconds");
            }
        }

        @Override
        public String type() {
            return "volumetrics:pulse";
        }
    }

    record Once(float seconds) implements Schedule {
        static final MapCodec<Once> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Limits.SECONDS.codec().fieldOf("seconds").forGetter(Once::seconds)
        ).apply(instance, Once::new));

        public Once {
            Limits.SECONDS.check(seconds);
        }

        @Override
        public String type() {
            return "volumetrics:once";
        }
    }

    /** @param points at least one, by time (seconds since placed, increasing) and share of the rate */
    record Curve(List<Point> points, boolean loop) implements Schedule {
        static final MapCodec<Curve> CODEC = RecordCodecBuilder.<Curve>mapCodec(instance -> instance.group(
                Point.CODEC.listOf().fieldOf("points").forGetter(Curve::points),
                Codec.BOOL.optionalFieldOf("loop", false).forGetter(Curve::loop)
        ).apply(instance, Curve::ofCodec)).validate(curve -> curve == null
                ? DataResult.error(() -> "A curve needs at least one point, with times increasing") : DataResult.success(curve));

        public Curve {
            points = List.copyOf(Objects.requireNonNull(points, "points"));
            if (!valid(points)) {
                throw new IllegalArgumentException("A curve needs at least one point, with times increasing");
            }
        }

        private static Curve ofCodec(List<Point> points, boolean loop) {
            return valid(points) ? new Curve(points, loop) : null;
        }

        private static boolean valid(List<Point> points) {
            if (points.isEmpty()) {
                return false;
            }
            for (int i = 1; i < points.size(); i++) {
                if (!(points.get(i).seconds() > points.get(i - 1).seconds())) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public String type() {
            return "volumetrics:curve";
        }
    }

    /** A point of a curve, written {@code [seconds, share]}. */
    record Point(float seconds, float share) {
        static final Codec<Point> CODEC = Codec.FLOAT.listOf().comapFlatMap(Point::read, point -> List.of(point.seconds, point.share));

        public Point {
            Limits.SECONDS.check(seconds);
            Limits.SCALE.check(share);
        }

        private static DataResult<Point> read(List<Float> list) {
            if (list.size() != 2) {
                return DataResult.error(() -> "A curve point is [seconds, share], got " + list);
            }
            try {
                return DataResult.success(new Point(list.get(0), list.get(1)));
            } catch (IllegalArgumentException e) {
                return DataResult.error(e::getMessage);
            }
        }
    }

    private static MapCodec<? extends Schedule> codecFor(String type) {
        return switch (type) {
            case "volumetrics:always" -> Always.CODEC;
            case "volumetrics:pulse" -> Pulse.CODEC;
            case "volumetrics:once" -> Once.CODEC;
            case "volumetrics:curve" -> Curve.CODEC;
            default -> MapCodec.unit(() -> {
                throw new IllegalArgumentException("Not a schedule: " + type);
            });
        };
    }
}
