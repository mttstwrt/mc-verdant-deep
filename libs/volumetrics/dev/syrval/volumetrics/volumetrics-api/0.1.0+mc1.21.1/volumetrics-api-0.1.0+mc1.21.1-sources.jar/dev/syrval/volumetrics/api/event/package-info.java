/**
 * Events (spec section 10): one-shot changes to the gas, fired through {@link dev.syrval.volumetrics.api.Inputs#fire}.
 * From a server they are stamped with the level's game time and sent to the players tracking the place, each of whom
 * applies it at that time; from a client, on that client alone. They change cosmetic media only, on each client's
 * simulation: an {@code analytic} medium is a formula with nothing to change, and {@code gameplay} media wait for the
 * server's simulation (VOL-060).
 */
package dev.syrval.volumetrics.api.event;
