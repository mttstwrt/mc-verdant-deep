package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

/**
 * The least of its fields with the corners rounded over {@code smoothness}: shapes melt into one another where they
 * meet. The polynomial smooth minimum, taken pairwise from the first field on.
 * {@code {"type": "volumetrics:smooth_min", "args": [{...}, {...}], "smoothness": 4}}.
 */
public record SmoothMin(List<Field> args, float smoothness) implements Field {
    public static final MapCodec<SmoothMin> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Check.args("smooth_min.args", 2).fieldOf("args").forGetter(SmoothMin::args),
            Check.positive("smooth_min.smoothness").fieldOf("smoothness").forGetter(SmoothMin::smoothness)
    ).apply(instance, SmoothMin::new));

    public SmoothMin {
        args = Check.args(args, 2, "smooth_min.args");
        Check.positive(smoothness, "smooth_min.smoothness");
    }

    @Override
    public FieldType type() {
        return FieldTypes.SMOOTH_MIN;
    }

    /** As {@link Min}'s, a shape's grown by the smoothness: the blend reaches a quarter of it outside. */
    @Override
    public FieldBounds bounds() {
        return Bounds.minOf(args, smoothness);
    }

    @Override
    public float minimum() {
        float least = Float.POSITIVE_INFINITY;
        for (Field arg : args) {
            least = Math.min(least, arg.minimum());
        }
        return least - smoothness / 4 * (args.size() - 1);
    }

    @Override
    public float maximum() {
        float most = Float.POSITIVE_INFINITY;
        for (Field arg : args) {
            most = Math.min(most, arg.maximum());
        }
        return most;
    }

    @Override
    public boolean distance() {
        return Check.allDistances(args);
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
