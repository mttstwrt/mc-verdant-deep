/**
 * Sources: gas fed into the simulation. {@link dev.syrval.volumetrics.api.source.Source} (what, where in the shape,
 * how much, when), its {@link dev.syrval.volumetrics.api.source.Schedule}, and
 * {@link dev.syrval.volumetrics.api.source.SourcePlacement}, the entry of the {@code volumetrics:source} registry that
 * places a source by a rule. Records only: immutable, side-neutral, any thread. The engine compiles a source when it is
 * added; nothing here is read while gas is simulated.
 */
package dev.syrval.volumetrics.api.source;
