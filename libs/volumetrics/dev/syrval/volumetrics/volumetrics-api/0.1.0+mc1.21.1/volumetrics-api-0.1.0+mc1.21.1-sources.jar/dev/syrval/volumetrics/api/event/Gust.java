package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.force.Force;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * A force for a few seconds, then gone: any local kind ({@code volumetrics:gusts} for turbulence, {@code radial} for a
 * breath out, {@code uniform} for a sweep), its region relative to where it is fired and not turned. Its media are the
 * force's own {@code media}. Not {@code level_wind}.
 * {@code {"type": "volumetrics:gust", "seconds": 3, "force": {"type": "volumetrics:radial", "speed": 6,
 * "shape": {"type": "volumetrics:sphere", "radius": 8}}}}.
 *
 * @param seconds how long it blows
 */
public record Gust(Force force, float seconds) implements Event {
    private static final Limits SECONDS = new Limits("gust.seconds", 0.05f, 60f);

    public static final MapCodec<Gust> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Force.CODEC.fieldOf("force").forGetter(Gust::force),
            SECONDS.codec().fieldOf("seconds").forGetter(Gust::seconds)
    ).apply(instance, Gust::new));

    public Gust {
        Objects.requireNonNull(force, "gust.force");
        SECONDS.check(seconds);
    }

    /** The force's media. */
    @Override
    public List<ResourceKey<Medium>> media() {
        return force.media();
    }

    @Override
    public ResourceLocation type() {
        return Events.GUST;
    }
}
