package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Objects;
import java.util.Optional;

/**
 * A medium's look changed for one source, placed field or puff, everything else kept: how a potion mod gets thirty
 * colours of cloud from one medium. Written beside the medium it changes, {@code "medium": "potions:cloud",
 * "tint": "#AA22FF"}, with {@code "emission"} as a medium's own ({@link Emission}).
 *
 * <ul>
 *   <li>{@code tint}: the albedo in place of the medium's, {@code 0xRRGGBB}. A medium whose emission takes its albedo
 *   (an emission with no colour) glows in the tint too.</li>
 *   <li>{@code emission}: light of its own in place of the medium's.</li>
 * </ul>
 *
 * <p>Each distinct variant is a kind of gas of its own to the engine: it moves, spreads and fades as its medium does,
 * and is retuned with it, but it is simulated and drawn beside the medium's other variants, not mixed with them, so
 * where two colours meet both are seen, not a blend. Kinds are few (the engine holds 32 near the camera, the most
 * important first), so the engine rounds a variant's colours and strength to steps too small to see, and variants
 * that round alike are one kind. A variant is still its medium wherever a medium is named: an event, a force or a
 * query naming the medium takes in every variant of it.
 *
 * @param tint     the albedo in place of the medium's; empty to keep it
 * @param emission light of its own in place of the medium's; empty to keep it
 */
public record Variant(Optional<Integer> tint, Optional<Emission> emission) {
    /** The medium as it is. */
    public static final Variant NONE = new Variant(Optional.empty(), Optional.empty());

    /** {@code tint} and {@code emission} beside the other fields of a source, placed field or puff; both optional. */
    public static final MapCodec<Variant> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            VolumetricsCodecs.RGB.optionalFieldOf("tint").forGetter(Variant::tint),
            Emission.CODEC.optionalFieldOf("emission").forGetter(Variant::emission)
    ).apply(instance, Variant::new));

    public Variant {
        Objects.requireNonNull(tint, "tint").ifPresent(rgb -> VolumetricsCodecs.requireRgb(rgb, "tint"));
        Objects.requireNonNull(emission, "emission");
    }

    /** The albedo {@code rgb}, {@code 0xRRGGBB}, in place of the medium's. */
    public static Variant tint(int rgb) {
        return new Variant(Optional.of(rgb), Optional.empty());
    }

    /** The same with light of its own in place of the medium's. */
    public Variant withEmission(Emission emission) {
        return new Variant(tint, Optional.of(emission));
    }

    /** Whether it changes nothing: the medium itself. */
    public boolean isNone() {
        return tint.isEmpty() && emission.isEmpty();
    }
}
