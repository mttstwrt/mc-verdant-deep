package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Objects;
import java.util.Optional;

/**
 * Light a medium gives off of its own, whatever lights it: embers, a glowing potion, a will-o'-the-wisp. Written
 * {@code "emission": {"color": "#FF8040", "strength": 0.2}}.
 *
 * @param color    {@code 0xRRGGBB}; empty for the medium's albedo
 * @param strength how bright, 0 to 4: at 1 the gas shines as brightly as the colour on its own
 */
public record Emission(Optional<Integer> color, float strength) {
    /** No light of its own. */
    public static final Emission NONE = new Emission(Optional.empty(), 0f);

    public static final Codec<Emission> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            VolumetricsCodecs.RGB.optionalFieldOf("color").forGetter(Emission::color),
            Ranges.EMISSION_STRENGTH.codec().fieldOf("strength").forGetter(Emission::strength)
    ).apply(instance, Emission::new));

    public Emission {
        Objects.requireNonNull(color, "color").ifPresent(rgb -> VolumetricsCodecs.requireRgb(rgb, "optics.emission.color"));
        Ranges.EMISSION_STRENGTH.check(strength);
    }

    /** Light of the medium's own albedo, at {@code strength}. */
    public static Emission ofAlbedo(float strength) {
        return new Emission(Optional.empty(), strength);
    }

    /** Light of {@code rgb}, {@code 0xRRGGBB}, at {@code strength}. */
    public static Emission of(int rgb, float strength) {
        return new Emission(Optional.of(rgb), strength);
    }
}
