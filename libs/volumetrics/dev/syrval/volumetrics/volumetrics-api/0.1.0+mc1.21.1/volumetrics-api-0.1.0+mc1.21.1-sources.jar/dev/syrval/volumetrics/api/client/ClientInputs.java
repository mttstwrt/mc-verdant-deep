package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.Experimental;
import dev.syrval.volumetrics.api.Handle;
import dev.syrval.volumetrics.api.Inputs;
import dev.syrval.volumetrics.api.Owner;
import dev.syrval.volumetrics.api.medium.Medium;
import net.minecraft.resources.ResourceKey;

/**
 * What a mod adds on this client only, to one client level ({@link Owner#client}): nothing is sent anywhere, and
 * other players do not see it. For effects the client alone knows of, such as a held item's or a screen's. Gas a
 * server should show to everyone is added with {@link Owner#server} instead. Scopes are checked on the client thread;
 * an entity scope also ends when the entity goes out of tracking range.
 */
public interface ClientInputs extends Inputs {
    /**
     * Calls the listener where the density of a medium within {@code reach} blocks of the camera crosses
     * {@code threshold}, as this client's queries answer it (its simulation near the camera, and the placed fields of
     * the medium). Until the handle is closed, by its scope's end (it is the level's), or by {@code closeAll}.
     * {@link Handle#update} changes what it watches (places it had gone above are told they are under, with a density
     * of {@code NaN}); {@link Handle#moveTo} throws {@link UnsupportedOperationException}: a trigger is centred on the
     * camera.
     *
     * <p>Sampling: every 2 blocks (the simulation's finest cells), at the cells' middles, in a scattered order that
     * covers the reach again and again, a pass in 4 ticks at the quickest. All triggers of the client share a budget of
     * field evaluations a tick, so a trigger over a placed field may take longer to cover a large reach; reads of the
     * simulation cost little and are bounded apart. A place is told at most once every half second. While neither the
     * medium's simulated gas at the threshold nor a placed field of it is near the camera, a trigger costs a few checks
     * a tick and samples nothing.
     *
     * <p>Any thread; the listener is called on the client thread ({@link DensityListener}).
     *
     * @throws IllegalArgumentException for a threshold or reach out of range ({@link DensityTrigger})
     */
    @Experimental
    Handle<DensityTrigger> onDensity(ResourceKey<Medium> medium, float threshold, float reach, DensityListener listener);
}
