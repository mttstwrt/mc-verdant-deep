package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.Inputs;
import dev.syrval.volumetrics.api.Owner;

/**
 * What a mod adds on this client only, to one client level ({@link Owner#client}): nothing is sent anywhere, and
 * other players do not see it. For effects the client alone knows of, such as a held item's or a screen's. Gas a
 * server should show to everyone is added with {@link Owner#server} instead. Scopes are checked on the client thread;
 * an entity scope also ends when the entity goes out of tracking range.
 */
public interface ClientInputs extends Inputs {
}
