/**
 * Conditions: named numbers from 0 to 1 per column of a level, from what every client and the server share (the
 * time, the weather, the biomes and blocks of loaded chunks), which fields read with a
 * {@code volumetrics:condition} node and sources with their {@code conditions}. {@link
 * dev.syrval.volumetrics.api.condition.Conditions} names the library's built-in ones, which data uses without code;
 * {@link dev.syrval.volumetrics.api.condition.ConditionProvider} is the code tier, registered through a mod's
 * {@link dev.syrval.volumetrics.api.Owner#registerCondition}. Both sides: a client evaluates its fields with them,
 * and the server the fields it answers for.
 */
package dev.syrval.volumetrics.api.condition;
