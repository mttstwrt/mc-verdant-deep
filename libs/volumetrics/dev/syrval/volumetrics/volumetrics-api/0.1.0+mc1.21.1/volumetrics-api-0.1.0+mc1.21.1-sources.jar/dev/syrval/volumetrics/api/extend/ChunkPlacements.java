package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
import dev.syrval.volumetrics.api.Scope;
import dev.syrval.volumetrics.api.field.PlacedField;
import dev.syrval.volumetrics.api.force.Force;
import dev.syrval.volumetrics.api.placement.Attachment;
import dev.syrval.volumetrics.api.source.Source;
import java.util.concurrent.CompletionStage;

/**
 * Where a {@link PlacementRule} adds what one chunk holds, on the rule's side: through its owner's
 * {@link dev.syrval.volumetrics.api.Inputs} for the chunk's level, as the rule's mod. An add is checked and compiled as
 * there; one the library cannot place (a medium the server's data lacks, a shape too large) is left out and logged once
 * per rule and reason, and the rule goes on. No handle comes back: the library ends what a rule added.
 *
 * <p>Where each goes is the attachment's affair and need not be in the chunk (a pull anchored on an axis outside it, a
 * field written in world coordinates at {@code Attachment.at(Vec3.ZERO)}); how long it lasts is the chunk's, so what
 * belongs to a part of the world is best added by the rule for the chunk that part is in. Reused by the library: works
 * only during the call it is given to.
 */
@Experimental
public interface ChunkPlacements {
    /** Until the chunk unloads. */
    void add(Source source, Attachment attachment);

    /**
     * With a narrower scope: a {@link Scope#block} of a block in this chunk (until the block goes, or the chunk
     * unloads), or a {@link Scope#timed} one (for that long, whether or not the chunk stays: a burst of gas where the
     * chunk loaded).
     *
     * @throws IllegalArgumentException for another scope, or a block outside the chunk
     */
    void add(Source source, Attachment attachment, Scope scope);

    /** Until the chunk unloads. */
    void add(Force force, Attachment attachment);

    /** @throws IllegalArgumentException as {@link #add(Source, Attachment, Scope)} does */
    void add(Force force, Attachment attachment, Scope scope);

    /** Until the chunk unloads. */
    void add(PlacedField field, Attachment attachment);

    /** @throws IllegalArgumentException as {@link #add(Source, Attachment, Scope)} does */
    void add(PlacedField field, Attachment attachment, Scope scope);

    /**
     * Finishes this chunk later: once {@code ready} completes, on the level's thread at the end of a tick, the library
     * calls {@code then} with its value and the chunk, if the chunk is still loaded and has not unloaded since, and
     * the rule is still the one registered; otherwise never. For work too slow for a chunk load, done off the level's
     * thread: the rule starts it (or finds it started, for another chunk of the same structure) and returns. A stage
     * that fails is logged once per rule and places nothing.
     */
    <T> void later(CompletionStage<T> ready, PlacementRule.Then<? super T> then);
}
