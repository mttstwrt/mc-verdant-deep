package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.field.Ambient;
import dev.syrval.volumetrics.api.field.Field;
import dev.syrval.volumetrics.api.force.ForcePlacement;
import dev.syrval.volumetrics.api.medium.Edge;
import dev.syrval.volumetrics.api.medium.Medium;
import dev.syrval.volumetrics.api.source.SourcePlacement;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * The datapack registries of Volumetrics. Each loads with the world from {@code data/<namespace>/volumetrics/<name>/}
 * and is sent to clients, so a server's datapacks decide what its players see. Look an entry up through the level's
 * registry access, as with any datapack registry.
 */
public final class VolumetricsRegistries {
    /** Kinds of gas: {@code data/<namespace>/volumetrics/medium/<name>.json}. */
    public static final ResourceKey<Registry<Medium>> MEDIUM = key("medium");
    /**
     * Edge presets a medium's detail names: {@code data/<namespace>/volumetrics/edge/<name>.json}. The library ships
     * {@code volumetrics:none}, {@code smooth}, {@code puffy}, {@code billowing}, {@code wispy}, {@code ghostly} and
     * {@code churning}.
     */
    public static final ResourceKey<Registry<Edge>> EDGE = key("edge");
    /**
     * Named fields, which other fields name with a {@code volumetrics:ref} node or by their id alone:
     * {@code data/<namespace>/volumetrics/field/<name>.json}, holding one field node.
     */
    public static final ResourceKey<Registry<Field>> FIELD = key("field");
    /**
     * Fields of gas a dimension always has, placed by data: a weather mod's cloud layers, a valley's fog.
     * {@code data/<namespace>/volumetrics/ambient/<name>.json}; see {@link Ambient}.
     */
    public static final ResourceKey<Registry<Ambient>> AMBIENT = key("ambient");
    /**
     * Sources placed by a rule: {@code data/<namespace>/volumetrics/source/<name>.json}; see {@link SourcePlacement}.
     */
    public static final ResourceKey<Registry<SourcePlacement>> SOURCE = key("source");
    /**
     * Forces placed by a rule: {@code data/<namespace>/volumetrics/force/<name>.json}; see {@link ForcePlacement}.
     */
    public static final ResourceKey<Registry<ForcePlacement>> FORCE = key("force");

    private VolumetricsRegistries() {}

    private static <T> ResourceKey<Registry<T>> key(String name) {
        return ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath("volumetrics", name));
    }
}
