package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Wisps drawn into a medium's gas, finer than the simulation can hold, so that its body does not read as blocks.
 * Drawn only; the simulation does not see them.
 *
 * @param scale    wisps per block: 0.1 gives features about ten blocks across
 * @param speed    blocks per second the pattern drifts, the way the gas moves
 * @param strength 0 leaves the gas smooth, 1 lets the wisps cut it down to nothing in places
 */
public record Wisps(float scale, float speed, float strength) {
    public static final Wisps DEFAULT = new Wisps(0.12f, 0.4f, 0.5f);

    public static final Codec<Wisps> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.WISPS_SCALE.codec().optionalFieldOf("scale", DEFAULT.scale).forGetter(Wisps::scale),
            Ranges.WISPS_SPEED.codec().optionalFieldOf("speed", DEFAULT.speed).forGetter(Wisps::speed),
            Ranges.WISPS_STRENGTH.codec().optionalFieldOf("strength", DEFAULT.strength).forGetter(Wisps::strength)
    ).apply(instance, Wisps::new));

    public Wisps {
        Ranges.WISPS_SCALE.check(scale);
        Ranges.WISPS_SPEED.check(speed);
        Ranges.WISPS_STRENGTH.check(strength);
    }
}
