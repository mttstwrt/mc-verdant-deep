package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.util.StringRepresentable;

/**
 * How far the point is above the world's surface in its column, in blocks: its height less the top of the column's
 * ground, negative below it. {@code {"type": "volumetrics:height_above_surface"}}, optionally with
 * {@code "surface": "motion_blocking"} for another surface. What a fog that follows the land takes as its profile's
 * input: {@code linear} over it from 0 to 12 lies in the valleys and over the plains alike.
 *
 * <p>The height is the point's own, moved by the space nodes above it as {@link Altitude} is; the surface is read at
 * the point's world column, so it stays where it is in the world, as a {@link Condition} does. Beyond the chunks a side
 * has loaded the surface is taken to be at the level's sea level.
 *
 * <p>Not pure maths ({@link #cpuOnly}): the simulation and the server read the world's heightmaps, and a renderer only
 * has them if it says so ({@code volumetrics:drawn_height_above_surface}, {@code Capabilities.has}; 26.3's does, by
 * the chunks round the camera). Where it does not, a {@code drawn} placed field naming it is refused, logged with its id,
 * and a {@code simulated} one is simulated near the camera and not drawn beyond it. Sources' and forces' shapes cannot
 * name it at all: they are fixed in place.
 */
public record HeightAboveSurface(Surface surface) implements Field {
    public static final HeightAboveSurface GROUND = new HeightAboveSurface(Surface.MOTION_BLOCKING_NO_LEAVES);
    public static final MapCodec<HeightAboveSurface> MAP_CODEC = Surface.CODEC
            .optionalFieldOf("surface", Surface.MOTION_BLOCKING_NO_LEAVES).xmap(HeightAboveSurface::new, HeightAboveSurface::surface);

    public HeightAboveSurface {
        Objects.requireNonNull(surface, "height_above_surface.surface");
    }

    @Override
    public FieldType type() {
        return FieldTypes.HEIGHT_ABOVE_SURFACE;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return Float.NEGATIVE_INFINITY;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean cpuOnly() {
        return true;
    }

    /**
     * Which blocks make the surface: the top of the highest such block of the column, as the game's heightmaps of the
     * same names keep it.
     */
    public enum Surface implements StringRepresentable {
        /**
         * The ground under the trees: blocks that stop movement, and water and other fluids, but not leaves. What a fog
         * that lies on the land wants, filling a forest between its trunks. The default.
         */
        MOTION_BLOCKING_NO_LEAVES("motion_blocking_no_leaves"),
        /** The same with leaves: the tops of the trees' crowns. */
        MOTION_BLOCKING("motion_blocking"),
        /** Any block but air: grass, flowers and snow layers too. */
        WORLD_SURFACE("world_surface");

        public static final Codec<Surface> CODEC = StringRepresentable.fromEnum(Surface::values);

        private final String name;

        Surface(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }
}
