package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;

/**
 * The height of the point, its world y in blocks: {@code {"type": "volumetrics:altitude"}}. What profiles take by
 * default, so a field thins with height.
 */
public record Altitude() implements Field {
    public static final Altitude INSTANCE = new Altitude();
    public static final MapCodec<Altitude> MAP_CODEC = MapCodec.unit(INSTANCE);

    @Override
    public FieldType type() {
        return FieldTypes.ALTITUDE;
    }

    /** Above 0 only above y 0. */
    @Override
    public FieldBounds bounds() {
        return FieldBounds.layer(0, Double.POSITIVE_INFINITY);
    }

    @Override
    public float minimum() {
        return Float.NEGATIVE_INFINITY;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }
}
