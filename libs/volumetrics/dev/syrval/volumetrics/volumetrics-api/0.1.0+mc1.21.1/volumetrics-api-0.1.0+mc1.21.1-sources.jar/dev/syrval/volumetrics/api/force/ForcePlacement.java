package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.placement.PlacementRule;
import java.util.Objects;

/**
 * A force placed by data: an entry of the {@link dev.syrval.volumetrics.api.VolumetricsRegistries#FORCE} registry,
 * {@code data/<namespace>/volumetrics/force/<name>.json}, a {@link Force} with the rule that says where it is. Loaded
 * with the world and sent to clients. The level's wind is not placed by a rule (it is everywhere): a file naming
 * {@code volumetrics:level_wind} is refused.
 *
 * <pre>{@code
 * { "type": "volumetrics:fan", "speed": 3, "range": 10, "spread": 25, "direction": { "y": 1 },
 *   "rule": { "type": "volumetrics:block", "blocks": "minecraft:magma_block", "offset": { "y": 1 } } }
 * }</pre>
 */
public record ForcePlacement(Force force, PlacementRule rule) {
    public static final Codec<ForcePlacement> CODEC = RecordCodecBuilder.<ForcePlacement>create(instance -> instance.group(
            Force.MAP_CODEC.forGetter(ForcePlacement::force),
            PlacementRule.CODEC.fieldOf("rule").forGetter(ForcePlacement::rule)
    ).apply(instance, ForcePlacement::ofCodec)).validate(placement -> placement == null
            ? DataResult.error(() -> "The level's wind is everywhere and is not placed by a rule") : DataResult.success(placement));

    public ForcePlacement {
        Objects.requireNonNull(force, "force");
        Objects.requireNonNull(rule, "rule");
        if (force.kind().levelWide()) {
            throw new IllegalArgumentException("The level's wind is everywhere and is not placed by a rule");
        }
    }

    private static ForcePlacement ofCodec(Force force, PlacementRule rule) {
        return force.kind().levelWide() ? null : new ForcePlacement(force, rule);
    }
}
