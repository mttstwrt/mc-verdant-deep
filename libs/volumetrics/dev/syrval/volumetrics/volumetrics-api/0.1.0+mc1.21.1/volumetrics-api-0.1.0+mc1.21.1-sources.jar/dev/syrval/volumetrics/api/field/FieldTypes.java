package dev.syrval.volumetrics.api.field;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * Every field node, by the {@code type} it is written with. A closed set, the same on both sides and in every
 * engine: a renderer that cannot evaluate a node says so through the field-program version it reports
 * ({@link dev.syrval.volumetrics.api.Capabilities#fieldProgramVersion}). One id is reserved for a node that comes
 * later: {@code volumetrics:air_in} (a box's air cells, CPU only); a field naming it fails to load until then.
 */
public final class FieldTypes {
    private static final Map<ResourceLocation, FieldType> TYPES = new LinkedHashMap<>();

    public static final FieldType CONSTANT = add("constant", Constant.MAP_CODEC);
    public static final FieldType ALTITUDE = add("altitude", Altitude.MAP_CODEC);
    public static final FieldType HEIGHT_ABOVE_SURFACE = add("height_above_surface", HeightAboveSurface.MAP_CODEC);
    public static final FieldType TIME = add("time", Time.MAP_CODEC);
    public static final FieldType CONDITION = add("condition", Condition.MAP_CODEC);
    public static final FieldType REF = add("ref", Ref.MAP_CODEC);
    public static final FieldType SPHERE = add("sphere", Sphere.MAP_CODEC);
    public static final FieldType BOX = add("box", Box.MAP_CODEC);
    public static final FieldType CYLINDER = add("cylinder", Cylinder.MAP_CODEC);
    public static final FieldType CAPSULE = add("capsule", Capsule.MAP_CODEC);
    public static final FieldType SLAB = add("slab", Slab.MAP_CODEC);
    public static final FieldType INSIDE = add("inside", Inside.MAP_CODEC);
    public static final FieldType SHELL = add("shell", Shell.MAP_CODEC);
    public static final FieldType EXPONENTIAL = add("exponential", Exponential.MAP_CODEC);
    public static final FieldType LINEAR = add("linear", Linear.MAP_CODEC);
    public static final FieldType GAUSSIAN = add("gaussian", Gaussian.MAP_CODEC);
    public static final FieldType NOISE = add("noise", Noise.MAP_CODEC);
    public static final FieldType COVERAGE = add("coverage", Coverage.MAP_CODEC);
    public static final FieldType CLAMP = add("clamp", Clamp.MAP_CODEC);
    public static final FieldType REMAP = add("remap", Remap.MAP_CODEC);
    public static final FieldType SMOOTHSTEP = add("smoothstep", Smoothstep.MAP_CODEC);
    public static final FieldType ADD = add("add", Add.MAP_CODEC);
    public static final FieldType MUL = add("mul", Mul.MAP_CODEC);
    public static final FieldType MIN = add("min", Min.MAP_CODEC);
    public static final FieldType MAX = add("max", Max.MAP_CODEC);
    public static final FieldType SMOOTH_MIN = add("smooth_min", SmoothMin.MAP_CODEC);
    public static final FieldType SMOOTH_MAX = add("smooth_max", SmoothMax.MAP_CODEC);
    public static final FieldType LERP = add("lerp", Lerp.MAP_CODEC);
    public static final FieldType TRANSLATE = add("translate", Translate.MAP_CODEC);
    public static final FieldType SCALE = add("scale", Scale.MAP_CODEC);
    public static final FieldType ROTATE_Y = add("rotate_y", RotateY.MAP_CODEC);
    public static final FieldType WARP = add("warp", Warp.MAP_CODEC);
    public static final FieldType PIECE_BOX = add("piece_box", PieceBox.MAP_CODEC);

    /** Ids kept for nodes that come later (see the class description). */
    public static final Set<ResourceLocation> RESERVED = Set.of(id("air_in"));

    /** A node's type by id. */
    static final Codec<FieldType> CODEC = ResourceLocation.CODEC.comapFlatMap(FieldTypes::get, FieldType::id);

    private FieldTypes() {}

    /** {@link Field#CODEC}: a node object by its type, or a named field's id for a {@link Ref}. */
    static Codec<Field> fieldCodec() {
        Codec<Field> nodes = CODEC.dispatch("type", Field::type, FieldType::codec);
        Codec<ResourceKey<Field>> ids = ResourceKey.codec(VolumetricsRegistries.FIELD);
        return Codec.either(ids, nodes).xmap(either -> either.map(Ref::new, field -> field),
                field -> field instanceof Ref ref ? Either.<ResourceKey<Field>, Field>left(ref.id())
                        : Either.<ResourceKey<Field>, Field>right(field));
    }

    /** Every node type, in the order of the spec's table. */
    public static Collection<FieldType> all() {
        return Collections.unmodifiableCollection(TYPES.values());
    }

    private static DataResult<FieldType> get(ResourceLocation id) {
        FieldType type = TYPES.get(id);
        if (type != null) {
            return DataResult.success(type);
        }
        if (RESERVED.contains(id)) {
            return DataResult.error(() -> "The field node " + id + " is not available yet");
        }
        return DataResult.error(() -> "Not a field node: " + id);
    }

    private static FieldType add(String name, MapCodec<? extends Field> codec) {
        FieldType type = new FieldType(id(name), codec);
        TYPES.put(type.id(), type);
        return type;
    }

    private static ResourceLocation id(String name) {
        return ResourceLocation.fromNamespaceAndPath("volumetrics", name);
    }
}
