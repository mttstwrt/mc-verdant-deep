package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.List;

/**
 * The product of its fields: each scales the rest, so a shape's {@link Inside} times a noise's {@link Coverage} is the
 * noise's patches within the shape. {@code {"type": "volumetrics:mul", "args": [{...}, {...}]}}.
 */
public record Mul(List<Field> args) implements Field {
    public static final MapCodec<Mul> MAP_CODEC = Check.args("mul.args", 1).fieldOf("args").xmap(Mul::new, Mul::args);

    public Mul {
        args = Check.args(args, 1, "mul.args");
    }

    @Override
    public FieldType type() {
        return FieldTypes.MUL;
    }

    /**
     * Within each field's bounds whose fellows are never negative: outside it, that field is 0 or less and the rest
     * do not turn the product's sign.
     */
    @Override
    public FieldBounds bounds() {
        if (Check.anyDistance(args)) {
            return FieldBounds.EVERYWHERE;
        }
        FieldBounds within = FieldBounds.EVERYWHERE;
        for (int i = 0; i < args.size(); i++) {
            boolean othersNotNegative = true;
            for (int j = 0; j < args.size(); j++) {
                othersNotNegative &= i == j || args.get(j).minimum() >= 0f;
            }
            if (othersNotNegative) {
                within = within.intersect(args.get(i).bounds());
            }
        }
        return within;
    }

    @Override
    public float minimum() {
        return range()[0];
    }

    @Override
    public float maximum() {
        return range()[1];
    }

    private float[] range() {
        float[] range = {1f, 1f};
        for (Field arg : args) {
            range = Check.product(range[0], range[1], arg.minimum(), arg.maximum());
        }
        return range;
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
