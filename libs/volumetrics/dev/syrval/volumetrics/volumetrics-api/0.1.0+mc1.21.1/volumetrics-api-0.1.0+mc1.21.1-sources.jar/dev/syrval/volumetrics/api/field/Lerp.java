package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * From one field to another by a third: {@code from} where {@code amount} is 0, {@code to} where it is 1, in a
 * straight line between. {@code {"type": "volumetrics:lerp", "from": {...}, "to": {...}, "amount": {...}}}.
 */
public record Lerp(Field from, Field to, Field amount) implements Field {
    public static final MapCodec<Lerp> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("from").forGetter(Lerp::from),
            Field.CODEC.fieldOf("to").forGetter(Lerp::to),
            Field.CODEC.fieldOf("amount").forGetter(Lerp::amount)
    ).apply(instance, Lerp::new));

    public Lerp {
        Objects.requireNonNull(from, "lerp.from");
        Objects.requireNonNull(to, "lerp.to");
        Objects.requireNonNull(amount, "lerp.amount");
    }

    private boolean amountWithin() {
        return amount.minimum() >= 0f && amount.maximum() <= 1f;
    }

    @Override
    public FieldType type() {
        return FieldTypes.LERP;
    }

    /** With an amount from 0 to 1, where either end is above 0. */
    @Override
    public FieldBounds bounds() {
        return amountWithin() && !from.distance() && !to.distance() ? from.bounds().union(to.bounds()) : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return amountWithin() ? Math.min(from.minimum(), to.minimum()) : Float.NEGATIVE_INFINITY;
    }

    @Override
    public float maximum() {
        return amountWithin() ? Math.max(from.maximum(), to.maximum()) : Float.POSITIVE_INFINITY;
    }

    @Override
    public List<Field> children() {
        return List.of(from, to, amount);
    }
}
