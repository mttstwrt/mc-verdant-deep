package dev.syrval.volumetrics.api.condition;

import dev.syrval.volumetrics.api.Experimental;
import net.minecraft.world.level.Level;

/**
 * Works out a condition of a column of a level at the moment: a mod's own reading of the world, registered under an id
 * with {@link dev.syrval.volumetrics.api.Owner#registerCondition}, for fields and sources that name the id.
 *
 * <p>The engine keeps each id's values in columns of 8 by 8 blocks and asks the provider a few columns at a time, on
 * each side that reads the id. A client keeps the columns round the camera, 2048 blocks across, and asks about a
 * thousand a tick over all its ids: the camera's column every tick, then the columns that came into range, nearest
 * first, then all of them in turn, so a full pass takes a few seconds; a column not asked yet has the camera's value.
 * A server keeps only the columns something on it read in the last half minute, asked when first read and then again
 * in turn, about a thousand a tick. Between column centres the value is blended, the same on both sides. A value
 * outside 0 to 1 is clamped, NaN counts as 1, and a provider that throws counts as 1 (logged once).
 *
 * <p>Called on the thread of the level it is given: the client thread for a client level, the server thread for a
 * server level. In a single-player game both run at once, each with its own level, so a provider keeps no mutable
 * state of its own between calls, or makes it safe for two threads.
 */
@Experimental
@FunctionalInterface
public interface ConditionProvider {
    /**
     * The condition at one column. Use only what every client of the level and the server have alike: the time, the
     * weather, and the biomes and blocks of loaded chunks. Beyond the loaded chunks
     * ({@code level.hasChunk(blockX >> 4, blockZ >> 4)} is false) only what holds for the whole level is known, so
     * return the provider's own fallback there: the column is asked again later, when it may be loaded. Called about a
     * thousand times a tick, so keep it cheap.
     *
     * @param level  the level, a client's or the server's
     * @param blockX the block at the column's middle, east
     * @param blockZ the same, south
     * @return 0 (none) to 1 (all of it)
     */
    float value(Level level, int blockX, int blockZ);

    /**
     * Whether the value is the same in every column of a level at a moment (the weather, the time), so the engine asks
     * once a tick for the whole level rather than column by column; it then passes the column of the camera, or of
     * the first point read on the server. False unless overridden.
     */
    default boolean levelWide() {
        return false;
    }
}
