package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Importance;
import java.util.List;
import java.util.Objects;

/**
 * One kind of gas: how it moves, how it meets light, the detail drawn into it, and who knows where it is. Datapacks
 * define media in {@code data/<namespace>/volumetrics/medium/<name>.json} (registry
 * {@link dev.syrval.volumetrics.api.VolumetricsRegistries#MEDIUM}); a mod may also build one in Java, which gives the
 * same record.
 *
 * <p>Numbers are in world units: blocks, seconds, and density, where 1 is pure gas. How much gas a cell can hold is the
 * engine's business, not the medium's. The engine compiles a medium once, when the registry loads or the medium is
 * added; nothing here is read while the gas is simulated or drawn.
 *
 * <pre>{@code
 * {
 *   "motion": { "diffusion": 0.35, "decay": 0.03, "drift": { "y": -2 } },
 *   "optics": { "extinction": 0.4, "albedo": "#DCE6EE", "lamps": 0.5 },
 *   "detail": { "wisps": { "scale": 0.12, "speed": 0.6, "strength": 0.6 }, "edge": "volumetrics:billowing" },
 *   "converts": [ { "into": "volumetrics:mist", "rate": 0.12 } ]
 * }
 * }</pre>
 *
 * @param authority  who knows where the gas is; {@link Authority#COSMETIC} unless written
 * @param importance what goes first when the engine cannot draw every kind of gas near the camera
 * @param motion     how it moves
 * @param optics     how it meets light
 * @param detail     what is drawn over its density
 * @param converts   what it turns into as it goes ({@link Conversion}); none unless written
 */
public record Medium(Authority authority, Importance importance, Motion motion, Optics optics, Detail detail,
                     List<Conversion> converts) {
    public static final Codec<Medium> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Authority.CODEC.optionalFieldOf("authority", Authority.COSMETIC).forGetter(Medium::authority),
            Importance.CODEC.optionalFieldOf("importance", Importance.NORMAL).forGetter(Medium::importance),
            Motion.CODEC.fieldOf("motion").forGetter(Medium::motion),
            Optics.CODEC.fieldOf("optics").forGetter(Medium::optics),
            Detail.CODEC.optionalFieldOf("detail", Detail.DEFAULT).forGetter(Medium::detail),
            Conversion.CODEC.listOf().optionalFieldOf("converts", List.of()).forGetter(Medium::converts)
    ).apply(instance, Medium::new));

    public Medium {
        Objects.requireNonNull(authority, "authority");
        Objects.requireNonNull(importance, "importance");
        Objects.requireNonNull(motion, "motion");
        Objects.requireNonNull(optics, "optics");
        Objects.requireNonNull(detail, "detail");
        converts = List.copyOf(converts);
    }

    /** Cosmetic gas of normal importance with the default detail. */
    public Medium(Motion motion, Optics optics) {
        this(Authority.COSMETIC, Importance.NORMAL, motion, optics, Detail.DEFAULT, List.of());
    }

    public Medium withAuthority(Authority authority) {
        return new Medium(authority, importance, motion, optics, detail, converts);
    }

    public Medium withImportance(Importance importance) {
        return new Medium(authority, importance, motion, optics, detail, converts);
    }

    public Medium withOptics(Optics optics) {
        return new Medium(authority, importance, motion, optics, detail, converts);
    }

    public Medium withDetail(Detail detail) {
        return new Medium(authority, importance, motion, optics, detail, converts);
    }

    public Medium withConverts(List<Conversion> converts) {
        return new Medium(authority, importance, motion, optics, detail, converts);
    }
}
