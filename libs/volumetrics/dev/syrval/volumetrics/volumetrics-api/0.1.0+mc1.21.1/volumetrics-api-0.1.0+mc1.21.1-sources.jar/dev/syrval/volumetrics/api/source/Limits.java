package dev.syrval.volumetrics.api.source;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

/** The bounds of a source file's numbers, named as written, so a file and a record built in Java fail alike. */
record Limits(String name, float min, float max) {
    static final Limits RATE = new Limits("source.rate", 0f, 64f);
    static final Limits FLOW = new Limits("source.flow", 0f, 65536f);
    static final Limits SPEED = new Limits("source.velocity", -16f, 16f);
    static final Limits SECONDS = new Limits("schedule seconds", 0f, 1e6f);
    static final Limits SCALE = new Limits("schedule.curve value", 0f, 16f);

    Codec<Float> codec() {
        return Codec.FLOAT.validate(value -> within(value) ? DataResult.success(value) : DataResult.error(() -> message(value)));
    }

    float check(float value) {
        if (!within(value)) {
            throw new IllegalArgumentException(message(value));
        }
        return value;
    }

    private boolean within(float value) {
        return value >= min && value <= max;
    }

    private String message(float value) {
        return name + " must be from " + min + " to " + max + ", got " + value;
    }
}
