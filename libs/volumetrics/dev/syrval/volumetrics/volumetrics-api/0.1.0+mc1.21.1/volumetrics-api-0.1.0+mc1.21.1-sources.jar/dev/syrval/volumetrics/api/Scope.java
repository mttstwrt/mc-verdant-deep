package dev.syrval.volumetrics.api;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;

/**
 * How long something a mod adds lasts, given when it is added; its {@link Handle} stops being alive when the scope
 * ends. Every scope also ends with its level at the latest, so nothing outlives a world or a dimension change, and the
 * engine saves nothing: a mod re-adds what it owns when its reason comes back, as block entities do.
 *
 * <p>A scope is checked where the thing was added: a client's scopes on the client, a server's on the server. Ending
 * one costs nothing while nothing happens: chunks and blocks are checked when they unload or change, entities when
 * they leave, and only timed scopes are looked at every tick.
 *
 * <p>Immutable values; the engine tells them apart with a switch over the five records.
 *
 * <p>More scopes may come in a minor version of the API: a mod's own {@code switch} over them needs a {@code default}
 * branch ({@code docs/API-CHANGES.md} in the library).
 */
public sealed interface Scope permits Scope.OfLevel, Scope.OfChunk, Scope.OfBlock, Scope.OfEntity, Scope.Timed {
    /** Until the level unloads. The default. */
    static Scope level() {
        return OfLevel.INSTANCE;
    }

    /**
     * Until the chunk unloads, or the level does. A mod re-adds it when the chunk loads again. Nothing at all if the
     * chunk is not loaded when it is added.
     */
    static Scope chunk(ChunkPos chunk) {
        return new OfChunk(chunk);
    }

    /**
     * Until another block takes the place of the one at {@code pos} when it is added (a change of state alone keeps
     * it), or its chunk unloads. Nothing at all if, when it is added, there is no loaded block there.
     */
    static OfBlock block(BlockPos pos) {
        return new OfBlock(pos, null);
    }

    /**
     * Until the state of the block at {@code pos} stops passing {@code holds} (a campfire put out, a furnace gone cold),
     * or its chunk unloads. {@code holds} is asked when it is added and each time that block changes, on the thread of
     * the side it was added on; it must be quick and must not touch the level. Nothing at all if it fails when added.
     */
    static OfBlock block(BlockPos pos, Predicate<BlockState> holds) {
        return new OfBlock(pos, Objects.requireNonNull(holds, "holds"));
    }

    /**
     * Until the entity is removed or this side stops tracking it: on a server when it is removed or unloaded with its
     * chunk, on a client also when it goes out of the player's tracking range.
     */
    static Scope entity(Entity entity) {
        return new OfEntity(entity);
    }

    /** For {@code seconds} of the level's game time after it is added (a paused game pauses it), or until the level unloads. */
    static Timed timed(double seconds) {
        return new Timed(seconds);
    }

    record OfLevel() implements Scope {
        private static final OfLevel INSTANCE = new OfLevel();
    }

    record OfChunk(ChunkPos chunk) implements Scope {
        public OfChunk {
            Objects.requireNonNull(chunk, "chunk");
        }
    }

    /**
     * @param holds what the block's state must pass, or null for the block there when it is added to stay
     */
    record OfBlock(BlockPos pos, @Nullable Predicate<BlockState> holds) implements Scope {
        /** Keeps its own copy, so a mutable position the caller goes on moving changes nothing. */
        public OfBlock {
            pos = Objects.requireNonNull(pos, "pos").immutable();
        }
    }

    /** Holds the entity itself; the scope ends, and the engine lets go of it, when the entity goes. */
    record OfEntity(Entity entity) implements Scope {
        public OfEntity {
            Objects.requireNonNull(entity, "entity");
        }
    }

    record Timed(double seconds) implements Scope {
        public Timed {
            if (!(seconds > 0) || Double.isInfinite(seconds)) {
                throw new IllegalArgumentException("A timed scope needs a finite number of seconds above 0, not " + seconds);
            }
        }
    }
}
