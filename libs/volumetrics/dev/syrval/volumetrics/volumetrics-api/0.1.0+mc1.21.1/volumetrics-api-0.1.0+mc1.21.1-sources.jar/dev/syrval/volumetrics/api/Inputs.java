package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.event.Event;
import dev.syrval.volumetrics.api.field.PlacedField;
import dev.syrval.volumetrics.api.force.Force;
import dev.syrval.volumetrics.api.placement.Attachment;
import dev.syrval.volumetrics.api.source.Source;
import net.minecraft.world.level.Level;

/**
 * Where a mod adds sources, forces and placed fields to one level, on one side: {@link Owner#client} for what only
 * this client sees, {@link Owner#server} for what the server places for everyone. Each add returns the {@link Handle}
 * that changes, moves and removes it, counted against the owner, and takes a {@link Scope}, {@link Scope#level} when
 * none is given. Nothing added is saved with the world.
 *
 * <p>Any thread. An add checks and compiles the definition on the calling thread, so a mistake is thrown there; the
 * engine places it at its next step or tick. An add the medium's authority does not allow (a source of an
 * {@code analytic} medium anywhere, of a {@code gameplay} medium on a client) is refused: the handle returned is not
 * alive and the refusal is logged once. Once the level has unloaded, every add returns a handle that is not alive.
 *
 * <p>Where each is put: a source's shape and a force's region are measured from the attachment's anchor and turned by
 * its frame ({@link Attachment}); a placed field's tree is moved by the anchor and not turned, so a field written in
 * world coordinates goes at {@code Attachment.at(Vec3.ZERO)}. An input attached to an entity follows it and ends when
 * the entity goes, whatever its scope. A {@code level_wind} force blows over the whole level wherever it is attached;
 * only a server adds one.
 */
public interface Inputs {
    Owner owner();

    Level level();

    /**
     * @throws IllegalArgumentException if its medium or a named field is missing, its shape is unbounded or too large,
     *                                  or a program is over the engine's limits
     */
    Handle<Source> add(Source source, Attachment attachment, Scope scope);

    /** For the level's lifetime. */
    default Handle<Source> add(Source source, Attachment attachment) {
        return add(source, attachment, Scope.level());
    }

    /**
     * @throws IllegalArgumentException if a named field is missing or a program is over the engine's limits, or, on a
     *                                  client, for a {@code level_wind} force
     */
    Handle<Force> add(Force force, Attachment attachment, Scope scope);

    /** For the level's lifetime. */
    default Handle<Force> add(Force force, Attachment attachment) {
        return add(force, attachment, Scope.level());
    }

    /** @throws IllegalArgumentException if its medium or a named field is missing, or it is over the engine's limits */
    Handle<PlacedField> add(PlacedField field, Attachment attachment, Scope scope);

    /** For the level's lifetime. */
    default Handle<PlacedField> add(PlacedField field, Attachment attachment) {
        return add(field, attachment, Scope.level());
    }

    /**
     * Fires a one-shot {@link Event} at the attachment's anchor as it is now (an event does not follow an entity, and is
     * not turned by it). Nothing to hold: an event cannot be taken back, and one with a duration runs it out.
     *
     * <p>From a server: stamped with the level's game time and sent to the players tracking the anchor's chunk now. Each
     * applies it at that time on its own simulation: held if it arrives early, applied at once if late, and left out if
     * it arrives after the place would have healed (later than the event's own duration plus two seconds; a gust once
     * it would be over). Nobody who arrives later gets it, as with any disturbance of cosmetic gas. Never cut by a
     * client's caps or settings. From a client: applied by this client alone, at its next step.
     *
     * <p>Only cosmetic media change. A {@link dev.syrval.volumetrics.api.event.Puff} of an {@code analytic} or
     * {@code gameplay} medium is refused (logged once, as a source of one is); the other events pass over such media,
     * whatever they name. Once the level has unloaded, nothing happens.
     *
     * @throws IllegalArgumentException if its medium or a named field is missing, its shape is unbounded or too large,
     *                                  a program is over the engine's limits, or a gust's force is {@code level_wind}
     */
    void fire(Event event, Attachment attachment);
}
