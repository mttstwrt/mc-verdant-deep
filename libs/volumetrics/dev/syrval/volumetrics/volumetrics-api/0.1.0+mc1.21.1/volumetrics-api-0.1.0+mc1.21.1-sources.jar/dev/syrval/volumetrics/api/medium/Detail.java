package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Experimental;
import java.util.Objects;
import java.util.Optional;

/**
 * Detail drawn over a medium's simulated density, finer than the simulation holds. Drawn only: it changes how the gas
 * looks, never where it goes. The {@code detail} object of a medium file. Each slot is drawn the same way for every
 * medium, so a renderer keeps one row of numbers per kind of gas and needs no branch per medium.
 *
 * @param wisps the wisps cut into the gas
 * @param edge  how its edge is shaped
 * @param flow  billowing carried by the flow; reserved, see {@link Flow}
 */
public record Detail(Wisps wisps, EdgeChoice edge, @Experimental Optional<Flow> flow) {
    /** The default wisps, no shaped edge. */
    public static final Detail DEFAULT = new Detail(Wisps.DEFAULT, EdgeChoice.NONE, Optional.empty());

    public static final Codec<Detail> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Wisps.CODEC.optionalFieldOf("wisps", Wisps.DEFAULT).forGetter(Detail::wisps),
            EdgeChoice.CODEC.optionalFieldOf("edge", EdgeChoice.NONE).forGetter(Detail::edge),
            Flow.CODEC.optionalFieldOf("flow").forGetter(Detail::flow)
    ).apply(instance, Detail::new));

    public Detail {
        Objects.requireNonNull(wisps, "wisps");
        Objects.requireNonNull(edge, "edge");
        Objects.requireNonNull(flow, "flow");
    }

    /** These wisps and this edge. */
    public Detail(Wisps wisps, EdgeChoice edge) {
        this(wisps, edge, Optional.empty());
    }
}
