package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.world.phys.Vec3;

/**
 * How a medium's gas moves, in physical terms each engine maps to its own numbers. The {@code motion} object of a
 * medium file.
 *
 * @param diffusion   square blocks per second: how fast the gas spreads from where it is dense to where it is thin
 * @param decay       the share of the gas lost each second
 * @param buoyancy    rising or sinking with the air around it; empty for gas that floats nowhere in particular
 * @param drift       blocks per second the gas moves of its own accord: {@code x} east, {@code z} south, {@code y} up
 *                    (negative sinks). Beside a {@code buoyancy}, {@code y} is a rise or sink of its own on top of
 *                    the buoyancy's
 * @param draft       a slowly turning sideways push of its own, on top of its drift and the wind
 * @param evaporation thin edges wearing away faster than the body
 * @param response    how much of what moves the air moves this gas
 */
public record Motion(float diffusion, float decay, Optional<Buoyancy> buoyancy, Vec3 drift, Optional<Draft> draft,
                     Optional<Evaporation> evaporation, Response response) {
    private record Drift(float x, float y, float z) {
        static final Codec<Drift> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Ranges.DRIFT_SIDEWAYS.codec().optionalFieldOf("x", 0f).forGetter(Drift::x),
                Ranges.DRIFT_UP.codec().optionalFieldOf("y", 0f).forGetter(Drift::y),
                Ranges.DRIFT_SIDEWAYS.codec().optionalFieldOf("z", 0f).forGetter(Drift::z)
        ).apply(instance, Drift::new));
    }

    private static final Codec<Vec3> DRIFT_CODEC = Drift.CODEC.xmap(drift -> new Vec3(drift.x(), drift.y(), drift.z()),
            vector -> new Drift((float) vector.x, (float) vector.y, (float) vector.z));

    public static final Codec<Motion> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.DIFFUSION.codec().fieldOf("diffusion").forGetter(Motion::diffusion),
            Ranges.DECAY.codec().optionalFieldOf("decay", 0f).forGetter(Motion::decay),
            Buoyancy.CODEC.optionalFieldOf("buoyancy").forGetter(Motion::buoyancy),
            DRIFT_CODEC.optionalFieldOf("drift", Vec3.ZERO).forGetter(Motion::drift),
            Draft.CODEC.optionalFieldOf("draft").forGetter(Motion::draft),
            Evaporation.CODEC.optionalFieldOf("evaporation").forGetter(Motion::evaporation),
            Response.CODEC.optionalFieldOf("response", Response.FULL).forGetter(Motion::response)
    ).apply(instance, Motion::new));

    public Motion {
        Ranges.DIFFUSION.check(diffusion);
        Ranges.DECAY.check(decay);
        Objects.requireNonNull(buoyancy, "buoyancy");
        Objects.requireNonNull(drift, "drift");
        Ranges.DRIFT_SIDEWAYS.check((float) drift.x);
        Ranges.DRIFT_UP.check((float) drift.y);
        Ranges.DRIFT_SIDEWAYS.check((float) drift.z);
        Objects.requireNonNull(draft, "draft");
        Objects.requireNonNull(evaporation, "evaporation");
        Objects.requireNonNull(response, "response");
    }

    /** Gas that spreads and decays and nothing else moves of its own accord. */
    public Motion(float diffusion, float decay) {
        this(diffusion, decay, Optional.empty(), Vec3.ZERO, Optional.empty(), Optional.empty(), Response.FULL);
    }

    public Motion withBuoyancy(Buoyancy buoyancy) {
        return new Motion(diffusion, decay, Optional.of(buoyancy), drift, draft, evaporation, response);
    }

    public Motion withDrift(Vec3 drift) {
        return new Motion(diffusion, decay, buoyancy, drift, draft, evaporation, response);
    }

    public Motion withDraft(Draft draft) {
        return new Motion(diffusion, decay, buoyancy, drift, Optional.of(draft), evaporation, response);
    }

    public Motion withEvaporation(Evaporation evaporation) {
        return new Motion(diffusion, decay, buoyancy, drift, draft, Optional.of(evaporation), response);
    }

    public Motion withResponse(Response response) {
        return new Motion(diffusion, decay, buoyancy, drift, draft, evaporation, response);
    }

    /**
     * A sideways push that turns slowly from one random heading to the next. The heading follows from the game time
     * and the medium's id, so every client agrees.
     *
     * @param speed  blocks per second at most
     * @param period seconds the heading takes to turn to the next one
     */
    public record Draft(float speed, float period) {
        public static final Codec<Draft> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Ranges.DRAFT_SPEED.codec().fieldOf("speed").forGetter(Draft::speed),
                Ranges.DRAFT_PERIOD.codec().fieldOf("period").forGetter(Draft::period)
        ).apply(instance, Draft::new));

        public Draft {
            Ranges.DRAFT_SPEED.check(speed);
            Ranges.DRAFT_PERIOD.check(period);
        }
    }

    /**
     * Gas thinner than {@code below} of the densest it is nearby loses {@code rate} of itself each second on top of
     * its decay, so a cloud keeps a body and loses its fringe, faint or thick alike. Gas that spreads keeps making
     * new fringe out of its body, so the faster it spreads, the more the body pays.
     *
     * @param below a share of the local peak, 0 to 1
     * @param rate  the share lost each second
     */
    public record Evaporation(float below, float rate) {
        public static final Codec<Evaporation> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Ranges.EVAPORATION_BELOW.codec().fieldOf("below").forGetter(Evaporation::below),
                Ranges.EVAPORATION_RATE.codec().fieldOf("rate").forGetter(Evaporation::rate)
        ).apply(instance, Evaporation::new));

        public Evaporation {
            Ranges.EVAPORATION_BELOW.check(below);
            Ranges.EVAPORATION_RATE.check(rate);
        }
    }

    /**
     * How much of each thing that moves the air moves this gas, each from 0 (none: heavy smoke, cavern fog) to 1
     * (all of it, the default).
     *
     * @param wind   the level's wind
     * @param forces local forces a mod places (fans, vortices, pulls)
     * @param stir   what walks through the gas or blows up in it
     */
    public record Response(float wind, float forces, float stir) {
        public static final Response FULL = new Response(1f, 1f, 1f);

        public static final Codec<Response> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Ranges.RESPONSE_WIND.codec().optionalFieldOf("wind", 1f).forGetter(Response::wind),
                Ranges.RESPONSE_FORCES.codec().optionalFieldOf("forces", 1f).forGetter(Response::forces),
                Ranges.RESPONSE_STIR.codec().optionalFieldOf("stir", 1f).forGetter(Response::stir)
        ).apply(instance, Response::new));

        public Response {
            Ranges.RESPONSE_WIND.check(wind);
            Ranges.RESPONSE_FORCES.check(forces);
            Ranges.RESPONSE_STIR.check(stir);
        }
    }
}
