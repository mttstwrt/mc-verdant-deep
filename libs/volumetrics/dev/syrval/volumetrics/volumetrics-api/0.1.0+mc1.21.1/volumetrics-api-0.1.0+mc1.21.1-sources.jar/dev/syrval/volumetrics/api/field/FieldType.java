package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * One kind of field node: the {@code type} its objects are written with and the codec of the rest of them. The set
 * is {@link FieldTypes}, closed: every node there runs in every engine (or says it is {@link Field#cpuOnly}).
 */
public record FieldType(ResourceLocation id, MapCodec<? extends Field> codec) {
    public FieldType {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(codec, "codec");
    }

    @Override
    public String toString() {
        return id.toString();
    }
}
