package dev.syrval.volumetrics.api.query;

/** Where an answer came from: how much it can be trusted to show what a player sees there. */
public enum Coverage {
    /** From the simulation near the camera (at most a step old), with the drawn fields over it: what is drawn there. */
    SIMULATION,
    /**
     * From placed fields alone: beyond a client's simulation (its fields' formula, without the gas sources give off),
     * or on a server for {@code analytic} media, where the formula is the whole answer.
     */
    FIELDS,
    /** Nothing this side knows of: a server asked about media it does not answer for, a level without the engine. */
    NONE
}
