package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.List;
import java.util.Objects;
//? if >=26.1 {
/*import net.minecraft.advancements.predicates.StatePropertiesPredicate;
import net.minecraft.core.registries.codec.RegistryCodecs;
*///?} else {
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.core.RegistryCodecs;
//?}
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

/**
 * At every block that is one of {@code blocks} (a list, one id, or a {@code #tag}) in a matching state, attached to
 * the block ({@link Attachment.AtBlock}: the middle of its floor, moved by {@code offset}, facing as the block does).
 * Clients find the blocks as they read the world round the camera, so nothing is asked of the server but the
 * definition. Blocks of one rule in the same cell of the simulation are one source or force there, counted as many as
 * there are blocks.
 *
 * <pre>{@code
 * "rule": { "type": "volumetrics:block", "blocks": "#minecraft:campfires", "state": { "lit": "true" },
 *           "offset": { "y": 1.2 } }
 * }</pre>
 *
 * @param state properties the block's state must have, as advancements and loot tables write them; with none, every
 *              state of the block matches
 * @param offset from the middle of the block's floor, in blocks along the world's axes
 */
public record BlockRule(HolderSet<Block> blocks, StatePropertiesPredicate state, Vec3 offset) implements PlacementRule {
    /** Every state. */
    public static final StatePropertiesPredicate ANY_STATE = new StatePropertiesPredicate(List.of());

    public static final MapCodec<BlockRule> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            //? if >=26.1 {
            /*RegistryCodecs.holderSet(Registries.BLOCK).fieldOf("blocks").forGetter(BlockRule::blocks),
            *///?} else {
            RegistryCodecs.homogeneousList(Registries.BLOCK).fieldOf("blocks").forGetter(BlockRule::blocks),
            //?}
            StatePropertiesPredicate.CODEC.optionalFieldOf("state", ANY_STATE).forGetter(BlockRule::state),
            VolumetricsCodecs.XYZ.optionalFieldOf("offset", Vec3.ZERO).forGetter(BlockRule::offset)
    ).apply(instance, BlockRule::new));

    public BlockRule {
        Objects.requireNonNull(blocks, "blocks");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(offset, "offset");
    }

    @Override
    public RuleType type() {
        return PlacementRules.BLOCK;
    }
}
