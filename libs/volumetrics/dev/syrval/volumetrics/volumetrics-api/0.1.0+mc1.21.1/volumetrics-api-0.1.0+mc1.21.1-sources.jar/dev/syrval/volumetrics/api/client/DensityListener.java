package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.Experimental;
import net.minecraft.core.BlockPos;

/**
 * Told when a medium's density at a place within a trigger's reach crosses its threshold ({@link ClientInputs#onDensity}),
 * for a mod that spawns its own particles or plays its own sounds where gas is. Called on the client thread, during the
 * client tick; it should be quick, and must not add or close triggers of the same level from inside the call.
 */
@Experimental
@FunctionalInterface
public interface DensityListener {
    /**
     * The density at a place went over the threshold ({@code above}) or back under it. Each place alternates: one gone
     * above is told once it is under again, once its medium has none left near the camera (with a density of 0), or once
     * it has left the reach or the trigger was updated (with a density of {@code NaN}). Not told when the trigger is
     * closed.
     *
     * @param block   the block holding the middle of the 2-block cell sampled, standing for that cell
     * @param density the density sampled there
     */
    void crossed(BlockPos block, float density, boolean above);
}
