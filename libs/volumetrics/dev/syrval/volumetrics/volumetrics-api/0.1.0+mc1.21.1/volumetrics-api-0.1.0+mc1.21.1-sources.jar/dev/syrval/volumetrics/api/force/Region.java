package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import dev.syrval.volumetrics.api.field.Field;
import java.util.Objects;

/**
 * The checks the kinds with a {@code shape} and a {@code reach} share. A force drives fully inside its shape and, for
 * a shape (a signed distance), by {@code (1 - d / reach)^2} at {@code d} blocks outside it, to nothing at {@code reach};
 * a shape given as any other field drives by its value, 0 to 1, and its reach is not used. The shape is written
 * relative to the attachment, bounded, and no more than {@value #MAX_EXTENT} blocks across.
 */
final class Region {
    /** The most a force's shape may span on any axis, in blocks. */
    static final int MAX_EXTENT = 256;
    static final float MAX_REACH = 64f;

    private Region() {}

    static Codec<Float> reach(String kind) {
        return Limits.distance(kind + ".reach", MAX_REACH).codec();
    }

    static Field shape(Field shape, String kind) {
        return Objects.requireNonNull(shape, kind + ".shape");
    }

    static float reach(float reach, String kind) {
        return Limits.distance(kind + ".reach", MAX_REACH).check(reach);
    }
}
