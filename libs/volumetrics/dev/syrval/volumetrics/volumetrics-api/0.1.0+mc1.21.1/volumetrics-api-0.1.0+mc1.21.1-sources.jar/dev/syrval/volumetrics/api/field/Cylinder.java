package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Optional;
import net.minecraft.world.phys.Vec3;

/**
 * An upright round shape standing on {@code base}, the middle of its bottom: a cylinder, or with a {@code top_radius}
 * of its own a cone, a funnel or the inside of a bowl, the radius changing evenly from bottom to top.
 * {@code {"type": "volumetrics:cylinder", "base": {"x": 0, "y": 60, "z": 0}, "height": 20, "radius": 16,
 * "top_radius": 24}}. As the signed distance to its surface, measured sideways to the slanted side of a cone. The
 * base is the origin when left out: where a source or force is attached, for shapes written relative to that.
 */
public record Cylinder(Vec3 base, float height, float radius, float topRadius) implements Field {
    public static final MapCodec<Cylinder> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            VolumetricsCodecs.XYZ.optionalFieldOf("base", Vec3.ZERO).forGetter(Cylinder::base),
            Check.positive("cylinder.height").fieldOf("height").forGetter(Cylinder::height),
            Check.positive("cylinder.radius").fieldOf("radius").forGetter(Cylinder::radius),
            Check.positive("cylinder.top_radius").optionalFieldOf("top_radius")
                    .forGetter(cylinder -> cylinder.topRadius == cylinder.radius ? Optional.empty() : Optional.of(cylinder.topRadius))
    ).apply(instance, (base, height, radius, top) -> new Cylinder(base, height, radius, top.orElse(radius))));

    public Cylinder {
        Check.position(base, "cylinder.base");
        Check.positive(height, "cylinder.height");
        Check.positive(radius, "cylinder.radius");
        Check.positive(topRadius, "cylinder.top_radius");
    }

    /** A cylinder of one radius. */
    public Cylinder(Vec3 base, float height, float radius) {
        this(base, height, radius, radius);
    }

    @Override
    public FieldType type() {
        return FieldTypes.CYLINDER;
    }

    @Override
    public FieldBounds bounds() {
        double reach = Math.max(radius, topRadius);
        return new FieldBounds(base.x - reach, base.y, base.z - reach, base.x + reach, base.y + height, base.z + reach);
    }

    @Override
    public float minimum() {
        return -Math.min(height / 2, Math.max(radius, topRadius));
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
