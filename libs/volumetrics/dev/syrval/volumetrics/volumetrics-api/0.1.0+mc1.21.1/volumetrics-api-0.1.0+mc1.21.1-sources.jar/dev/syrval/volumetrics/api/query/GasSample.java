package dev.syrval.volumetrics.api.query;

import dev.syrval.volumetrics.api.medium.Medium;
import java.util.Map;
import java.util.Objects;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.Vec3;

/**
 * The gas at one point ({@link GasQueries#sample}).
 *
 * @param densities  by medium, the density of each with gas there (1 is pure gas); a medium absent has none, or is not
 *                   one this side answers for (a server lists {@code analytic} media only)
 * @param extinction light stopped per block there, all media together: light through {@code n} blocks of it is dimmed
 *                   to {@code exp(-extinction * n)}
 * @param velocity   the velocity the gas there is carried at, in blocks per second, weighted by each medium's density:
 *                   the level's wind as each medium answers it, with its own drift and draft; zero where there is no
 *                   gas. Local forces (fans, pulls) and rising are not in it yet
 * @param coverage   where the answer came from
 */
public record GasSample(Map<ResourceKey<Medium>, Float> densities, float extinction, Vec3 velocity, Coverage coverage) {
    /** No gas, from nowhere. */
    public static final GasSample EMPTY = new GasSample(Map.of(), 0f, Vec3.ZERO, Coverage.NONE);

    public GasSample {
        densities = Map.copyOf(densities);
        Objects.requireNonNull(velocity, "velocity");
        Objects.requireNonNull(coverage, "coverage");
    }

    /** A medium's density, 0 where it is not. */
    public float density(ResourceKey<Medium> medium) {
        Float density = densities.get(medium);
        return density == null ? 0f : density;
    }

    /** The densities of every medium together. */
    public float total() {
        float total = 0f;
        for (float density : densities.values()) {
            total += density;
        }
        return total;
    }
}
