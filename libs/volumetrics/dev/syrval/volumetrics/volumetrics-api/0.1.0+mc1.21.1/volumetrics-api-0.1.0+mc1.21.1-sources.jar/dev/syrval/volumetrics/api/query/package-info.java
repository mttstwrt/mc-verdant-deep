/**
 * Queries: how much gas there is at a point, along a line or in a box, for mods that act on it (an entity coughing in
 * smoke, a sound muffled by fog, an airship's drag). {@link dev.syrval.volumetrics.api.query.GasQueries} is reached
 * per level through {@link dev.syrval.volumetrics.api.VolumetricsApi#queries}, on either side: a client answers from
 * its simulation and its placed fields, a server for {@code analytic} media from their fields' formula.
 */
package dev.syrval.volumetrics.api.query;
