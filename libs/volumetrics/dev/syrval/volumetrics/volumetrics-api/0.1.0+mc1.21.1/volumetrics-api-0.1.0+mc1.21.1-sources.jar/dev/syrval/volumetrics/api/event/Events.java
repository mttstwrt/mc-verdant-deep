package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Every kind of event, by the {@code type} it is written with:
 * <ul>
 *   <li>{@code volumetrics:blast} ({@link Blast}): a push out of a sphere, at once or as a travelling shockwave.</li>
 *   <li>{@code volumetrics:puff} ({@link Puff}): gas added in a shape at once.</li>
 *   <li>{@code volumetrics:clear} ({@link Clear}): gas taken away in a shape, at once or over a time.</li>
 *   <li>{@code volumetrics:gust} ({@link Gust}): a force for a few seconds.</li>
 * </ul>
 * A closed set, the same on both sides.
 */
public final class Events {
    public static final ResourceLocation BLAST = id("blast");
    public static final ResourceLocation PUFF = id("puff");
    public static final ResourceLocation CLEAR = id("clear");
    public static final ResourceLocation GUST = id("gust");

    private static final Map<ResourceLocation, MapCodec<? extends Event>> CODECS = new LinkedHashMap<>();

    static {
        CODECS.put(BLAST, Blast.MAP_CODEC);
        CODECS.put(PUFF, Puff.MAP_CODEC);
        CODECS.put(CLEAR, Clear.MAP_CODEC);
        CODECS.put(GUST, Gust.MAP_CODEC);
    }

    /** An event, by its {@code type}. */
    static final Codec<Event> CODEC = ResourceLocation.CODEC
            .validate(id -> CODECS.containsKey(id) ? DataResult.success(id) : DataResult.error(() -> "Not a kind of event: " + id))
            .dispatch("type", Event::type, CODECS::get);

    private Events() {}

    public static Set<ResourceLocation> all() {
        return Collections.unmodifiableSet(CODECS.keySet());
    }

    private static ResourceLocation id(String name) {
        return ResourceLocation.fromNamespaceAndPath("volumetrics", name);
    }
}
