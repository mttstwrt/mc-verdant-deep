package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;

/**
 * The box of the structure piece a {@link dev.syrval.volumetrics.api.placement.StructureRule} placed this at (or of
 * the whole structure, with {@code "each": "structure"}), as a shape: {@code {"type": "volumetrics:piece_box"}}. The
 * library puts the piece's own {@link Box} in its place, measured from where the rule attached it (the middle of the
 * piece's floor), before the field is compiled, so one entry fills each piece whatever its size:
 * {@code {"type": "volumetrics:inside", "shape": {"type": "volumetrics:piece_box"}, "edge": 2}}.
 *
 * <p>Only in a source's shape, a force's region or a placed field of an entry placed by a structure rule: anywhere
 * else it has no box, and the entry is refused.
 */
public record PieceBox() implements Field {
    public static final PieceBox INSTANCE = new PieceBox();
    public static final MapCodec<PieceBox> MAP_CODEC = MapCodec.unit(INSTANCE);

    @Override
    public FieldType type() {
        return FieldTypes.PIECE_BOX;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return Float.NEGATIVE_INFINITY;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
