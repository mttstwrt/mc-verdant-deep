package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;

/** The same number everywhere: {@code {"type": "volumetrics:constant", "value": 0.4}}. */
public record Constant(float value) implements Field {
    public static final MapCodec<Constant> MAP_CODEC = Check.number("constant.value").fieldOf("value")
            .xmap(Constant::new, Constant::value);

    public Constant {
        Check.number(value, "constant.value");
    }

    @Override
    public FieldType type() {
        return FieldTypes.CONSTANT;
    }

    @Override
    public FieldBounds bounds() {
        return value > 0 ? FieldBounds.EVERYWHERE : FieldBounds.NOWHERE;
    }

    @Override
    public float minimum() {
        return value;
    }

    @Override
    public float maximum() {
        return value;
    }
}
