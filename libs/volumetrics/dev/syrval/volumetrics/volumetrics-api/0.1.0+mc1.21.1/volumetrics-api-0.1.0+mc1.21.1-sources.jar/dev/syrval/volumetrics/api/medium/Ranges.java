package dev.syrval.volumetrics.api.medium;

/**
 * The bounds of every number of a medium or edge file. A class of its own that holds nothing else, so that a record's
 * constants can be checked whichever record the game touches first: were the bounds kept in the records, one record's
 * static setup could reach another's while that one was still being set up and find its bounds missing.
 */
final class Ranges {
    static final Range DIFFUSION = new Range("motion.diffusion", 0f, 64f);
    static final Range DECAY = new Range("motion.decay", 0f, 20f);
    static final Range DRIFT_SIDEWAYS = new Range("motion.drift x and z", -16f, 16f);
    static final Range DRIFT_UP = new Range("motion.drift y", -64f, 64f);
    static final Range DRAFT_SPEED = new Range("motion.draft.speed", 0f, 16f);
    static final Range DRAFT_PERIOD = new Range("motion.draft.period", 1e-3f, 1e5f);
    static final Range EVAPORATION_BELOW = new Range("motion.evaporation.below", 0f, 1f);
    static final Range EVAPORATION_RATE = new Range("motion.evaporation.rate", 0f, 20f);
    static final Range RESPONSE_WIND = new Range("motion.response.wind", 0f, 1f);
    static final Range RESPONSE_FORCES = new Range("motion.response.forces", 0f, 1f);
    static final Range RESPONSE_STIR = new Range("motion.response.stir", 0f, 1f);
    static final Range BUOYANCY_DENSITY = new Range("buoyancy.density", 1e-4f, 1e4f);
    static final Range BUOYANCY_SETTLES_AT = new Range("buoyancy.settles_at", -1e5f, 1e5f);
    static final Range BUOYANCY_SPEED = new Range("buoyancy.speed", 0f, 1e4f);

    static final Range EXTINCTION = new Range("optics.extinction", 0f, 16f);
    static final Range PHASE_LOBE = new Range("optics.phase lobe", -0.9f, 0.9f);
    static final Range PHASE_BLEND = new Range("optics.phase.blend", 0f, 1f);
    static final Range EMISSION_STRENGTH = new Range("optics.emission.strength", 0f, 4f);
    static final Range AMBIENT = new Range("optics.ambient", 0f, 4f);
    static final Range LAMPS = new Range("optics.lamps", 0f, 4f);

    static final Range CONVERSION_RATE = new Range("converts.rate", 0f, 20f);

    static final Range WISPS_SCALE = new Range("detail.wisps.scale", 0f, 4f);
    static final Range WISPS_SPEED = new Range("detail.wisps.speed", 0f, 16f);
    static final Range WISPS_STRENGTH = new Range("detail.wisps.strength", 0f, 1f);
    static final Range FLOW_STRENGTH = new Range("detail.flow.strength", 0f, 1f);

    static final Range EDGE_THRESHOLD = new Range("edge threshold", 0f, 1f);
    static final Range EDGE_SOFTNESS = new Range("edge softness", 0f, 1f);
    static final Range EDGE_FILL = new Range("edge fill", 0f, 1f);
    static final Range EDGE_EROSION = new Range("edge erosion", 0f, 1f);
    static final Range EDGE_TURBULENCE = new Range("edge turbulence", 0f, 4f);
    static final Range EDGE_TURBULENCE_SCALE = new Range("edge turbulence_scale", 0.01f, 4f);
    static final Range EDGE_TURBULENCE_SPEED = new Range("edge turbulence_speed", 0f, 16f);

    private Ranges() {}
}
