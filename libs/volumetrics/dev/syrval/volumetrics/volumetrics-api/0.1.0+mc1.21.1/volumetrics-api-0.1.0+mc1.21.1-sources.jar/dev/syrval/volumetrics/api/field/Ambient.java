package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/**
 * A field a dimension always has: an entry of the {@link dev.syrval.volumetrics.api.VolumetricsRegistries#AMBIENT}
 * registry, {@code data/<namespace>/volumetrics/ambient/<name>.json}, a {@link PlacedField} with the dimension it is
 * in. Loaded with the world and sent to clients, so every player of a server has the same.
 *
 * <pre>{@code
 * { "dimension": "minecraft:overworld", "medium": "volumetrics:mist", "mode": "drawn",
 *   "field": "mymod:valley_fog" }
 * }</pre>
 *
 * @param dimension the level it is in
 * @param placed    what it puts there
 */
public record Ambient(ResourceKey<Level> dimension, PlacedField placed) {
    public static final Codec<Ambient> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ResourceKey.codec(Registries.DIMENSION).fieldOf("dimension").forGetter(Ambient::dimension),
            PlacedField.MAP_CODEC.forGetter(Ambient::placed)
    ).apply(instance, Ambient::new));

    public Ambient {
        Objects.requireNonNull(dimension, "dimension");
        Objects.requireNonNull(placed, "placed");
    }
}
