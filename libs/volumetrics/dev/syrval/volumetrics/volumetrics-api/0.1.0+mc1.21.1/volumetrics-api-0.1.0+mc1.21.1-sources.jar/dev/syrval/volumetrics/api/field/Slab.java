package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * Everything between two heights, without sides: a layer as wide as the world, what cloud layers and valley fog
 * fill. As the signed distance in blocks to its nearer face. {@code {"type": "volumetrics:slab", "bottom": 180,
 * "top": 230}}.
 */
public record Slab(double bottom, double top) implements Field {
    public static final MapCodec<Slab> MAP_CODEC = RecordCodecBuilder.<Slab>mapCodec(instance -> instance.group(
            Check.position("slab.bottom").fieldOf("bottom").forGetter(Slab::bottom),
            Check.position("slab.top").fieldOf("top").forGetter(Slab::top)
    ).apply(instance, (bottom, top) -> top > bottom ? new Slab(bottom, top) : null)).validate(slab -> slab == null
            ? DataResult.error(() -> "slab.top must be above slab.bottom") : DataResult.success(slab));

    public Slab {
        Check.position(bottom, "slab.bottom");
        Check.position(top, "slab.top");
        if (!(top > bottom)) {
            throw new IllegalArgumentException("slab.top must be above slab.bottom, got " + bottom + " and " + top);
        }
    }

    @Override
    public FieldType type() {
        return FieldTypes.SLAB;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.layer(bottom, top);
    }

    @Override
    public float minimum() {
        return (float) -(top - bottom) / 2;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
