package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * How much of the gas the conditions of the moment leave at the point's column, 0 (none) to 1 (all of it), as the
 * provider registered under {@code id} reckons it: the weather, the time of day, the biome, as another mod decides.
 * {@code {"type": "volumetrics:condition", "id": "weather:cloudiness"}}. Read at the world column of the point, so
 * {@code translate} and the other space nodes do not move it: conditions stay where they are in the world.
 *
 * <p>An id nobody registered is 1 (logged once). The engine keeps a limited number of ids per level (four today); a
 * field naming more is not scaled by the extra ones (logged once). Providers are registered on the client for now,
 * through the library's legacy {@code AmbientConditions}; on both sides with VOL-082's step 2.
 */
public record Condition(ResourceLocation id) implements Field {
    public static final MapCodec<Condition> MAP_CODEC = ResourceLocation.CODEC.fieldOf("id").xmap(Condition::new, Condition::id);

    public Condition {
        Objects.requireNonNull(id, "condition.id");
    }

    @Override
    public FieldType type() {
        return FieldTypes.CONDITION;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }
}
