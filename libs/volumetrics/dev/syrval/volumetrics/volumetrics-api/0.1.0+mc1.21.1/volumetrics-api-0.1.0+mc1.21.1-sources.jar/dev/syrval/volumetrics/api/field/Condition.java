package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * How much of the gas the conditions of the moment leave at the point's column, 0 (none) to 1 (all of it):
 * {@code {"type": "volumetrics:condition", "id": "volumetrics:rain"}}. The id is one of the library's built-in
 * conditions ({@link dev.syrval.volumetrics.api.condition.Conditions}: the time of day, daylight, rain, thunder, a biome
 * tag) or one a mod registered ({@link dev.syrval.volumetrics.api.Owner#registerCondition}). Read at the world column
 * of the point, so {@code translate} and the other space nodes do not move it: conditions stay where they are in the
 * world. Combine them with field arithmetic: {@code mul} of {@code volumetrics:rain} and a biome tag.
 *
 * <p>An id nobody registered is 1 (logged once). A client keeps at most four ids per level (one channel each of the
 * texture its renderer reads); a field naming more is not scaled by the extra ones there (logged once). A server keeps
 * as many as its fields name.
 */
public record Condition(ResourceLocation id) implements Field {
    public static final MapCodec<Condition> MAP_CODEC = ResourceLocation.CODEC.fieldOf("id").xmap(Condition::new, Condition::id);

    public Condition {
        Objects.requireNonNull(id, "condition.id");
    }

    @Override
    public FieldType type() {
        return FieldTypes.CONDITION;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }
}
