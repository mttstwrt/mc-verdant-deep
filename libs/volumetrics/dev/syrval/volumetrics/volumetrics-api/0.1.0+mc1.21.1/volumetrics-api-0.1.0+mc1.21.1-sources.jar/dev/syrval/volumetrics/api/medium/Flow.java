package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Experimental;

/**
 * Billowing detail the flow carries: the gas rolls where it moves fast against still air and rests where it rests.
 * Drawn only, like the rest of {@link Detail}: rolls about a level axis across the way the gas goes, about two of the
 * medium's wisps across, carried along with it. The rolls move the medium's pattern (its wisps and its edge's erosion),
 * the detail finer than the simulation's cells, not the simulated gas itself. Only local forces count as moving against
 * the air (a pull, a gust, an entity), not the medium's drift or the level's wind, which carry the air with the gas; and
 * only sideways. Where nothing pushes the gas it is drawn as without this. A renderer that cannot draw it leaves it out;
 * ask {@code capabilities().has(volumetrics:flow_detail)}. Its fields may change while it is experimental.
 *
 * @param strength how far the rolls move the pattern, 0 to 1: at 1, up to half a roll where the gas moves at 1.5
 *                 blocks a second or more against the air around it, less where it moves slower; 0 draws none
 */
@Experimental
public record Flow(float strength) {
    public static final Codec<Flow> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.FLOW_STRENGTH.codec().fieldOf("strength").forGetter(Flow::strength)
    ).apply(instance, Flow::new));

    public Flow {
        Ranges.FLOW_STRENGTH.check(strength);
    }
}
