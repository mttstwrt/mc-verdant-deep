package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Experimental;

/**
 * Billowing detail the flow carries: the gas rolls where it moves fast against still air and rests where it rests.
 * Reserved: no renderer draws it yet, and one that cannot leaves it out (logged once); ask
 * {@code capabilities().has(volumetrics:flow_detail)}. Its fields may change before it is built.
 *
 * @param strength how much of the flow's energy shows as detail, 0 to 1
 */
@Experimental
public record Flow(float strength) {
    public static final Codec<Flow> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.FLOW_STRENGTH.codec().fieldOf("strength").forGetter(Flow::strength)
    ).apply(instance, Flow::new));

    public Flow {
        Ranges.FLOW_STRENGTH.check(strength);
    }
}
