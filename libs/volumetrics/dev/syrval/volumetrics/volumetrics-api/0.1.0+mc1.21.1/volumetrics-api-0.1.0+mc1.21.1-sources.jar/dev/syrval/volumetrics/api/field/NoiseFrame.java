package dev.syrval.volumetrics.api.field;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * What carries a noise along, so its patches drift: nothing ({@code "world"}), the wind as it carries the placed
 * field's medium ({@code "wind"}: the level's wind times the medium's {@code response.wind}, plus its sideways drift,
 * so the patches move with the gas), or numbers of its own ({@code {"wind": 0.5, "drift": {"x": 1, "z": 0}}}: a share
 * of the level's wind and a drift in blocks per second). Sideways only: the patches never move up or down.
 *
 * @param medium whether it is carried as the placed field's medium is; {@code wind} and the drift are then unused
 * @param wind   the share of the level's wind that carries it, 0 to 1
 * @param driftX blocks per second east, besides the wind
 * @param driftZ blocks per second south
 */
public record NoiseFrame(boolean medium, float wind, float driftX, float driftZ) {
    /** Still in the world. */
    public static final NoiseFrame WORLD = new NoiseFrame(false, 0f, 0f, 0f);
    /** Carried as the placed field's medium. */
    public static final NoiseFrame WIND = new NoiseFrame(true, 0f, 0f, 0f);

    private record Drift(float x, float z) {
        static final Codec<Drift> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Check.number("frame.drift.x").optionalFieldOf("x", 0f).forGetter(Drift::x),
                Check.number("frame.drift.z").optionalFieldOf("z", 0f).forGetter(Drift::z)
        ).apply(instance, Drift::new));
    }

    private static final Codec<NoiseFrame> OWN_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Check.share("frame.wind").optionalFieldOf("wind", 0f).forGetter(NoiseFrame::wind),
            Drift.CODEC.optionalFieldOf("drift", new Drift(0f, 0f)).forGetter(frame -> new Drift(frame.driftX, frame.driftZ))
    ).apply(instance, (wind, drift) -> new NoiseFrame(false, wind, drift.x(), drift.z())));

    private static final Codec<NoiseFrame> NAMED_CODEC = Codec.STRING.comapFlatMap(name -> switch (name) {
        case "world" -> DataResult.success(WORLD);
        case "wind" -> DataResult.success(WIND);
        default -> DataResult.error(() -> "A noise frame is \"world\", \"wind\" or an object, got \"" + name + "\"");
    }, frame -> frame.medium ? "wind" : "world");

    /** {@code "world"}, {@code "wind"} or an object; written by name when it has one. */
    public static final Codec<NoiseFrame> CODEC = Codec.either(NAMED_CODEC, OWN_CODEC).xmap(
            either -> either.map(frame -> frame, frame -> frame),
            frame -> frame.medium || frame.equals(WORLD) ? Either.left(frame) : Either.right(frame));

    public NoiseFrame {
        Check.share(wind, "frame.wind");
        Check.number(driftX, "frame.drift.x");
        Check.number(driftZ, "frame.drift.z");
        if (medium && (wind != 0f || driftX != 0f || driftZ != 0f)) {
            throw new IllegalArgumentException("A noise frame carried as its medium has no numbers of its own");
        }
    }

    /** Carried by {@code wind} of the level's wind and a drift of its own, in blocks per second. */
    public static NoiseFrame of(float wind, float driftX, float driftZ) {
        return new NoiseFrame(false, wind, driftX, driftZ);
    }
}
