/**
 * The client's side of the API: {@link dev.syrval.volumetrics.api.client.ClientInputs}, what a mod adds on this client
 * only. The one package of the API whose use is client-only.
 */
package dev.syrval.volumetrics.api.client;
