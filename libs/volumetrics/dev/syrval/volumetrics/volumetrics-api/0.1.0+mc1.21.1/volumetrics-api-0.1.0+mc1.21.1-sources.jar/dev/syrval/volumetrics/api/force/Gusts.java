package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.field.Field;

/**
 * Turbulence over a shape: air driven this way and that, up to about {@code strength} blocks per second, by a noise
 * with features {@code scale} blocks across that changes over {@code period} seconds. It adds to what the other forces
 * drive. The noise follows the game time, so every player sees the same gusts.
 * {@code {"type": "volumetrics:gusts", "strength": 2, "scale": 6, "period": 3, "shape": {...}}}.
 */
public record Gusts(float strength, float scale, float period, Field shape, float reach) implements ForceKind {
    private static final Limits STRENGTH = Limits.distance("gusts.strength", Limits.MAX_SPEED);
    private static final Limits SCALE = new Limits("gusts.scale", 0.5f, 256f);
    private static final Limits PERIOD = new Limits("gusts.period", 0.05f, 600f);

    public static final MapCodec<Gusts> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            STRENGTH.codec().fieldOf("strength").forGetter(Gusts::strength),
            SCALE.codec().optionalFieldOf("scale", 8f).forGetter(Gusts::scale),
            PERIOD.codec().optionalFieldOf("period", 3f).forGetter(Gusts::period),
            Field.CODEC.fieldOf("shape").forGetter(Gusts::shape),
            Region.reach("gusts").optionalFieldOf("reach", 0f).forGetter(Gusts::reach)
    ).apply(instance, Gusts::new));

    public Gusts {
        STRENGTH.check(strength);
        SCALE.check(scale);
        PERIOD.check(period);
        Region.shape(shape, "gusts");
        Region.reach(reach, "gusts");
    }

    @Override
    public ForceType type() {
        return ForceKinds.GUSTS;
    }
}
