package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * Cuts a noise into patches, as clouds are: {@code coverage} of the noise's range is gas, with a blend {@code softness}
 * wide at the rims, as {@code smoothstep(1 - coverage - softness / 2, 1 - coverage + softness / 2, noise)}. A coverage
 * of 1 with no softness is gas everywhere, 0 none. {@code {"type": "volumetrics:coverage", "coverage": 0.45,
 * "softness": 0.2, "noise": {...}}}.
 */
public record Coverage(Field noise, float coverage, float softness) implements Field {
    public static final MapCodec<Coverage> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("noise").forGetter(Coverage::noise),
            Check.share("coverage.coverage").fieldOf("coverage").forGetter(Coverage::coverage),
            Check.share("coverage.softness").optionalFieldOf("softness", 0f).forGetter(Coverage::softness)
    ).apply(instance, Coverage::new));

    public Coverage {
        Objects.requireNonNull(noise, "coverage.noise");
        Check.share(coverage, "coverage.coverage");
        Check.share(softness, "coverage.softness");
    }

    /** The input value up to which there is no gas. */
    public float low() {
        return 1f - coverage - softness / 2f;
    }

    /** The input value from which there is all of it. */
    public float high() {
        return 1f - coverage + softness / 2f;
    }

    @Override
    public FieldType type() {
        return FieldTypes.COVERAGE;
    }

    @Override
    public FieldBounds bounds() {
        return low() >= 0f && !noise.distance() ? noise.bounds() : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }

    @Override
    public List<Field> children() {
        return List.of(noise);
    }
}
