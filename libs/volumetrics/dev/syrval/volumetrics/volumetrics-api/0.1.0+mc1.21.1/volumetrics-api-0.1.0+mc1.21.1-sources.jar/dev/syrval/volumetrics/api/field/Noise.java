package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import net.minecraft.util.StringRepresentable;

/**
 * Noise from 0 to 1, the same on every client and the server of a level: its lattice comes from an integer hash of the
 * level's noise seed (the server's), so the patches a simulation pulls its gas towards are the ones drawn beyond it.
 * {@code {"type": "volumetrics:noise", "kind": "value", "scale": 160, "octaves": 3, "frame": "wind"}}.
 *
 * <p>It repeats every {@link #PERIOD} blocks along each axis, so a noise carried by the wind for ever wraps without a
 * seam; a {@code scale} is rounded to the nearest that fits a period a whole number of times. Each octave after the
 * first has twice the detail and half the weight.
 *
 * @param kind    {@code value} (the default: smooth blobs, what fogs were cut from before v2), {@code gradient}
 *                (smoother, without the lattice showing) or {@code cellular} (cells, as cumulus)
 * @param scale   blocks across a feature, about: the spacing of the first octave's lattice
 * @param octaves 1 to 4
 * @param frame   what carries it along
 * @param seed    mixed into the level's seed, so two fields' noises differ; 0 for the level's own
 */
public record Noise(Kind kind, float scale, int octaves, NoiseFrame frame, int seed) implements Field {
    /** Blocks after which every noise repeats, along each axis. */
    public static final int PERIOD = 4096;
    /** Most octaves a noise may have. */
    public static final int MAX_OCTAVES = 4;

    public static final MapCodec<Noise> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Kind.CODEC.optionalFieldOf("kind", Kind.VALUE).forGetter(Noise::kind),
            Check.positive("noise.scale").fieldOf("scale").forGetter(Noise::scale),
            Codec.intRange(1, MAX_OCTAVES).optionalFieldOf("octaves", 1).forGetter(Noise::octaves),
            NoiseFrame.CODEC.optionalFieldOf("frame", NoiseFrame.WORLD).forGetter(Noise::frame),
            Codec.INT.optionalFieldOf("seed", 0).forGetter(Noise::seed)
    ).apply(instance, Noise::new));

    public Noise {
        Objects.requireNonNull(kind, "noise.kind");
        Check.positive(scale, "noise.scale");
        if (octaves < 1 || octaves > MAX_OCTAVES) {
            throw new IllegalArgumentException("noise.octaves must be from 1 to " + MAX_OCTAVES + ", got " + octaves);
        }
        Objects.requireNonNull(frame, "noise.frame");
    }

    /** Value noise of one octave, still in the world, of the level's own seed. */
    public Noise(float scale) {
        this(Kind.VALUE, scale, 1, NoiseFrame.WORLD, 0);
    }

    public Noise withOctaves(int octaves) {
        return new Noise(kind, scale, octaves, frame, seed);
    }

    public Noise withFrame(NoiseFrame frame) {
        return new Noise(kind, scale, octaves, frame, seed);
    }

    @Override
    public FieldType type() {
        return FieldTypes.NOISE;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }

    public enum Kind implements StringRepresentable {
        VALUE("value"),
        GRADIENT("gradient"),
        CELLULAR("cellular");

        public static final Codec<Kind> CODEC = StringRepresentable.fromEnum(Kind::values);

        private final String name;

        Kind(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }
}
