package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Importance;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.Objects;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.StringRepresentable;

/**
 * A medium put where a field says, in one of two modes:
 * <ul>
 *   <li>{@code drawn}: never simulated, so it costs the simulation nothing and is drawn at any distance. It follows no
 *   floor, and blocks do not stop it: the air of a place, haze in a chasm, a pall over a swamp.</li>
 *   <li>{@code simulated}: near the camera it is real gas of its medium, pulled towards the field's density, where it is
 *   thinner, by {@code formation} of the difference a second, and where it is thicker by {@code dissipation}; it pools,
 *   pours over ridges and is blown along. Beyond the simulation it is drawn by the field, and the gas blends into it.</li>
 * </ul>
 * The field's density is the medium's: light through {@code n} blocks at density {@code d} is dimmed to
 * {@code exp(-extinction * d * n)}. {@code importance} decides which placed fields are drawn when the renderer cannot
 * draw them all, before distance does.
 *
 * <pre>{@code
 * { "medium": "volumetrics:mist", "mode": "simulated", "formation": 0.05, "dissipation": 0.05,
 *   "field": { "type": "volumetrics:mul", "args": [ ... ] } }
 * }</pre>
 *
 * <p>A renderer draws the fields it can evaluate; today's draw a field only in the form fogs had before v2 (a shape's
 * inside, times a profile over height, a noise's coverage and a condition), and leave any other drawn field out
 * (logged once) until the GPU evaluates every node (VOL-082 step 3). A simulated field of another form is simulated
 * near the camera all the same, and not drawn beyond. A drawn field with a node only the CPU evaluates
 * ({@link Field#cpuOnly}: {@link HeightAboveSurface}) is refused when it is compiled, logged with its id: no renderer
 * has what it reads.
 *
 * @param medium      the gas, by id in {@link VolumetricsRegistries#MEDIUM}
 * @param field       its density
 * @param mode        drawn or simulated
 * @param formation   for a simulated field, the share of what is missing that forms each second, 0 to 20
 * @param dissipation for a simulated field, the share of what is too much that thins away each second, 0 to 20
 * @param importance  what goes first when not every placed field can be drawn
 */
public record PlacedField(ResourceKey<Medium> medium, Field field, Mode mode, float formation, float dissipation,
                          Importance importance) {
    /** Rates are per second; above this a field would be reached within a step anyway. */
    public static final float MAX_RATE = 20f;

    public static final MapCodec<PlacedField> MAP_CODEC = RecordCodecBuilder.<PlacedField>mapCodec(instance -> instance.group(
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).fieldOf("medium").forGetter(PlacedField::medium),
            Field.CODEC.fieldOf("field").forGetter(PlacedField::field),
            Mode.CODEC.optionalFieldOf("mode", Mode.DRAWN).forGetter(PlacedField::mode),
            rate("formation").optionalFieldOf("formation", 0f).forGetter(PlacedField::formation),
            rate("dissipation").optionalFieldOf("dissipation", 0f).forGetter(PlacedField::dissipation),
            Importance.CODEC.optionalFieldOf("importance", Importance.NORMAL).forGetter(PlacedField::importance)
    ).apply(instance, PlacedField::ofCodec)).validate(placed -> placed == null
            ? DataResult.error(() -> "A simulated field needs a formation or dissipation above 0") : DataResult.success(placed));

    public static final Codec<PlacedField> CODEC = MAP_CODEC.codec();

    public PlacedField {
        Objects.requireNonNull(medium, "medium");
        Objects.requireNonNull(field, "field");
        Objects.requireNonNull(mode, "mode");
        Objects.requireNonNull(importance, "importance");
        checkRate(formation, "formation");
        checkRate(dissipation, "dissipation");
        if (mode == Mode.SIMULATED && formation <= 0f && dissipation <= 0f) {
            throw new IllegalArgumentException("A simulated field needs a formation or dissipation above 0");
        }
    }

    /** Drawn only, of normal importance. */
    public static PlacedField drawn(ResourceKey<Medium> medium, Field field) {
        return new PlacedField(medium, field, Mode.DRAWN, 0f, 0f, Importance.NORMAL);
    }

    /** Simulated near the camera at these rates a second, of normal importance. */
    public static PlacedField simulated(ResourceKey<Medium> medium, Field field, float formation, float dissipation) {
        return new PlacedField(medium, field, Mode.SIMULATED, formation, dissipation, Importance.NORMAL);
    }

    public PlacedField withImportance(Importance importance) {
        return new PlacedField(medium, field, mode, formation, dissipation, importance);
    }

    private static PlacedField ofCodec(ResourceKey<Medium> medium, Field field, Mode mode, float formation, float dissipation,
                                       Importance importance) {
        return mode == Mode.SIMULATED && formation <= 0f && dissipation <= 0f ? null
                : new PlacedField(medium, field, mode, formation, dissipation, importance);
    }

    private static Codec<Float> rate(String name) {
        return Codec.FLOAT.validate(value -> value >= 0 && value <= MAX_RATE ? DataResult.success(value)
                : DataResult.error(() -> name + " must be from 0 to " + MAX_RATE + " a second, got " + value));
    }

    private static void checkRate(float value, String name) {
        if (!(value >= 0 && value <= MAX_RATE)) {
            throw new IllegalArgumentException(name + " must be from 0 to " + MAX_RATE + " a second, got " + value);
        }
    }

    public enum Mode implements StringRepresentable {
        DRAWN("drawn"),
        SIMULATED("simulated");

        public static final Codec<Mode> CODEC = StringRepresentable.fromEnum(Mode::values);

        private final String name;

        Mode(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }
}
