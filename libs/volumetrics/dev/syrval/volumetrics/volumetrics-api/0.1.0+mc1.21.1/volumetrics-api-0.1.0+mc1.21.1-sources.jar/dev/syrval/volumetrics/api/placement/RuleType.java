package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.MapCodec;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;

/**
 * A kind of {@link PlacementRule}: the id it is written with ({@code "type"}) and the codec of its other fields.
 * {@link PlacementRules} lists them.
 */
public record RuleType(ResourceLocation id, MapCodec<? extends PlacementRule> codec) {
    public RuleType {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(codec, "codec");
    }
}
