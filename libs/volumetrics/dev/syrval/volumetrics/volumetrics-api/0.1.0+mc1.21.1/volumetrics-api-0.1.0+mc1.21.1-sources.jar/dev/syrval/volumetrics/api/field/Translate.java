package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.List;
import java.util.Objects;
import net.minecraft.world.phys.Vec3;

/**
 * A field moved by an offset in blocks, its noises and altitude with it (not its conditions, which are the world's):
 * {@code {"type": "volumetrics:translate", "offset": {"x": 100, "y": 0, "z": -40}, "field": {...}}}. A named field
 * written round the origin can be placed anywhere so.
 */
public record Translate(Vec3 offset, Field field) implements Field {
    public static final MapCodec<Translate> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            VolumetricsCodecs.XYZ.fieldOf("offset").forGetter(Translate::offset),
            Field.CODEC.fieldOf("field").forGetter(Translate::field)
    ).apply(instance, Translate::new));

    public Translate {
        Check.position(offset, "translate.offset");
        Objects.requireNonNull(field, "translate.field");
    }

    @Override
    public FieldType type() {
        return FieldTypes.TRANSLATE;
    }

    @Override
    public FieldBounds bounds() {
        return field.bounds().offset(offset.x, offset.y, offset.z);
    }

    @Override
    public float minimum() {
        return field.minimum();
    }

    @Override
    public float maximum() {
        return field.maximum();
    }

    @Override
    public boolean distance() {
        return field.distance();
    }

    @Override
    public List<Field> children() {
        return List.of(field);
    }
}
