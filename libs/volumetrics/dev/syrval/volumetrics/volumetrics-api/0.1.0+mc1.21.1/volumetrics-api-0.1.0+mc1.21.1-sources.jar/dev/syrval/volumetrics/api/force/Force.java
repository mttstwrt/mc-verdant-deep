package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import java.util.Objects;
import net.minecraft.resources.ResourceKey;

/**
 * A force: one of the kinds of {@link ForceKinds}, and the media it moves. Written as the kind's object with an
 * optional {@code media} list beside its fields:
 *
 * <pre>{@code
 * { "type": "volumetrics:vortex", "speed": 4, "core": 1.5, "lift": 1,
 *   "shape": { "type": "volumetrics:cylinder", "radius": 6, "height": 10 }, "reach": 3,
 *   "media": ["volumetrics:smoke"] }
 * }</pre>
 *
 * <p>With no {@code media} it moves every medium, each as far as its {@code motion.response.forces} says (the level's
 * wind, as far as {@code motion.response.wind}); with a list, those media alone, scaled the same way. Data places
 * forces with {@link ForcePlacement}; code (from VOL-082 1e) with an owner and an attachment.
 *
 * @param media the media it moves; empty for all
 */
public record Force(ForceKind kind, List<ResourceKey<Medium>> media) {
    public static final MapCodec<Force> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            ForceKinds.MAP_CODEC.forGetter(Force::kind),
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).listOf().optionalFieldOf("media", List.of()).forGetter(Force::media)
    ).apply(instance, Force::new));

    public static final Codec<Force> CODEC = MAP_CODEC.codec();

    public Force {
        Objects.requireNonNull(kind, "kind");
        media = List.copyOf(media);
    }

    /** Moving every medium. */
    public static Force of(ForceKind kind) {
        return new Force(kind, List.of());
    }
}
