package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;

/**
 * How a medium's gas rises or sinks with the air of the level it is in, which is densest at sea level and thins with
 * height as the server says. Written as {@code "buoyancy": {"density": 1.4}} or {@code {"settles_at": 120}}, with an
 * optional {@code "speed"}; exactly one of the first two.
 *
 * @param density   how dense the gas is against the air at sea level: above 1 it sinks, below 1 it rises, until it
 *                  reaches air as dense as itself
 * @param settlesAt the same written as where the gas comes to rest, in blocks above sea level; may be negative
 * @param speed     blocks per second the gas moves when it is twice as dense as the air around it (or half as dense);
 *                  empty for the server's setting
 */
public record Buoyancy(Optional<Float> density, Optional<Float> settlesAt, Optional<Float> speed) {
    /** The fields as written, before the rule that exactly one of the first two is there. */
    private record Fields(Optional<Float> density, Optional<Float> settlesAt, Optional<Float> speed) {}

    private static final Codec<Fields> FIELDS_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.BUOYANCY_DENSITY.codec().optionalFieldOf("density").forGetter(Fields::density),
            Ranges.BUOYANCY_SETTLES_AT.codec().optionalFieldOf("settles_at").forGetter(Fields::settlesAt),
            Ranges.BUOYANCY_SPEED.codec().optionalFieldOf("speed").forGetter(Fields::speed)
    ).apply(instance, Fields::new));

    public static final Codec<Buoyancy> CODEC = FIELDS_CODEC.flatXmap(
            fields -> fields.density().isPresent() == fields.settlesAt().isPresent()
                    ? DataResult.error(() -> "buoyancy needs exactly one of density and settles_at")
                    : DataResult.success(new Buoyancy(fields.density(), fields.settlesAt(), fields.speed())),
            buoyancy -> DataResult.success(new Fields(buoyancy.density(), buoyancy.settlesAt(), buoyancy.speed())));

    public Buoyancy {
        if (density.isPresent() == settlesAt.isPresent()) {
            throw new IllegalArgumentException("buoyancy needs exactly one of density and settles_at");
        }
        density.ifPresent(Ranges.BUOYANCY_DENSITY::check);
        settlesAt.ifPresent(Ranges.BUOYANCY_SETTLES_AT::check);
        speed.ifPresent(Ranges.BUOYANCY_SPEED::check);
    }

    /** Gas this dense against the air at sea level, at the server's speed. */
    public static Buoyancy ofDensity(float density) {
        return new Buoyancy(Optional.of(density), Optional.empty(), Optional.empty());
    }

    /** Gas that comes to rest this many blocks above sea level, at the server's speed. */
    public static Buoyancy settlingAt(float blocksAboveSea) {
        return new Buoyancy(Optional.empty(), Optional.of(blocksAboveSea), Optional.empty());
    }

    /** The same moving at {@code speed} blocks per second in place of the server's. */
    public Buoyancy withSpeed(float speed) {
        return new Buoyancy(density, settlesAt, Optional.of(speed));
    }
}
