/**
 * Media: kinds of gas, as data. {@link dev.syrval.volumetrics.api.medium.Medium} and its parts, with the codecs that
 * are the format of {@code data/<namespace>/volumetrics/medium/} and {@code data/<namespace>/volumetrics/edge/} files.
 * Records only: immutable, side-neutral, any thread. The engine compiles them into its own form; nothing here names
 * how a renderer or a simulation holds gas.
 */
package dev.syrval.volumetrics.api.medium;
