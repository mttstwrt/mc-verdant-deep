package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * A push out of a sphere: the gas inside it goes to the shell just beyond, as an explosion pushes it (TNT, power 4,
 * empties about 6 blocks; the game's own explosions go on doing that through their own packet).
 * {@code {"type": "volumetrics:blast", "radius": 12, "seconds": 0.8, "media": ["volumetrics:mist"]}}.
 *
 * @param radius   blocks, the sphere it empties
 * @param strength the share of the gas at its middle it pushes out, 0 to 1; it falls off over the outer quarter
 * @param seconds  how long the shockwave takes to reach the radius, pushing a ridge of gas ahead of it; 0 at once
 * @param media    the media it pushes; empty for every cosmetic medium
 */
public record Blast(float radius, float strength, float seconds, List<ResourceKey<Medium>> media) implements Event {
    private static final Limits RADIUS = new Limits("blast.radius", 0.5f, 48f);
    private static final Limits STRENGTH = new Limits("blast.strength", 0f, 1f);
    private static final Limits SECONDS = new Limits("blast.seconds", 0f, 10f);

    public static final MapCodec<Blast> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            RADIUS.codec().fieldOf("radius").forGetter(Blast::radius),
            STRENGTH.codec().optionalFieldOf("strength", 1f).forGetter(Blast::strength),
            SECONDS.codec().optionalFieldOf("seconds", 0f).forGetter(Blast::seconds),
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).listOf().optionalFieldOf("media", List.of()).forGetter(Blast::media)
    ).apply(instance, Blast::new));

    public Blast {
        RADIUS.check(radius);
        STRENGTH.check(strength);
        SECONDS.check(seconds);
        media = List.copyOf(media);
    }

    /** At full strength, at once, on every cosmetic medium. */
    public static Blast of(float radius) {
        return new Blast(radius, 1f, 0f, List.of());
    }

    @Override
    public ResourceLocation type() {
        return Events.BLAST;
    }
}
