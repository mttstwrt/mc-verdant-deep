package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
import java.util.function.Predicate;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;

/**
 * The code tier of placement: a mod's own rule for what gas a chunk holds, for what data's rules
 * ({@link dev.syrval.volumetrics.api.placement.PlacementRule}, such as {@code volumetrics:block}) cannot say: a patch
 * of blocks rather than each block, a structure the mod worked out itself, anything read from the mod's own state.
 * Registered with {@link dev.syrval.volumetrics.api.Owner#registerPlacementRule}.
 *
 * <p>The library calls the rule once for each chunk that loads on its {@linkplain #side() side} (on the level's thread,
 * at the end of the tick the chunk loaded in), with a read-only view of the chunk, and the rule adds the sources, forces
 * and placed fields that chunk holds ({@link ChunkPlacements}). Everything after that is the library's: what a rule adds
 * is scoped to the chunk and ends when it unloads, a server's is sent to the players tracking the chunk, and the next
 * load calls the rule again. A rule holds no handles and needs no event of its loader.
 *
 * <p>Cost. Chunk loads are a hot path: a player who moves loads a few chunks a tick, one who joins or teleports
 * hundreds. A rule that looks for certain blocks says which ({@link #looksFor}), and the library asks each section's
 * palette first: a chunk none of whose sections can hold one costs a palette check per section and the rule is not
 * called. A rule that declares nothing is called for every chunk, and should cost little there (a hash lookup by the
 * chunk's position, say). Work that takes longer than a chunk load should, such as working out a structure that spans
 * many chunks, goes off the level's thread and comes back through {@link ChunkPlacements#later}.
 *
 * <p>Events ({@link dev.syrval.volumetrics.api.Inputs#fire}) are not for rules: an event reaches only the players
 * tracking its chunk when it is fired, and when a chunk loads that is nearly always nobody. A burst of gas where a chunk
 * loads is a source or a field with a timed scope ({@link ChunkPlacements#add(dev.syrval.volumetrics.api.source.Source,
 * dev.syrval.volumetrics.api.placement.Attachment, dev.syrval.volumetrics.api.Scope)}).
 *
 * <p>The rule object itself is asked for {@link #side} and {@link #looksFor} once, when it is registered, and to
 * {@link #start} once per level, on that level's thread. In a single-player game the client's and the integrated
 * server's levels both run, each on its own thread, so a rule of each side keeps per-level state in what {@code start}
 * returns.
 */
@Experimental
public interface PlacementRule {
    /** Which levels the rule places in, and so who sees what it adds. */
    enum Side {
        /**
         * Server levels. What the rule adds is placed from the server for every player
         * ({@link dev.syrval.volumetrics.api.server.ServerInputs}): sent to the players tracking the chunk.
         */
        SERVER,
        /**
         * Client levels: what this client alone sees ({@link dev.syrval.volumetrics.api.client.ClientInputs}), placed as
         * the chunks reach it from its server. Nothing is sent anywhere.
         */
        CLIENT
    }

    Side side();

    /**
     * The block states the rule looks for, or null to be called for every chunk. When given, the rule is called only
     * for a chunk with a section whose palette has a state that passes it, and {@link ChunkView#forEachMatch} visits the
     * blocks that pass it. Asked of palette entries and blocks, never of air in an empty section: it must be quick, must
     * not touch the level, and must answer the same for a state every time (a block tag it reads stays as it was when
     * the chunk loaded).
     */
    default @Nullable Predicate<BlockState> looksFor() {
        return null;
    }

    /**
     * The rule's placer for one level, made the first time a chunk of the level calls for it, on the level's thread;
     * null if the rule places nothing in this level (another dimension, say), and then it is not asked about the
     * level's chunks at all. The library lets go of the placer when the level unloads.
     */
    @Nullable Placer start(Level level);

    /** One level's part of a rule. */
    @FunctionalInterface
    interface Placer {
        /**
         * Adds what the chunk holds, on the level's thread. The view and {@code out} are the library's and are reused:
         * they work only until this returns. What has been added stays if it throws (logged once per rule).
         */
        void place(ChunkView chunk, ChunkPlacements out);
    }

    /** What a rule does once something it waited for is ready ({@link ChunkPlacements#later}). */
    @FunctionalInterface
    interface Then<T> {
        /**
         * Adds what the chunk holds, now that {@code value} is ready, on the level's thread, as {@link Placer#place}
         * does, with a view of the chunk as it is now.
         */
        void place(T value, ChunkView chunk, ChunkPlacements out);
    }
}
