package dev.syrval.volumetrics.api.force;

/**
 * What a force does, as the air velocity it drives towards, in blocks per second, over its region; one of
 * {@link ForceKinds}. Engine-neutral: the cellular engine pushes the gas by it, the fluid engine relaxes its air
 * towards it. Where the regions of several forces overlap, the air is driven towards their mean, weighted by how
 * strongly each drives there, so a ring of pulls round one point pulls no faster than one, and opposite pushes cancel;
 * gusts and the level's wind add on top. Regions are measured from what the force is attached to, moved and not
 * turned; directions (and so a fan's cone, a vortex's axis, a pull's upright line) are in its frame
 * ({@link dev.syrval.volumetrics.api.placement.Attachment}).
 *
 * <p>More kinds may come in a minor version of the API: a mod's own {@code switch} over them needs a {@code default}
 * branch ({@code docs/API-CHANGES.md} in the library).
 */
public sealed interface ForceKind permits LevelWind, Uniform, Toward, Radial, Vortex, Fan, Gusts {
    ForceType type();

    /** Whether the force is the level's wind, which is everywhere and placed only from server code. */
    default boolean levelWide() {
        return false;
    }
}
