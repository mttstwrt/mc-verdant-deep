package dev.syrval.volumetrics.api.force;

/**
 * What a force does, as the air velocity it drives towards, in blocks per second, over its region; one of
 * {@link ForceKinds}. Engine-neutral: the cellular engine pushes the gas by it, the fluid engine relaxes its air
 * towards it. Where the regions of several forces overlap, the air is driven towards their mean, weighted by how
 * strongly each drives there, so a ring of pulls round one point pulls no faster than one, and opposite pushes cancel;
 * gusts and the level's wind add on top. Positions and directions are in the frame of what the force is attached to
 * ({@link dev.syrval.volumetrics.api.placement.Attachment}).
 */
public sealed interface ForceKind permits LevelWind, Uniform, Toward, Radial, Vortex, Fan, Gusts {
    ForceType type();

    /** Whether the force is the level's wind, which is everywhere and placed only from server code. */
    default boolean levelWide() {
        return false;
    }
}
