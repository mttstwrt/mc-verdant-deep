package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * A bell: {@code peak} where the input is {@code center}, falling off over about {@code width} either side
 * ({@code peak * exp(-((input - center) / width)^2 / 2)}). The input is the altitude unless another field is given;
 * over a shape's distance it makes a soft shell. {@code {"type": "volumetrics:gaussian", "center": 70, "width": 6}}.
 */
public record Gaussian(Field input, float center, float width, float peak) implements Field {
    public static final MapCodec<Gaussian> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.optionalFieldOf("input", Altitude.INSTANCE).forGetter(Gaussian::input),
            Check.number("gaussian.center").fieldOf("center").forGetter(Gaussian::center),
            Check.positive("gaussian.width").fieldOf("width").forGetter(Gaussian::width),
            Check.number("gaussian.peak").optionalFieldOf("peak", 1f).forGetter(Gaussian::peak)
    ).apply(instance, Gaussian::new));

    public Gaussian {
        Objects.requireNonNull(input, "gaussian.input");
        Check.number(center, "gaussian.center");
        Check.positive(width, "gaussian.width");
        Check.number(peak, "gaussian.peak");
    }

    @Override
    public FieldType type() {
        return FieldTypes.GAUSSIAN;
    }

    @Override
    public FieldBounds bounds() {
        return peak > 0 ? FieldBounds.EVERYWHERE : FieldBounds.NOWHERE;
    }

    @Override
    public float minimum() {
        return Math.min(0f, peak);
    }

    @Override
    public float maximum() {
        return Math.max(0f, peak);
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
