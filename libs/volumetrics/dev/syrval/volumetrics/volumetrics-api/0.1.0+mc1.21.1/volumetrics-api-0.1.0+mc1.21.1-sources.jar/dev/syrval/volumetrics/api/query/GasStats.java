package dev.syrval.volumetrics.api.query;

import java.util.Objects;
import net.minecraft.world.phys.Vec3;

/**
 * The gas in a box ({@link GasQueries#integrate}), of one medium or of all.
 *
 * @param volume       how much gas there is, in cubic blocks of pure gas: density summed over the box's volume
 * @param meanDensity  {@code volume} over the box's volume
 * @param maxDensity   the densest it is anywhere in the box, as sampled
 * @param meanVelocity the velocity the gas is carried at, weighted by density (see {@link GasSample#velocity}); zero
 *                     with no gas
 * @param coverage     {@link Coverage#SIMULATION} if any of the box was read from the simulation, else where the rest
 *                     came from
 */
public record GasStats(double volume, float meanDensity, float maxDensity, Vec3 meanVelocity, Coverage coverage) {
    /** No gas, from nowhere. */
    public static final GasStats EMPTY = new GasStats(0, 0f, 0f, Vec3.ZERO, Coverage.NONE);

    public GasStats {
        Objects.requireNonNull(meanVelocity, "meanVelocity");
        Objects.requireNonNull(coverage, "coverage");
    }
}
