package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Locale;
import java.util.Objects;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
//? if >=26.1 {
/*import net.minecraft.core.registries.codec.RegistryCodecs;
*///?} else {
import net.minecraft.core.RegistryCodecs;
//?}

/**
 * On every entity of the types named, on each client: as an entity comes into a client's world, the client attaches
 * the source, force or field to it ({@link Attachment.AtEntity}, at its feet moved by {@code offset}, turning with it as
 * {@code turning} says) for as long as the client has it; nothing is asked of the server and nothing is sent. Every
 * blaze smokes.
 *
 * <pre>{@code
 * "rule": { "type": "volumetrics:entity", "entities": "minecraft:blaze", "offset": { "y": 0.9 } }
 * }</pre>
 *
 * @param entities the entity types: one id, a {@code #tag}, or a list
 * @param offset   from the entity's feet, in blocks; turned with the entity's yaw when it turns, +z forward
 * @param turning  whether its frame (a source's velocity, a force's direction) turns with the entity's body or head
 */
public record EntityRule(HolderSet<EntityType<?>> entities, Vec3 offset, Attachment.Turning turning) implements PlacementRule {
    private static final Codec<Attachment.Turning> TURNING = Codec.STRING.comapFlatMap(
            name -> {
                for (Attachment.Turning turning : Attachment.Turning.values()) {
                    if (turning.name().toLowerCase(Locale.ROOT).equals(name)) {
                        return DataResult.success(turning);
                    }
                }
                return DataResult.error(() -> "turning must be none, body or head, got " + name);
            },
            turning -> turning.name().toLowerCase(Locale.ROOT));

    public static final MapCodec<EntityRule> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            //? if >=26.1 {
            /*RegistryCodecs.holderSet(Registries.ENTITY_TYPE).fieldOf("entities").forGetter(EntityRule::entities),
            *///?} else {
            RegistryCodecs.homogeneousList(Registries.ENTITY_TYPE).fieldOf("entities").forGetter(EntityRule::entities),
            //?}
            VolumetricsCodecs.XYZ.optionalFieldOf("offset", Vec3.ZERO).forGetter(EntityRule::offset),
            TURNING.optionalFieldOf("turning", Attachment.Turning.NONE).forGetter(EntityRule::turning)
    ).apply(instance, EntityRule::new));

    public EntityRule {
        Objects.requireNonNull(entities, "entities");
        Objects.requireNonNull(offset, "offset");
        Objects.requireNonNull(turning, "turning");
    }

    @Override
    public RuleType type() {
        return PlacementRules.ENTITY;
    }
}
