package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/** The input held between two numbers: {@code {"type": "volumetrics:clamp", "input": {...}, "min": 0, "max": 0.8}}. */
public record Clamp(Field input, float min, float max) implements Field {
    public static final MapCodec<Clamp> MAP_CODEC = RecordCodecBuilder.<Clamp>mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("input").forGetter(Clamp::input),
            Check.number("clamp.min").fieldOf("min").forGetter(Clamp::min),
            Check.number("clamp.max").fieldOf("max").forGetter(Clamp::max)
    ).apply(instance, (input, min, max) -> max >= min ? new Clamp(input, min, max) : null)).validate(clamp -> clamp == null
            ? DataResult.error(() -> "clamp.max must not be below clamp.min") : DataResult.success(clamp));

    public Clamp {
        Objects.requireNonNull(input, "clamp.input");
        Check.number(min, "clamp.min");
        Check.number(max, "clamp.max");
        if (max < min) {
            throw new IllegalArgumentException("clamp.max must not be below clamp.min, got " + min + " and " + max);
        }
    }

    @Override
    public FieldType type() {
        return FieldTypes.CLAMP;
    }

    @Override
    public FieldBounds bounds() {
        return min <= 0f && !input.distance() ? input.bounds() : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return Math.clamp(input.minimum(), min, max);
    }

    @Override
    public float maximum() {
        return Math.clamp(input.maximum(), min, max);
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
