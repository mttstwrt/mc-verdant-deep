package dev.syrval.volumetrics.api.placement;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * What a source or force is placed on, and so where its shape and directions are measured from: its anchor, and the
 * frame its directions are given in. A source's {@code velocity}, a fan's {@code direction}, a uniform force's
 * {@code velocity} and a vortex's axis are in that frame; shapes are not turned, only moved.
 *
 * <ul>
 *   <li>{@link AtPosition}: a point in the world; the world's frame (x east, y up, z south).</li>
 *   <li>{@link AtBlock}: the middle of a block's floor. A block with a {@code facing} or {@code horizontal_facing}
 *   property faces that way: its frame's +z is where it faces (+y up for a horizontal facing, north for a block
 *   facing up, south for one facing down). Any other block has the world's frame.</li>
 *   <li>{@link AtEntity}: an entity's feet, following it; on a client its interpolated position, so nothing is sent as
 *   it moves. Its frame turns with its body or its head ({@link Turning}), +z forward, or stays the world's.</li>
 * </ul>
 * Each takes an offset, in blocks along the world's axes, from the anchor.
 *
 * <p>Immutable values (an entity attachment holds the entity, and lets go of it with the handle). Data places sources
 * and forces through {@link PlacementRule}s, which make these for what they find.
 */
public sealed interface Attachment permits Attachment.AtPosition, Attachment.AtBlock, Attachment.AtEntity {
    /** At a point in the world. */
    static Attachment at(Vec3 position) {
        return new AtPosition(position);
    }

    /** At the middle of a block's floor. */
    static Attachment block(BlockPos pos) {
        return new AtBlock(pos, Vec3.ZERO);
    }

    /** At the middle of a block's floor, moved by {@code offset} blocks. */
    static Attachment block(BlockPos pos, Vec3 offset) {
        return new AtBlock(pos, offset);
    }

    /** At an entity's feet, in the world's frame. */
    static Attachment entity(Entity entity) {
        return new AtEntity(entity, Vec3.ZERO, Turning.NONE);
    }

    /** At an entity's feet moved by {@code offset} blocks, turning with it as {@code turning} says. */
    static Attachment entity(Entity entity, Vec3 offset, Turning turning) {
        return new AtEntity(entity, offset, turning);
    }

    /** From the anchor, in blocks along the world's axes. */
    Vec3 offset();

    /** @param position where, in world blocks */
    record AtPosition(Vec3 position) implements Attachment {
        public AtPosition {
            requireFinite(position, "position");
        }

        @Override
        public Vec3 offset() {
            return Vec3.ZERO;
        }
    }

    /** @param pos the block, kept as an immutable copy */
    record AtBlock(BlockPos pos, Vec3 offset) implements Attachment {
        public AtBlock {
            pos = Objects.requireNonNull(pos, "pos").immutable();
            requireFinite(offset, "offset");
        }
    }

    record AtEntity(Entity entity, Vec3 offset, Turning turning) implements Attachment {
        public AtEntity {
            Objects.requireNonNull(entity, "entity");
            requireFinite(offset, "offset");
            Objects.requireNonNull(turning, "turning");
        }
    }

    /** Whether an entity attachment's frame turns with the entity. */
    enum Turning {
        /** The world's frame. */
        NONE,
        /** Turns with the body's yaw: +z where the body faces, +y up. */
        BODY,
        /** Turns with the head's yaw and pitch: +z where the entity looks. */
        HEAD
    }

    private static void requireFinite(Vec3 vector, String name) {
        Objects.requireNonNull(vector, name);
        if (!Double.isFinite(vector.x) || !Double.isFinite(vector.y) || !Double.isFinite(vector.z)) {
            throw new IllegalArgumentException(name + " must be finite, got " + vector);
        }
    }
}
