package dev.syrval.volumetrics.api.field;

import java.util.List;

/** The bounds {@code min} and {@code max} nodes and their smooth forms share. */
final class Bounds {
    private Bounds() {}

    /**
     * {@code min} over shapes is their union, grown by {@code grow} for a smooth union, which reaches that far
     * outside; over densities, where all of them are above 0; mixed, unknown.
     */
    static FieldBounds minOf(List<Field> args, float grow) {
        if (Check.allDistances(args)) {
            FieldBounds union = FieldBounds.NOWHERE;
            for (Field arg : args) {
                union = union.union(arg.bounds());
            }
            return union.expand(grow);
        }
        if (Check.anyDistance(args)) {
            return FieldBounds.EVERYWHERE;
        }
        FieldBounds within = FieldBounds.EVERYWHERE;
        for (Field arg : args) {
            within = within.intersect(arg.bounds());
        }
        return within;
    }

    /** {@code max} over shapes is their intersection; over densities, where any of them is above 0; mixed, unknown. */
    static FieldBounds maxOf(List<Field> args) {
        if (Check.allDistances(args)) {
            FieldBounds within = FieldBounds.EVERYWHERE;
            for (Field arg : args) {
                within = within.intersect(arg.bounds());
            }
            return within;
        }
        if (Check.anyDistance(args)) {
            return FieldBounds.EVERYWHERE;
        }
        FieldBounds union = FieldBounds.NOWHERE;
        for (Field arg : args) {
            union = union.union(arg.bounds());
        }
        return union;
    }
}
