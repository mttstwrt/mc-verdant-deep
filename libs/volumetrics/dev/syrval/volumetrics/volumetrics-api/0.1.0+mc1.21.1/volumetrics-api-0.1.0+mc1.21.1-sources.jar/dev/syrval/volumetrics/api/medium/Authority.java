package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import dev.syrval.volumetrics.api.Experimental;
import net.minecraft.util.StringRepresentable;

/**
 * Who knows where a medium's gas is, which decides what the server can be asked about it and what it costs there.
 * Written {@code "authority": "cosmetic"}.
 */
public enum Authority implements StringRepresentable {
    /**
     * Each client simulates the gas near its own camera; the server knows nothing of where it is and asking it gets
     * nothing. Costs the server about nothing. The default.
     */
    COSMETIC("cosmetic"),
    /**
     * Where the gas is follows from the formula of the fields that place it, the same on every side, so the server can
     * answer exactly without simulating anything. Placed by fields only, not by sources. Until the engine supports it,
     * a medium that asks for it is treated as cosmetic (logged once).
     */
    @Experimental
    ANALYTIC("analytic"),
    /**
     * The server simulates the gas coarsely and its answers count for gameplay; clients keep their finer detail
     * and are corrected towards the server's. Placed from the server only. Until the engine supports it, a medium that
     * asks for it is treated as cosmetic (logged once).
     */
    @Experimental
    GAMEPLAY("gameplay");

    public static final Codec<Authority> CODEC = StringRepresentable.fromEnum(Authority::values);

    private final String name;

    Authority(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
