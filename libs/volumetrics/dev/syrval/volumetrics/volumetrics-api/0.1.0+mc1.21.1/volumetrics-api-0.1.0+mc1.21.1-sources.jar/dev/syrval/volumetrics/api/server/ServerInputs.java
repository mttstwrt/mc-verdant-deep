package dev.syrval.volumetrics.api.server;

import dev.syrval.volumetrics.api.Inputs;
import dev.syrval.volumetrics.api.Owner;

/**
 * What a mod adds from the server to one server level ({@link Owner#server}), for every player there: the library
 * sends it to the players who should have it, and the server simulates none of it (cosmetic media). Scopes are checked
 * on the server thread, and a client is sent the end of one.
 *
 * <p>Who should have it: for one on an entity, the players tracking that entity; for a placed field, everyone in the
 * level (fields are drawn at any distance); for anything else, the players tracking one chunk: its scope's chunk when
 * it is scoped to a chunk or a block, else its anchor's. So a pull anchored on a hole's axis but scoped to the chunk
 * of the disc it acts on reaches the players near that disc, and leaves them when they stop tracking it.
 */
public interface ServerInputs extends Inputs {
}
