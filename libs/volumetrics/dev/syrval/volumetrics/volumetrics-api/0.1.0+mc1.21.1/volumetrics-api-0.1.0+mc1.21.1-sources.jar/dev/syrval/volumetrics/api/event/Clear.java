package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.field.Field;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import java.util.Objects;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * Gas taken away over a shape: where the shape is 1 (a signed distance counts as 1 inside) all of it by the end of
 * {@code seconds}, in proportion elsewhere, including what flows in meanwhile; afterwards the gas around fills the
 * place again as it would any hole. A spell clearing the air. The shape is bounded and no more than 256 blocks across.
 * {@code {"type": "volumetrics:clear", "seconds": 2, "shape": {"type": "volumetrics:sphere", "radius": 10}}}.
 *
 * @param seconds how long it takes, 0 for at once
 * @param media   the media it takes; empty for every cosmetic medium
 */
public record Clear(Field shape, float seconds, List<ResourceKey<Medium>> media) implements Event {
    private static final Limits SECONDS = new Limits("clear.seconds", 0f, 60f);

    public static final MapCodec<Clear> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("shape").forGetter(Clear::shape),
            SECONDS.codec().optionalFieldOf("seconds", 0f).forGetter(Clear::seconds),
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).listOf().optionalFieldOf("media", List.of()).forGetter(Clear::media)
    ).apply(instance, Clear::new));

    public Clear {
        Objects.requireNonNull(shape, "clear.shape");
        SECONDS.check(seconds);
        media = List.copyOf(media);
    }

    @Override
    public ResourceLocation type() {
        return Events.CLEAR;
    }
}
