package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import net.minecraft.world.phys.Vec3;

/**
 * A cone of moving air from the attachment along {@code direction} (in its frame; forward, +z, unless written): a fan,
 * a bellows, an updraft over a vent. The air leaves at {@code speed} blocks per second through a mouth of
 * {@code radius} blocks, widening by {@code spread} degrees each side and slowing evenly to nothing at {@code range}
 * blocks; across the cone it fades from the axis to the rim. A negative speed draws air in towards the mouth (Create's
 * fans run either way). {@code {"type": "volumetrics:fan", "speed": 3, "range": 10, "spread": 20, "direction": {"y": 1}}}.
 */
public record Fan(float speed, float range, float spread, float radius, Vec3 direction) implements ForceKind {
    private static final Limits SPEED = Limits.speed("fan.speed");
    private static final Limits RANGE = new Limits("fan.range", 0.5f, 128f);
    private static final Limits SPREAD = new Limits("fan.spread", 0f, 80f);
    private static final Limits RADIUS = new Limits("fan.radius", 0.1f, 32f);

    public static final MapCodec<Fan> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            SPEED.codec().fieldOf("speed").forGetter(Fan::speed),
            RANGE.codec().fieldOf("range").forGetter(Fan::range),
            SPREAD.codec().optionalFieldOf("spread", 15f).forGetter(Fan::spread),
            RADIUS.codec().optionalFieldOf("radius", 0.5f).forGetter(Fan::radius),
            VolumetricsCodecs.XYZ.optionalFieldOf("direction", new Vec3(0, 0, 1)).forGetter(Fan::direction)
    ).apply(instance, Fan::new));

    public Fan {
        SPEED.check(speed);
        RANGE.check(range);
        SPREAD.check(spread);
        RADIUS.check(radius);
        if (direction == null || !(direction.length() > 1e-6)) {
            throw new IllegalArgumentException("fan.direction must not be zero, got " + direction);
        }
        direction = direction.normalize();
    }

    @Override
    public ForceType type() {
        return ForceKinds.FAN;
    }
}
