package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import net.minecraft.world.phys.Vec3;

/**
 * A ball, as the signed distance to its surface in blocks:
 * {@code {"type": "volumetrics:sphere", "center": {"x": 0, "y": 80, "z": 0}, "radius": 12}}. The centre is the
 * origin when left out: where a source or force is attached, for shapes written relative to that.
 */
public record Sphere(Vec3 center, float radius) implements Field {
    public static final MapCodec<Sphere> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            VolumetricsCodecs.XYZ.optionalFieldOf("center", Vec3.ZERO).forGetter(Sphere::center),
            Check.positive("sphere.radius").fieldOf("radius").forGetter(Sphere::radius)
    ).apply(instance, Sphere::new));

    public Sphere {
        Check.position(center, "sphere.center");
        Check.positive(radius, "sphere.radius");
    }

    @Override
    public FieldType type() {
        return FieldTypes.SPHERE;
    }

    @Override
    public FieldBounds bounds() {
        return new FieldBounds(center.x - radius, center.y - radius, center.z - radius, center.x + radius,
                center.y + radius, center.z + radius);
    }

    @Override
    public float minimum() {
        return -radius;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
