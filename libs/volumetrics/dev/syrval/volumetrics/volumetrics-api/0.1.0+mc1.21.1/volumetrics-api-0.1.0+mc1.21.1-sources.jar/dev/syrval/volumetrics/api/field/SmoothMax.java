package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

/**
 * The most of its fields with the corners rounded over {@code smoothness}: the smooth intersection of shapes. The
 * polynomial smooth maximum, taken pairwise from the first field on.
 * {@code {"type": "volumetrics:smooth_max", "args": [{...}, {...}], "smoothness": 4}}.
 */
public record SmoothMax(List<Field> args, float smoothness) implements Field {
    public static final MapCodec<SmoothMax> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Check.args("smooth_max.args", 2).fieldOf("args").forGetter(SmoothMax::args),
            Check.positive("smooth_max.smoothness").fieldOf("smoothness").forGetter(SmoothMax::smoothness)
    ).apply(instance, SmoothMax::new));

    public SmoothMax {
        args = Check.args(args, 2, "smooth_max.args");
        Check.positive(smoothness, "smooth_max.smoothness");
    }

    @Override
    public FieldType type() {
        return FieldTypes.SMOOTH_MAX;
    }

    /**
     * Over shapes, their intersection: the smooth maximum is never below the plain one. Over densities, unknown: where
     * all are 0 it is a quarter of the smoothness.
     */
    @Override
    public FieldBounds bounds() {
        return Check.allDistances(args) ? Bounds.maxOf(args) : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        float least = Float.NEGATIVE_INFINITY;
        for (Field arg : args) {
            least = Math.max(least, arg.minimum());
        }
        return least;
    }

    @Override
    public float maximum() {
        float most = Float.NEGATIVE_INFINITY;
        for (Field arg : args) {
            most = Math.max(most, arg.maximum());
        }
        return most + smoothness / 4 * (args.size() - 1);
    }

    @Override
    public boolean distance() {
        return Check.allDistances(args);
    }

    @Override
    public List<Field> children() {
        return args;
    }
}
