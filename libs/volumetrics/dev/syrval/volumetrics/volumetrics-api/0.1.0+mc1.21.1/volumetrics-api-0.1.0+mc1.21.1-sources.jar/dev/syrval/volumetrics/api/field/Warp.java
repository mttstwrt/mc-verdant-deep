package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * A field read at points pushed about by a noise, up to {@code strength} blocks along each axis: lumpy, billowy
 * outlines for the cost of three noises. The noise is written as a noise node's fields without its type.
 * {@code {"type": "volumetrics:warp", "noise": {"scale": 24, "octaves": 2}, "strength": 6, "field": {...}}}. A warped
 * distance is no longer exact, so keep the strength below the features it bends.
 */
public record Warp(Noise noise, float strength, Field field) implements Field {
    public static final MapCodec<Warp> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Noise.MAP_CODEC.codec().fieldOf("noise").forGetter(Warp::noise),
            Check.notNegative("warp.strength").fieldOf("strength").forGetter(Warp::strength),
            Field.CODEC.fieldOf("field").forGetter(Warp::field)
    ).apply(instance, Warp::new));

    public Warp {
        Objects.requireNonNull(noise, "warp.noise");
        Check.notNegative(strength, "warp.strength");
        Objects.requireNonNull(field, "warp.field");
    }

    @Override
    public FieldType type() {
        return FieldTypes.WARP;
    }

    @Override
    public FieldBounds bounds() {
        return field.bounds().expand(strength);
    }

    @Override
    public float minimum() {
        return field.distance() ? field.minimum() - strength : field.minimum();
    }

    @Override
    public float maximum() {
        return field.distance() ? field.maximum() + strength : field.maximum();
    }

    @Override
    public boolean distance() {
        return field.distance();
    }

    @Override
    public List<Field> children() {
        return List.of(noise, field);
    }
}
