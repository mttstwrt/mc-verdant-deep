package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

/**
 * The bounds of one number of a medium file, with the name it has there, so that a file and a record built in Java are
 * refused with the same message naming the field: in the codec as a data error, in a record's constructor as an
 * exception. The constants are in {@link Ranges}.
 */
record Range(String name, float min, float max) {
    Codec<Float> codec() {
        return Codec.FLOAT.validate(value -> within(value) ? DataResult.success(value) : DataResult.error(() -> message(value)));
    }

    /** @throws IllegalArgumentException outside the bounds, or not a number */
    float check(float value) {
        if (!within(value)) {
            throw new IllegalArgumentException(message(value));
        }
        return value;
    }

    private boolean within(float value) {
        return value >= min && value <= max;
    }

    private String message(float value) {
        return name + " must be from " + min + " to " + max + ", got " + value;
    }
}
