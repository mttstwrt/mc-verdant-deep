package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * A shape as gas: 1 inside it, thinning to 0 over its outermost {@code edge} blocks (smoothly, as GLSL's
 * {@code smoothstep}), 0 outside. {@code {"type": "volumetrics:inside", "shape": {...}, "edge": 12}}; an edge of 0,
 * the default, is a hard surface.
 */
public record Inside(Field shape, float edge) implements Field {
    public static final MapCodec<Inside> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("shape").forGetter(Inside::shape),
            Check.notNegative("inside.edge").optionalFieldOf("edge", 0f).forGetter(Inside::edge)
    ).apply(instance, Inside::new));

    public Inside {
        Objects.requireNonNull(shape, "inside.shape");
        Check.notNegative(edge, "inside.edge");
    }

    @Override
    public FieldType type() {
        return FieldTypes.INSIDE;
    }

    @Override
    public FieldBounds bounds() {
        return shape.distance() ? shape.bounds() : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return 1f;
    }

    @Override
    public List<Field> children() {
        return List.of(shape);
    }
}
