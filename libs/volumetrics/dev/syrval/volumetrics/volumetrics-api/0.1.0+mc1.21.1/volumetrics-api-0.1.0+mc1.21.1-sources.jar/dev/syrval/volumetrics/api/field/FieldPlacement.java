package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.placement.BlockRule;
import dev.syrval.volumetrics.api.placement.PlacementRule;
import java.util.Objects;

/**
 * A field placed by data where a rule finds something: an entry of the
 * {@link dev.syrval.volumetrics.api.VolumetricsRegistries#PLACED_FIELD} registry,
 * {@code data/<namespace>/volumetrics/placed_field/<name>.json}, a {@link PlacedField} with its rule. An abandoned
 * castle's dust in every room ({@link dev.syrval.volumetrics.api.placement.StructureRule}), a glow round every
 * allay ({@link dev.syrval.volumetrics.api.placement.EntityRule}). Not at every block: a field per block is what a
 * source is for. A field a dimension always has is an {@link Ambient} entry.
 *
 * <pre>{@code
 * { "medium": "castles:dust", "mode": "simulated", "formation": 0.02,
 *   "field": { "type": "volumetrics:mul", "args": [
 *     { "type": "volumetrics:inside", "shape": { "type": "volumetrics:piece_box" }, "edge": 1 },
 *     { "type": "volumetrics:constant", "value": 0.15 } ] },
 *   "rule": { "type": "volumetrics:structure", "structures": "#castles:abandoned" } }
 * }</pre>
 */
public record FieldPlacement(PlacedField placed, PlacementRule rule) {
    private static final String AT_BLOCKS = "A field is placed by an entity or a structure rule, not at every block";

    public static final Codec<FieldPlacement> CODEC = RecordCodecBuilder.<FieldPlacement>create(instance -> instance.group(
            PlacedField.MAP_CODEC.forGetter(FieldPlacement::placed),
            PlacementRule.CODEC.fieldOf("rule").forGetter(FieldPlacement::rule)
    ).apply(instance, FieldPlacement::ofCodec)).validate(placement -> placement == null
            ? DataResult.error(() -> AT_BLOCKS) : DataResult.success(placement));

    public FieldPlacement {
        Objects.requireNonNull(placed, "placed");
        Objects.requireNonNull(rule, "rule");
        if (rule instanceof BlockRule) {
            throw new IllegalArgumentException(AT_BLOCKS);
        }
    }

    private static FieldPlacement ofCodec(PlacedField placed, PlacementRule rule) {
        return rule instanceof BlockRule ? null : new FieldPlacement(placed, rule);
    }
}
