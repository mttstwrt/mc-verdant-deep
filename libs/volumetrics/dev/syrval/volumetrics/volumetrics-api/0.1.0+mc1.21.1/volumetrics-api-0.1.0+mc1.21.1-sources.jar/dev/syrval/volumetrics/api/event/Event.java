package dev.syrval.volumetrics.api.event;

import com.mojang.serialization.Codec;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;

/**
 * A one-shot change to the gas, fired at a place with {@link dev.syrval.volumetrics.api.Inputs#fire}: a {@link Blast},
 * a {@link Puff}, a {@link Clear} or a {@link Gust}. Written as an object with its {@code type} ({@link Events}).
 * Positions in an event are relative to where it is fired; it is not turned.
 *
 * <p>Each names the media it changes; none for every medium it may change. Only cosmetic media change: an event passes
 * over {@code analytic} and {@code gameplay} media whatever it names (see the package).
 *
 * <p>More events may come in a minor version of the API: a mod's own {@code switch} over them needs a {@code default}
 * branch ({@code docs/API-CHANGES.md} in the library).
 */
public sealed interface Event permits Blast, Puff, Clear, Gust {
    Codec<Event> CODEC = Events.CODEC;

    /** The id it is written with. */
    ResourceLocation type();

    /** The media it changes; empty for every cosmetic medium. */
    List<ResourceKey<Medium>> media();
}
