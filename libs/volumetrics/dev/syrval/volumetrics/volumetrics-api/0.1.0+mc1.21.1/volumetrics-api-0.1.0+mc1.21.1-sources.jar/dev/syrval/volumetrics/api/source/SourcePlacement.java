package dev.syrval.volumetrics.api.source;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.placement.PlacementRule;
import java.util.Objects;

/**
 * A source placed by data: an entry of the {@link dev.syrval.volumetrics.api.VolumetricsRegistries#SOURCE} registry,
 * {@code data/<namespace>/volumetrics/source/<name>.json}, a {@link Source} with the rule that says where it is.
 * Loaded with the world and sent to clients; each rule is evaluated where its information is (block rules on each
 * client).
 *
 * <pre>{@code
 * { "medium": "volumetrics:smoke", "shape": { "type": "volumetrics:sphere", "radius": 0.6 }, "rate": 2.5,
 *   "velocity": { "y": 0.8 },
 *   "rule": { "type": "volumetrics:block", "blocks": "#minecraft:campfires", "state": { "lit": "true" },
 *             "offset": { "y": 1.2 } } }
 * }</pre>
 */
public record SourcePlacement(Source source, PlacementRule rule) {
    public static final Codec<SourcePlacement> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Source.MAP_CODEC.forGetter(SourcePlacement::source),
            PlacementRule.CODEC.fieldOf("rule").forGetter(SourcePlacement::rule)
    ).apply(instance, SourcePlacement::new));

    public SourcePlacement {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(rule, "rule");
    }
}
