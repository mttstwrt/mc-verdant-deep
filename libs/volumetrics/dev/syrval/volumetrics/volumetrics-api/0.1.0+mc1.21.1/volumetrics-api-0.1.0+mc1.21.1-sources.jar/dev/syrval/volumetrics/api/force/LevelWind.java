package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.world.phys.Vec3;

/**
 * A contribution to the level's wind: blocks per second towards east ({@code x}) and south ({@code z}), everywhere or
 * within an {@code area} (a box of columns and heights). Contributed from server code, one handle a mod; several add,
 * and a mod that wants it to change over time updates its handle (a weather mod's gusts, a storm moving in). The
 * server carries the level's ambient fields on by the contributions without an area, and sends them all to its players
 * with that carried offset, so a player who joins late sees the clouds where everyone else does. The wind is read once a
 * step at the camera: it is the same over the whole simulation, which is what keeps it cheap.
 *
 * <pre>{@code
 * { "type": "volumetrics:level_wind", "x": 3, "z": 1 }
 * }</pre>
 *
 * @param area where it blows; everywhere when empty
 */
public record LevelWind(float x, float z, Optional<Area> area) implements ForceKind {
    private static final Limits SPEED = Limits.speed("level_wind speed");

    public static final MapCodec<LevelWind> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            SPEED.codec().optionalFieldOf("x", 0f).forGetter(LevelWind::x),
            SPEED.codec().optionalFieldOf("z", 0f).forGetter(LevelWind::z),
            Area.CODEC.optionalFieldOf("area").forGetter(LevelWind::area)
    ).apply(instance, LevelWind::new));

    public LevelWind {
        SPEED.check(x);
        SPEED.check(z);
        Objects.requireNonNull(area, "area");
    }

    /** Everywhere. */
    public LevelWind(float x, float z) {
        this(x, z, Optional.empty());
    }

    @Override
    public ForceType type() {
        return ForceKinds.LEVEL_WIND;
    }

    @Override
    public boolean levelWide() {
        return true;
    }

    /** A box of world blocks, both corners inside, in either order. */
    public record Area(Vec3 from, Vec3 to) {
        public static final Codec<Area> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                VolumetricsCodecs.XYZ.fieldOf("from").forGetter(Area::from),
                VolumetricsCodecs.XYZ.fieldOf("to").forGetter(Area::to)
        ).apply(instance, Area::new));

        public Area {
            Objects.requireNonNull(from, "from");
            Objects.requireNonNull(to, "to");
        }

        public boolean contains(double x, double y, double z) {
            return x >= Math.min(from.x, to.x) && x <= Math.max(from.x, to.x) && y >= Math.min(from.y, to.y)
                    && y <= Math.max(from.y, to.y) && z >= Math.min(from.z, to.z) && z <= Math.max(from.z, to.z);
        }
    }
}
