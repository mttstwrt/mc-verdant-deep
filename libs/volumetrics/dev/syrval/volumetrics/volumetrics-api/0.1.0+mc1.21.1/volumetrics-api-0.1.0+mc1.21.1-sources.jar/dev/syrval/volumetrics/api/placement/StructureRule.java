package dev.syrval.volumetrics.api.placement;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.List;
import java.util.Objects;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.phys.Vec3;

/**
 * At every piece of a structure (or at every whole structure) of the kinds named, from the server: the library looks
 * at the structures each chunk holds as the chunk loads, places each piece's source, force or field once, in the chunk
 * that holds the middle of the piece, scoped to that chunk, and sends it to the players near it. Attached at the middle
 * of the piece's floor ({@link Attachment.AtPosition}), moved by {@code offset}, in the world's frame. A shape or field
 * written with {@code volumetrics:piece_box} is given the piece's own box there
 * ({@link dev.syrval.volumetrics.api.field.PieceBox}), so one entry fills every room of a castle whatever its size.
 *
 * <pre>{@code
 * "rule": { "type": "volumetrics:structure", "structures": "#minecraft:village", "each": "piece" }
 * }</pre>
 *
 * <p>{@code structures} is one id, one {@code #tag}, or a list of either; they are looked up on the server only
 * (clients do not have the structure registry), so a name no datapack has matches nothing. What a rule placed stays
 * as it was placed until its chunk unloads: a retune of the entry reaches the chunks that load after it.
 *
 * @param structures the structures, by id or tag
 * @param each       a placement at each piece, or one at each whole structure
 * @param offset     from the middle of the piece's (or the structure's) floor, in blocks
 */
public record StructureRule(List<Either<TagKey<Structure>, ResourceKey<Structure>>> structures, Each each, Vec3 offset)
        implements PlacementRule {
    private static final Codec<Either<TagKey<Structure>, ResourceKey<Structure>>> NAME =
            Codec.either(TagKey.hashedCodec(Registries.STRUCTURE), ResourceKey.codec(Registries.STRUCTURE));

    /** One name, or a list. */
    private static final Codec<List<Either<TagKey<Structure>, ResourceKey<Structure>>>> NAMES = Codec.either(NAME, NAME.listOf())
            .xmap(either -> either.map(List::of, list -> list), list -> list.size() == 1 ? Either.left(list.getFirst()) : Either.right(list));

    public static final MapCodec<StructureRule> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            NAMES.fieldOf("structures").forGetter(StructureRule::structures),
            Each.CODEC.optionalFieldOf("each", Each.PIECE).forGetter(StructureRule::each),
            VolumetricsCodecs.XYZ.optionalFieldOf("offset", Vec3.ZERO).forGetter(StructureRule::offset)
    ).apply(instance, StructureRule::new));

    public StructureRule {
        structures = List.copyOf(structures);
        if (structures.isEmpty()) {
            throw new IllegalArgumentException("A structure rule names at least one structure or tag");
        }
        Objects.requireNonNull(each, "each");
        Objects.requireNonNull(offset, "offset");
    }

    @Override
    public RuleType type() {
        return PlacementRules.STRUCTURE;
    }

    /** What a structure rule places at. */
    public enum Each implements StringRepresentable {
        /** Each piece of the structure: a room, a corridor, a tower. */
        PIECE("piece"),
        /** The whole structure once, its box the box round all its pieces. */
        STRUCTURE("structure");

        public static final Codec<Each> CODEC = StringRepresentable.fromEnum(Each::values);

        private final String name;

        Each(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }
}
