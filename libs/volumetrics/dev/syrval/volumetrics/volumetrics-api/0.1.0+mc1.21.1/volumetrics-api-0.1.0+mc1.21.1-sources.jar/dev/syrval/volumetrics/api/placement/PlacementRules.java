package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;

/**
 * Every {@link PlacementRule}, by the {@code type} it is written with: {@code volumetrics:block} ({@link BlockRule},
 * on clients), {@code volumetrics:entity} ({@link EntityRule}, on clients) and {@code volumetrics:structure}
 * ({@link StructureRule}, on the server).
 */
public final class PlacementRules {
    private static final Map<ResourceLocation, RuleType> TYPES = new LinkedHashMap<>();

    public static final RuleType BLOCK = add("block", BlockRule.MAP_CODEC);
    public static final RuleType ENTITY = add("entity", EntityRule.MAP_CODEC);
    public static final RuleType STRUCTURE = add("structure", StructureRule.MAP_CODEC);

    private static final Codec<RuleType> TYPE_CODEC = ResourceLocation.CODEC.comapFlatMap(PlacementRules::get, RuleType::id);

    private PlacementRules() {}

    static Codec<PlacementRule> codec() {
        return TYPE_CODEC.dispatch("type", PlacementRule::type, RuleType::codec);
    }

    public static Collection<RuleType> all() {
        return Collections.unmodifiableCollection(TYPES.values());
    }

    private static DataResult<RuleType> get(ResourceLocation id) {
        RuleType type = TYPES.get(id);
        if (type != null) {
            return DataResult.success(type);
        }
        return DataResult.error(() -> "Not a placement rule: " + id);
    }

    private static RuleType add(String name, MapCodec<? extends PlacementRule> codec) {
        RuleType type = new RuleType(id(name), codec);
        TYPES.put(type.id(), type);
        return type;
    }

    private static ResourceLocation id(String name) {
        return ResourceLocation.fromNamespaceAndPath("volumetrics", name);
    }
}
