package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/**
 * Every {@link PlacementRule}, by the {@code type} it is written with. Two ids are reserved for rules that come later:
 * {@code volumetrics:entity} (entity types or a tag, on clients) and {@code volumetrics:structure} (structure pieces, on
 * the server); a file naming one fails to load until then.
 */
public final class PlacementRules {
    private static final Map<ResourceLocation, RuleType> TYPES = new LinkedHashMap<>();

    public static final RuleType BLOCK = add("block", BlockRule.MAP_CODEC);

    /** Ids kept for rules that come later. */
    public static final Set<ResourceLocation> RESERVED = Set.of(id("entity"), id("structure"));

    private static final Codec<RuleType> TYPE_CODEC = ResourceLocation.CODEC.comapFlatMap(PlacementRules::get, RuleType::id);

    private PlacementRules() {}

    static Codec<PlacementRule> codec() {
        return TYPE_CODEC.dispatch("type", PlacementRule::type, RuleType::codec);
    }

    public static Collection<RuleType> all() {
        return Collections.unmodifiableCollection(TYPES.values());
    }

    private static DataResult<RuleType> get(ResourceLocation id) {
        RuleType type = TYPES.get(id);
        if (type != null) {
            return DataResult.success(type);
        }
        if (RESERVED.contains(id)) {
            return DataResult.error(() -> "The placement rule " + id + " is not available yet");
        }
        return DataResult.error(() -> "Not a placement rule: " + id);
    }

    private static RuleType add(String name, MapCodec<? extends PlacementRule> codec) {
        RuleType type = new RuleType(id(name), codec);
        TYPES.put(type.id(), type);
        return type;
    }

    private static ResourceLocation id(String name) {
        return ResourceLocation.fromNamespaceAndPath("volumetrics", name);
    }
}
