/**
 * Where sources and forces are: {@link dev.syrval.volumetrics.api.placement.Attachment}s, what a source or force is
 * placed on from code, and {@link dev.syrval.volumetrics.api.placement.PlacementRule}s, which data uses to place them
 * wherever something is found ({@link dev.syrval.volumetrics.api.placement.BlockRule}: at every block of a kind).
 * Shared by {@link dev.syrval.volumetrics.api.source} and {@link dev.syrval.volumetrics.api.force}. Records only:
 * immutable, side-neutral, any thread.
 */
package dev.syrval.volumetrics.api.placement;
