package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.placement.Attachment;

/**
 * Something a mod added, there until it is closed or its {@link Scope} ends. {@code T} is the definition it was added
 * with, which {@link #update} replaces. Implemented by the engine.
 *
 * <p>Any thread. A change takes effect at the engine's next step (a client's) or tick (a server's), not during the call.
 * A handle that is no longer alive ignores {@link #update} and {@link #moveTo} (in a development environment it says
 * so in the log, once), so a mod need not track whether its scope has ended.
 */
public interface Handle<T> {
    /**
     * Replaces the definition. Nothing happens once the handle is not alive.
     *
     * @throws IllegalArgumentException if the definition cannot be added here; the handle keeps the one it had
     */
    void update(T definition);

    /**
     * Puts it on another attachment, keeping its definition and scope. Nothing happens once the handle is not alive.
     * One attached to an entity follows it without this.
     */
    void moveTo(Attachment attachment);

    /** Removes what the handle added. Closing it again, or after its scope ended, does nothing. */
    void close();

    /**
     * False once it is closed: by the mod, by {@link Owner#closeAll}, by the end of its scope or its level, or because
     * it was refused when added.
     */
    boolean alive();
}
