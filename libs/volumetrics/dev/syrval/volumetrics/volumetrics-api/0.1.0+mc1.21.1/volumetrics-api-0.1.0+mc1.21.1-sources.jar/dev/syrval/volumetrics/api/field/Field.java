package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.Codec;
import java.util.List;

/**
 * A field: a number at every point of the world and moment, written as a tree of nodes. Densities (1 is pure gas)
 * for placed fields, signed distances in blocks for shapes (negative inside, positive outside), and anything between
 * as the arithmetic makes it. What gas fills (a {@link PlacedField}), and the shapes of sources and forces.
 *
 * <p>Written as an object whose {@code type} names the node, {@code {"type": "volumetrics:sphere", ...}}, or as the id
 * of a named field ({@link dev.syrval.volumetrics.api.VolumetricsRegistries#FIELD}), which is short for a
 * {@link Ref}. {@link FieldTypes} lists the nodes; {@link Fields} builds them in Java.
 *
 * <p>The engine compiles a tree once, when it is added or its registry loads, into a compact program that the
 * simulation and the renderers evaluate the same way; nothing here is read while gas is simulated or drawn. Positions
 * are world coordinates in blocks: the engine works relative to the camera, so a field far from the world's origin is
 * as exact as one near it.
 *
 * <p>Every node states what it can be, so an engine can cull it and size its budgets without evaluating it:
 * {@link #bounds}, {@link #minimum}, {@link #maximum}. All conservative, and computed from the node's children; a
 * {@link Ref} states nothing until the engine has looked it up. Records only: immutable, side-neutral, any thread.
 */
public interface Field {
    /** A node object, or a named field's id. Lazy, because nodes hold fields and their codecs this one. */
    Codec<Field> CODEC = Codec.lazyInitialized(FieldTypes::fieldCodec);

    /** Which node this is. */
    FieldType type();

    /**
     * Where the node can matter, in world blocks. For a {@link #distance distance}, the box outside which the point is
     * outside the shape (the distance is 0 or more); for anything else, the box outside which the value is 0 or less,
     * which is no gas. {@link FieldBounds#EVERYWHERE} when the node cannot say.
     */
    FieldBounds bounds();

    /** The least the node can be anywhere; negative infinity when it cannot say. */
    float minimum();

    /** The most the node can be anywhere; positive infinity when it cannot say. */
    float maximum();

    /**
     * Whether the value is a signed distance in blocks to a surface, negative inside: true for shapes, and for the
     * space nodes, {@code min}, {@code max} and their smooth forms over shapes alone.
     */
    default boolean distance() {
        return false;
    }

    /**
     * Whether the node can only be evaluated by the engine's CPU side (the simulation, the server), not by a renderer
     * on the GPU: a node that reads blocks, or code. A drawn field must not have one. True if any child has.
     */
    default boolean cpuOnly() {
        for (Field child : children()) {
            if (child.cpuOnly()) {
                return true;
            }
        }
        return false;
    }

    /** The node's fields, in the order it names them. */
    default List<Field> children() {
        return List.of();
    }

    /** {@code mul} of this and another: this field where the other is 1, none where it is 0. */
    default Field times(Field other) {
        return Fields.mul(this, other);
    }

    /** {@code add} of this and another. */
    default Field plus(Field other) {
        return Fields.add(this, other);
    }

    /** This field moved by an offset in blocks. */
    default Field translated(double x, double y, double z) {
        return new Translate(new net.minecraft.world.phys.Vec3(x, y, z), this);
    }
}
