package dev.syrval.volumetrics.api.spi;

import dev.syrval.volumetrics.api.Capabilities;
import dev.syrval.volumetrics.api.Owner;
import dev.syrval.volumetrics.api.VolumetricsApi;
import dev.syrval.volumetrics.api.query.GasQueries;
import net.minecraft.world.level.Level;

/**
 * The engine behind {@link VolumetricsApi}. The library implements it once and lists the implementation in
 * {@code META-INF/services/dev.syrval.volumetrics.api.spi.VolumetricsEngine}; {@code VolumetricsApi} finds it with
 * {@link java.util.ServiceLoader} on first use and keeps it. Not for mods: it changes with the engine, outside the
 * API's version.
 *
 * <p>Any thread.
 */
public interface VolumetricsEngine {
    /** The owner for a mod, the same one for every call with the same id. {@code modId} is a valid namespace. */
    Owner owner(String modId);

    /** The queries of a level, on the side it belongs to. */
    GasQueries queries(Level level);

    Capabilities capabilities();
}
