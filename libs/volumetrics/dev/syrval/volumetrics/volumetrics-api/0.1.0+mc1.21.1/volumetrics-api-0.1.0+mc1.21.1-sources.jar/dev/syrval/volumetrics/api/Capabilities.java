package dev.syrval.volumetrics.api;

import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * What the installed engine and renderer support. Renderers differ by Minecraft version and may lag one another, so a
 * mod asks about a feature here rather than checking versions; data can name a fallback where a feature may be
 * missing. Implemented by the engine; from {@link VolumetricsApi#capabilities}. Any thread.
 */
public interface Capabilities {
    /**
     * The renderer's name, such as {@code volumetrics:renderpearl_march}; empty on a dedicated server, which draws
     * nothing. For logs and bug reports: ask {@link #has} about features rather than matching names.
     */
    Optional<String> renderer();

    /** The version of the field-program format the engine evaluates; 0 while it evaluates none. */
    int fieldProgramVersion();

    /**
     * Whether a feature is there, by an open id: {@code volumetrics:froxels}, {@code volumetrics:chromatic_extinction},
     * {@code volumetrics:gameplay_server} and the like. False for any id the engine does not know. Known so far:
     * {@code volumetrics:drawn_field_programs}, a client whose renderer draws drawn fields of any form the GPU can run,
     * not only the fog form ({@code inside} of a cylinder, box or slab times a profile, a coverage of value noise and a
     * condition); {@code volumetrics:drawn_height_above_surface}, one whose drawn fields may also read
     * {@code height_above_surface}; {@code volumetrics:coloured_lamps}, one that lights gas near a lamp in the lamp's
     * colour ({@link dev.syrval.volumetrics.api.lamp.Lamp}) rather than the game's one lamp colour.
     */
    boolean has(ResourceLocation feature);
}
