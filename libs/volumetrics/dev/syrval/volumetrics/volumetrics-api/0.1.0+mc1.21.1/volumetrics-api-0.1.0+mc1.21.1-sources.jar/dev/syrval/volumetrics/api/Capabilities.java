package dev.syrval.volumetrics.api;

import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * What the installed engine and renderer support. Renderers differ by Minecraft version and may lag one another, so a
 * mod asks about a feature here rather than checking versions; data can name a fallback where a feature may be
 * missing. Implemented by the engine; from {@link VolumetricsApi#capabilities}. Any thread.
 */
public interface Capabilities {
    /**
     * The renderer's name, such as {@code volumetrics:renderpearl_march}; empty on a dedicated server, which draws
     * nothing. For logs and bug reports: ask {@link #has} about features rather than matching names.
     */
    Optional<String> renderer();

    /** The version of the field-program format the engine evaluates; 0 while it evaluates none. */
    int fieldProgramVersion();

    /**
     * Whether a feature is there, by an open id: {@code volumetrics:froxels}, {@code volumetrics:chromatic_extinction},
     * {@code volumetrics:gameplay_server} and the like. False for any id the engine does not know.
     */
    boolean has(ResourceLocation feature);
}
