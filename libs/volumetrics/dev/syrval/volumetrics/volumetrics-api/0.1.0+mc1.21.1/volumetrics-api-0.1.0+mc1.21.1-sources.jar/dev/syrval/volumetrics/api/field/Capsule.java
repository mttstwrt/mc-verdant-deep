package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import net.minecraft.world.phys.Vec3;

/**
 * Every point within {@code radius} blocks of the line from {@code from} to {@code to}: a rod with round ends, as the
 * signed distance to its surface. {@code {"type": "volumetrics:capsule", "from": {...}, "to": {...}, "radius": 3}}.
 */
public record Capsule(Vec3 from, Vec3 to, float radius) implements Field {
    public static final MapCodec<Capsule> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            VolumetricsCodecs.XYZ.fieldOf("from").forGetter(Capsule::from),
            VolumetricsCodecs.XYZ.fieldOf("to").forGetter(Capsule::to),
            Check.positive("capsule.radius").fieldOf("radius").forGetter(Capsule::radius)
    ).apply(instance, Capsule::new));

    public Capsule {
        Check.position(from, "capsule.from");
        Check.position(to, "capsule.to");
        Check.positive(radius, "capsule.radius");
    }

    @Override
    public FieldType type() {
        return FieldTypes.CAPSULE;
    }

    @Override
    public FieldBounds bounds() {
        return new FieldBounds(Math.min(from.x, to.x), Math.min(from.y, to.y), Math.min(from.z, to.z),
                Math.max(from.x, to.x), Math.max(from.y, to.y), Math.max(from.z, to.z)).expand(radius);
    }

    @Override
    public float minimum() {
        return -radius;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }

    @Override
    public boolean distance() {
        return true;
    }
}
