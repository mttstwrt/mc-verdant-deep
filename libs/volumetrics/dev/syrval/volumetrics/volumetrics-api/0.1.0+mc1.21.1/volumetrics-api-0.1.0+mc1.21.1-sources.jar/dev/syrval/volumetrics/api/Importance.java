package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

/**
 * How much a medium, source, placed field or decorator matters when the engine cannot keep everything: when a budget
 * is full (kinds of gas, drawn fields, decorators), {@link #AMBIENT} goes first, then distance decides, and
 * {@link #ESSENTIAL} stays as long as anything does. Quality settings scale the budgets, never this.
 *
 * <p>Declared from most kept to least, so the natural order ranks them.
 */
public enum Importance implements StringRepresentable {
    /** Kept while anything is: gas that tells the player something, such as a creature's warning mist. */
    ESSENTIAL("essential"),
    /** The default. */
    NORMAL("normal"),
    /** Atmosphere that may go first: haze, dust, distant smoke. */
    AMBIENT("ambient");

    public static final Codec<Importance> CODEC = StringRepresentable.fromEnum(Importance::values);

    private final String name;

    Importance(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
