package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * 0 up to {@code from}, 1 from {@code to}, and a smooth S between, as GLSL's {@code smoothstep}:
 * {@code {"type": "volumetrics:smoothstep", "input": {...}, "from": 0.3, "to": 0.7}}.
 */
public record Smoothstep(Field input, float from, float to) implements Field {
    public static final MapCodec<Smoothstep> MAP_CODEC = RecordCodecBuilder.<Smoothstep>mapCodec(instance -> instance.group(
            Field.CODEC.fieldOf("input").forGetter(Smoothstep::input),
            Check.number("smoothstep.from").fieldOf("from").forGetter(Smoothstep::from),
            Check.number("smoothstep.to").fieldOf("to").forGetter(Smoothstep::to)
    ).apply(instance, (input, from, to) -> to > from ? new Smoothstep(input, from, to) : null)).validate(step -> step == null
            ? DataResult.error(() -> "smoothstep.to must be above smoothstep.from") : DataResult.success(step));

    public Smoothstep {
        Objects.requireNonNull(input, "smoothstep.input");
        Check.number(from, "smoothstep.from");
        Check.number(to, "smoothstep.to");
        if (!(to > from)) {
            throw new IllegalArgumentException("smoothstep.to must be above smoothstep.from, got " + from + " and " + to);
        }
    }

    @Override
    public FieldType type() {
        return FieldTypes.SMOOTHSTEP;
    }

    @Override
    public FieldBounds bounds() {
        return from >= 0f && !input.distance() ? input.bounds() : FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return input.minimum() >= to ? 1f : input.minimum() > from ? step(input.minimum()) : 0f;
    }

    @Override
    public float maximum() {
        return input.maximum() <= from ? 0f : input.maximum() < to ? step(input.maximum()) : 1f;
    }

    private float step(float x) {
        float t = Math.clamp((x - from) / (to - from), 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
