package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import net.minecraft.world.phys.Vec3;

/** Codecs the API's records share, for mods that write records of their own in the same form. */
public final class VolumetricsCodecs {
    /** A colour as {@code 0xRRGGBB}, written {@code "#RRGGBB"}; the shader takes it as linear. */
    public static final Codec<Integer> RGB = Codec.STRING.comapFlatMap(VolumetricsCodecs::parseRgb,
            rgb -> String.format(Locale.ROOT, "#%06X", rgb));

    /**
     * A position or a direction in blocks, written {@code {"x": 1, "y": 2, "z": 3}}; a coordinate left out is 0. Each
     * must be finite.
     */
    public static final Codec<Vec3> XYZ = RecordCodecBuilder.<Vec3>create(instance -> instance.group(
            Codec.DOUBLE.optionalFieldOf("x", 0.0).forGetter(vector -> vector.x),
            Codec.DOUBLE.optionalFieldOf("y", 0.0).forGetter(vector -> vector.y),
            Codec.DOUBLE.optionalFieldOf("z", 0.0).forGetter(vector -> vector.z)
    ).apply(instance, Vec3::new)).validate(vector -> Double.isFinite(vector.x) && Double.isFinite(vector.y)
            && Double.isFinite(vector.z) ? DataResult.success(vector) : DataResult.error(() -> "A position must be finite, got " + vector));

    private VolumetricsCodecs() {}

    /** @throws IllegalArgumentException if {@code rgb} has bits above {@code 0xFFFFFF}; {@code name} says which field */
    public static int requireRgb(int rgb, String name) {
        if ((rgb & 0xFF000000) != 0) {
            throw new IllegalArgumentException(name + " must be a colour 0xRRGGBB, got 0x" + Integer.toHexString(rgb));
        }
        return rgb;
    }

    private static DataResult<Integer> parseRgb(String text) {
        if (text.length() != 7 || text.charAt(0) != '#') {
            return DataResult.error(() -> "A colour must look like #RRGGBB, got " + text);
        }
        int rgb = 0;
        for (int i = 1; i < 7; i++) {
            int digit = Character.digit(text.charAt(i), 16);
            if (digit < 0) {
                return DataResult.error(() -> "A colour must look like #RRGGBB, got " + text);
            }
            rgb = rgb << 4 | digit;
        }
        return DataResult.success(rgb);
    }
}
