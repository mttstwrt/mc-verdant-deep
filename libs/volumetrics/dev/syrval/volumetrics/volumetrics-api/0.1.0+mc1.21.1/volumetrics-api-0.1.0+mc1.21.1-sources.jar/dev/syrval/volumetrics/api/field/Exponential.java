package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Objects;

/**
 * A profile that thins as air does: {@code start} at {@code from}, and by a factor of e every {@code scale_height}
 * of its input further (a negative scale height thickens instead), held at its ends below {@code from} and above
 * {@code to}: {@code start * exp(-(clamp(input, from, to) - from) / scale_height)}. The input is the altitude unless
 * another field is given, such as a shape's distance.
 * {@code {"type": "volumetrics:exponential", "from": 62, "to": 120, "start": 0.4, "scale_height": 30}}.
 */
public record Exponential(Field input, float from, float to, float start, float scaleHeight) implements Field {
    public static final MapCodec<Exponential> MAP_CODEC = RecordCodecBuilder.<Exponential>mapCodec(instance -> instance.group(
            Field.CODEC.optionalFieldOf("input", Altitude.INSTANCE).forGetter(Exponential::input),
            Check.number("exponential.from").fieldOf("from").forGetter(Exponential::from),
            com.mojang.serialization.Codec.FLOAT.optionalFieldOf("to", Float.POSITIVE_INFINITY).forGetter(Exponential::to),
            Check.number("exponential.start").fieldOf("start").forGetter(Exponential::start),
            Check.number("exponential.scale_height").fieldOf("scale_height").forGetter(Exponential::scaleHeight)
    ).apply(instance, (input, from, to, start, scale) -> valid(from, to, scale) == null
            ? new Exponential(input, from, to, start, scale) : null)).validate(exponential -> exponential == null
            ? DataResult.error(() -> "exponential needs to above from and a scale_height other than 0")
            : DataResult.success(exponential));

    public Exponential {
        Objects.requireNonNull(input, "exponential.input");
        Check.number(from, "exponential.from");
        Check.number(start, "exponential.start");
        String problem = valid(from, to, scaleHeight);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }
    }

    /** Over the altitude, without an end above. */
    public Exponential(float from, float start, float scaleHeight) {
        this(Altitude.INSTANCE, from, Float.POSITIVE_INFINITY, start, scaleHeight);
    }

    private static String valid(float from, float to, float scaleHeight) {
        if (!(to > from) || Float.isNaN(to) || to == Float.NEGATIVE_INFINITY) {
            return "exponential.to must be above exponential.from, got " + from + " and " + to;
        }
        if (scaleHeight == 0f || !Float.isFinite(scaleHeight)) {
            return "exponential.scale_height must be a finite number other than 0, got " + scaleHeight;
        }
        return null;
    }

    /** The value at the input {@code x}. */
    public float at(float x) {
        return start * (float) Math.exp(-(Math.clamp(x, from, to) - from) / scaleHeight);
    }

    @Override
    public FieldType type() {
        return FieldTypes.EXPONENTIAL;
    }

    @Override
    public FieldBounds bounds() {
        return maximum() > 0 ? FieldBounds.EVERYWHERE : FieldBounds.NOWHERE;
    }

    @Override
    public float minimum() {
        return Math.min(start, end());
    }

    @Override
    public float maximum() {
        return Math.max(start, end());
    }

    /** The value at {@code to} and above: 0 or infinite without an end, by the sign of the scale height. */
    private float end() {
        if (start == 0f) {
            return 0f;
        }
        return start * (float) Math.exp(-((double) to - from) / scaleHeight);
    }

    @Override
    public List<Field> children() {
        return List.of(input);
    }
}
