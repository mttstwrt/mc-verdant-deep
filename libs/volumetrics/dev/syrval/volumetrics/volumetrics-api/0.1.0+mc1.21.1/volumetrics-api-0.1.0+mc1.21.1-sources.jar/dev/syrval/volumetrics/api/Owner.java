package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.client.ClientInputs;
import dev.syrval.volumetrics.api.condition.ConditionProvider;
import dev.syrval.volumetrics.api.condition.Conditions;
import dev.syrval.volumetrics.api.extend.PlacementRule;
import dev.syrval.volumetrics.api.server.ServerInputs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * A mod's standing with the engine. Everything a mod adds goes through its owner, so every {@link Handle} knows which
 * mod it belongs to, and a mod can take back all of its own at once. Implemented by the engine; a mod gets its owner
 * from {@link VolumetricsApi#owner}, the same one on every call. Any thread.
 */
public interface Owner {
    /** The id of the mod it belongs to. */
    String modId();

    /**
     * Where this mod adds what only this client sees, in a client level. Cheap: a mod may ask each time.
     *
     * @throws IllegalArgumentException if the level is not a client's
     * @throws IllegalStateException    on a dedicated server
     */
    ClientInputs client(Level level);

    /** Where this mod adds what the server places for every player, in a server level. Cheap: a mod may ask each time. */
    ServerInputs server(ServerLevel level);

    /** Closes every handle of this mod that is alive, on either side and in every level: for a mod's own reset. */
    void closeAll();

    /**
     * Registers a condition under an id, for every level on both sides, from the next tick of each: fields and sources
     * naming the id read it ({@link ConditionProvider} says how it is asked). A second registration of the id, by
     * this mod or another, replaces the first (logged), and the values worked out with the old one are dropped. An id
     * nobody registered reads 1, logged once. Register on both sides, in common setup: a server answering for its
     * fields needs it as much as its players do. Any thread. {@link #closeAll} leaves it.
     *
     * @throws IllegalArgumentException for an id of the library's built-in conditions ({@link Conditions})
     */
    @Experimental
    void registerCondition(ResourceLocation id, ConditionProvider provider);

    /**
     * Registers a code-tier placement rule under an id, for every level of its {@linkplain PlacementRule#side side}:
     * the library calls it for each chunk of those levels that loads from then on, and owns what it adds
     * ({@link PlacementRule} says how). Chunks loaded before are not called back; register in common setup (a server
     * rule) or client setup (a client rule), before any level exists. A second registration of the id, by this mod or
     * another, replaces the first (logged): chunks that load afterwards are the new rule's, what the old one added
     * stays until its chunk unloads, and what it was still waiting for ({@code later}) is dropped. Any thread.
     * {@link #closeAll} closes what rules added, as it closes any handle of the mod, and leaves the rules registered.
     */
    @Experimental
    void registerPlacementRule(ResourceLocation id, PlacementRule rule);
}
