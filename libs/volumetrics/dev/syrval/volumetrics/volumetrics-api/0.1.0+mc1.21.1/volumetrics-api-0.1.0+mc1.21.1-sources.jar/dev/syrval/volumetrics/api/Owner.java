package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.api.client.ClientInputs;
import dev.syrval.volumetrics.api.server.ServerInputs;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/**
 * A mod's standing with the engine. Everything a mod adds goes through its owner, so every {@link Handle} knows which
 * mod it belongs to, and a mod can take back all of its own at once. Implemented by the engine; a mod gets its owner
 * from {@link VolumetricsApi#owner}, the same one on every call. Any thread.
 */
public interface Owner {
    /** The id of the mod it belongs to. */
    String modId();

    /**
     * Where this mod adds what only this client sees, in a client level. Cheap: a mod may ask each time.
     *
     * @throws IllegalArgumentException if the level is not a client's
     * @throws IllegalStateException    on a dedicated server
     */
    ClientInputs client(Level level);

    /** Where this mod adds what the server places for every player, in a server level. Cheap: a mod may ask each time. */
    ServerInputs server(ServerLevel level);

    /** Closes every handle of this mod that is alive, on either side and in every level: for a mod's own reset. */
    void closeAll();
}
