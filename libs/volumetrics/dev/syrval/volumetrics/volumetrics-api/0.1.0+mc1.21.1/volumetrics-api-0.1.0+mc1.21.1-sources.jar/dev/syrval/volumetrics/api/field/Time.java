package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;

/**
 * The level's game time in seconds: {@code {"type": "volumetrics:time"}}. The same on every client of a level. A
 * float, so it loses its fractions after some days of game time: use it through shaping that does not need them.
 * A field that reads it changes every step, so the simulation works its target out again every step.
 */
public record Time() implements Field {
    public static final Time INSTANCE = new Time();
    public static final MapCodec<Time> MAP_CODEC = MapCodec.unit(INSTANCE);

    @Override
    public FieldType type() {
        return FieldTypes.TIME;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return 0f;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }
}
