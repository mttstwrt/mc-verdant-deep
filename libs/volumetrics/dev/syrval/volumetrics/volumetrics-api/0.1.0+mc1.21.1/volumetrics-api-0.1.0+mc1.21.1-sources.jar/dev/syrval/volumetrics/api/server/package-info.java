/**
 * The server's side of the API: {@link dev.syrval.volumetrics.api.server.ServerInputs}, what a mod adds from the
 * server for everyone.
 */
package dev.syrval.volumetrics.api.server;
