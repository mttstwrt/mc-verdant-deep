package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.List;
import java.util.Objects;
import net.minecraft.world.phys.Vec3;

/**
 * A field made {@code factor} times larger about {@code pivot} (the origin unless given), its noises with it; a
 * distance stays in blocks. {@code {"type": "volumetrics:scale", "factor": 2, "pivot": {...}, "field": {...}}}.
 */
public record Scale(float factor, Vec3 pivot, Field field) implements Field {
    public static final MapCodec<Scale> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Check.positive("scale.factor").fieldOf("factor").forGetter(Scale::factor),
            VolumetricsCodecs.XYZ.optionalFieldOf("pivot", Vec3.ZERO).forGetter(Scale::pivot),
            Field.CODEC.fieldOf("field").forGetter(Scale::field)
    ).apply(instance, Scale::new));

    public Scale {
        Check.positive(factor, "scale.factor");
        Check.position(pivot, "scale.pivot");
        Objects.requireNonNull(field, "scale.field");
    }

    @Override
    public FieldType type() {
        return FieldTypes.SCALE;
    }

    @Override
    public FieldBounds bounds() {
        FieldBounds inner = field.bounds();
        if (inner.isEmpty()) {
            return inner;
        }
        return new FieldBounds(pivot.x + (inner.minX() - pivot.x) * factor, pivot.y + (inner.minY() - pivot.y) * factor,
                pivot.z + (inner.minZ() - pivot.z) * factor, pivot.x + (inner.maxX() - pivot.x) * factor,
                pivot.y + (inner.maxY() - pivot.y) * factor, pivot.z + (inner.maxZ() - pivot.z) * factor);
    }

    @Override
    public float minimum() {
        return field.distance() ? field.minimum() * factor : field.minimum();
    }

    @Override
    public float maximum() {
        return field.distance() ? field.maximum() * factor : field.maximum();
    }

    @Override
    public boolean distance() {
        return field.distance();
    }

    @Override
    public List<Field> children() {
        return List.of(field);
    }
}
