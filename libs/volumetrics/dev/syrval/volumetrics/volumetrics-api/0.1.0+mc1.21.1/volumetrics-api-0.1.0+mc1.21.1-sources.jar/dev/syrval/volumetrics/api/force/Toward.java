package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.field.Field;

/**
 * A sideways pull towards the upright line through the attachment, at {@code speed} blocks per second, slowing to
 * nothing over the last {@code taper} blocks so the gas comes to rest there: a draught down a hole. Negative speed
 * pushes away from the line. {@code {"type": "volumetrics:toward", "speed": 2, "shape": {...}, "reach": 8}}.
 */
public record Toward(float speed, Field shape, float reach, float taper) implements ForceKind {
    private static final Limits SPEED = Limits.speed("toward.speed");
    private static final Limits TAPER = Limits.distance("toward.taper", 64f);

    public static final MapCodec<Toward> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            SPEED.codec().fieldOf("speed").forGetter(Toward::speed),
            Field.CODEC.fieldOf("shape").forGetter(Toward::shape),
            Region.reach("toward").optionalFieldOf("reach", 0f).forGetter(Toward::reach),
            TAPER.codec().optionalFieldOf("taper", 4f).forGetter(Toward::taper)
    ).apply(instance, Toward::new));

    public Toward {
        SPEED.check(speed);
        Region.shape(shape, "toward");
        Region.reach(reach, "toward");
        TAPER.check(taper);
    }

    @Override
    public ForceType type() {
        return ForceKinds.TOWARD;
    }
}
