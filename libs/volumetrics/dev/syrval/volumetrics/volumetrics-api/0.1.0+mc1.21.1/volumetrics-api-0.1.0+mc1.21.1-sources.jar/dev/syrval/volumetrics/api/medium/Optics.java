package dev.syrval.volumetrics.api.medium;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import java.util.Objects;

/**
 * How a medium's gas meets light, in the physical terms engines and shader packs use for participating media. The
 * {@code optics} object of a medium file.
 *
 * @param extinction how much light the gas stops, per block at density 1: light through {@code n} blocks of gas at
 *                   density {@code d} is dimmed to {@code exp(-extinction * d * n)}
 * @param albedo     the share of each colour of stopped light the gas scatters rather than swallows, {@code 0xRRGGBB}:
 *                   the colour it shows where it is lit; written {@code "#RRGGBB"}
 * @param phase      which way it scatters the light
 * @param emission   light of its own
 * @param ambient    how strongly daylight (the sky and the sun) lights it: 1 as it lights a block, 0 to 4
 * @param lamps      how strongly light sources (torches, lamps, lava) light it: 1 as they light a block, 0 to 4
 */
public record Optics(float extinction, int albedo, Phase phase, Emission emission, float ambient, float lamps) {
    public static final Codec<Optics> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ranges.EXTINCTION.codec().fieldOf("extinction").forGetter(Optics::extinction),
            VolumetricsCodecs.RGB.fieldOf("albedo").forGetter(Optics::albedo),
            Phase.CODEC.optionalFieldOf("phase", Phase.DEFAULT).forGetter(Optics::phase),
            Emission.CODEC.optionalFieldOf("emission", Emission.NONE).forGetter(Optics::emission),
            Ranges.AMBIENT.codec().optionalFieldOf("ambient", 1f).forGetter(Optics::ambient),
            Ranges.LAMPS.codec().optionalFieldOf("lamps", 1f).forGetter(Optics::lamps)
    ).apply(instance, Optics::new));

    public Optics {
        Ranges.EXTINCTION.check(extinction);
        VolumetricsCodecs.requireRgb(albedo, "optics.albedo");
        Objects.requireNonNull(phase, "phase");
        Objects.requireNonNull(emission, "emission");
        Ranges.AMBIENT.check(ambient);
        Ranges.LAMPS.check(lamps);
    }

    /** Gas of this extinction and albedo, lit as blocks are, with the default phase and no light of its own. */
    public Optics(float extinction, int albedo) {
        this(extinction, albedo, Phase.DEFAULT, Emission.NONE, 1f, 1f);
    }

    public Optics withPhase(Phase phase) {
        return new Optics(extinction, albedo, phase, emission, ambient, lamps);
    }

    public Optics withEmission(Emission emission) {
        return new Optics(extinction, albedo, phase, emission, ambient, lamps);
    }

    /** The same lit {@code ambient} as strongly by daylight and {@code lamps} as strongly by light sources. */
    public Optics withLight(float ambient, float lamps) {
        return new Optics(extinction, albedo, phase, emission, ambient, lamps);
    }
}
