package dev.syrval.volumetrics.api.force;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;

/**
 * Every kind of force, by the {@code type} it is written with:
 * <ul>
 *   <li>{@code volumetrics:level_wind} ({@link LevelWind}): the level's wind, from server code; several add.</li>
 *   <li>{@code volumetrics:uniform} ({@link Uniform}): one velocity over a shape.</li>
 *   <li>{@code volumetrics:toward} ({@link Toward}): a sideways pull to an upright line.</li>
 *   <li>{@code volumetrics:radial} ({@link Radial}): a push out of or a pull into a point.</li>
 *   <li>{@code volumetrics:vortex} ({@link Vortex}): a swirl about an upright line, with inflow and lift.</li>
 *   <li>{@code volumetrics:fan} ({@link Fan}): a cone of moving air; negative speed draws air in.</li>
 *   <li>{@code volumetrics:gusts} ({@link Gusts}): turbulence that changes from moment to moment.</li>
 * </ul>
 * A closed set, the same on both sides; a code tier ({@code ForceProvider}) is planned beside it.
 */
public final class ForceKinds {
    private static final Map<ResourceLocation, ForceType> TYPES = new LinkedHashMap<>();

    public static final ForceType LEVEL_WIND = add("level_wind", LevelWind.MAP_CODEC);
    public static final ForceType UNIFORM = add("uniform", Uniform.MAP_CODEC);
    public static final ForceType TOWARD = add("toward", Toward.MAP_CODEC);
    public static final ForceType RADIAL = add("radial", Radial.MAP_CODEC);
    public static final ForceType VORTEX = add("vortex", Vortex.MAP_CODEC);
    public static final ForceType FAN = add("fan", Fan.MAP_CODEC);
    public static final ForceType GUSTS = add("gusts", Gusts.MAP_CODEC);

    private static final Codec<ForceType> TYPE_CODEC = ResourceLocation.CODEC.comapFlatMap(ForceKinds::get, ForceType::id);

    /** A kind's object, by its {@code type}, as fields beside others (a force's {@code media}). */
    static final MapCodec<ForceKind> MAP_CODEC = TYPE_CODEC.dispatchMap("type", ForceKind::type, ForceType::codec);

    private ForceKinds() {}

    public static Collection<ForceType> all() {
        return Collections.unmodifiableCollection(TYPES.values());
    }

    private static DataResult<ForceType> get(ResourceLocation id) {
        ForceType type = TYPES.get(id);
        return type != null ? DataResult.success(type) : DataResult.error(() -> "Not a kind of force: " + id);
    }

    private static ForceType add(String name, MapCodec<? extends ForceKind> codec) {
        ForceType type = new ForceType(ResourceLocation.fromNamespaceAndPath("volumetrics", name), codec);
        TYPES.put(type.id(), type);
        return type;
    }
}
