package dev.syrval.volumetrics.api.field;

import com.mojang.serialization.MapCodec;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import java.util.Objects;
import net.minecraft.resources.ResourceKey;

/**
 * A named field of the {@link VolumetricsRegistries#FIELD} registry, looked up when the engine compiles the field that
 * names it: {@code {"type": "volumetrics:ref", "id": "mymod:valley_fog"}}, or the id alone wherever a field is
 * written. A datapack that changes the named field changes every field naming it. A missing id, or fields that name
 * one another round in a circle, fail the compile of the field that names them (logged).
 *
 * <p>States nothing of itself ({@link FieldBounds#EVERYWHERE}, any value) until looked up.
 */
public record Ref(ResourceKey<Field> id) implements Field {
    public static final MapCodec<Ref> MAP_CODEC = ResourceKey.codec(VolumetricsRegistries.FIELD).fieldOf("id")
            .xmap(Ref::new, Ref::id);

    public Ref {
        Objects.requireNonNull(id, "ref.id");
    }

    @Override
    public FieldType type() {
        return FieldTypes.REF;
    }

    @Override
    public FieldBounds bounds() {
        return FieldBounds.EVERYWHERE;
    }

    @Override
    public float minimum() {
        return Float.NEGATIVE_INFINITY;
    }

    @Override
    public float maximum() {
        return Float.POSITIVE_INFINITY;
    }
}
