package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.Codec;

/**
 * Where data places a source or a force: at everything a rule finds, each with the {@link Attachment} the rule makes
 * for it. A rule is evaluated where its information is (spec section 3): block rules on each client, as it reads the
 * world round the camera, so they cost the server nothing and send nothing.
 *
 * <p>Written as an object whose {@code type} names the rule; {@link PlacementRules} lists them. Entity and structure
 * rules ({@code volumetrics:entity}, {@code volumetrics:structure}) are reserved for a later step. A mod's code places
 * what data cannot say through the code tier's {@link dev.syrval.volumetrics.api.extend.PlacementRule}.
 */
public interface PlacementRule {
    Codec<PlacementRule> CODEC = Codec.lazyInitialized(PlacementRules::codec);

    RuleType type();
}
