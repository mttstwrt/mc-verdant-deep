package dev.syrval.volumetrics.api.placement;

import com.mojang.serialization.Codec;

/**
 * Where data places a source, a force or a field: at everything a rule finds, each with the {@link Attachment} the
 * rule makes for it. A rule is evaluated where its information is (spec section 3): block rules ({@link BlockRule}) and
 * entity rules ({@link EntityRule}) on each client, as it reads the world round the camera and as entities come into
 * it, so they cost the server nothing and send nothing; structure rules ({@link StructureRule}) on the server, which
 * alone knows where structures are, and which sends what they place to the players near it.
 *
 * <p>Written as an object whose {@code type} names the rule; {@link PlacementRules} lists them. A field is placed by
 * an entity or a structure rule, not at every block ({@link dev.syrval.volumetrics.api.field.FieldPlacement}). A mod's
 * code places what data cannot say through the code tier's {@link dev.syrval.volumetrics.api.extend.PlacementRule}.
 */
public interface PlacementRule {
    Codec<PlacementRule> CODEC = Codec.lazyInitialized(PlacementRules::codec);

    RuleType type();
}
