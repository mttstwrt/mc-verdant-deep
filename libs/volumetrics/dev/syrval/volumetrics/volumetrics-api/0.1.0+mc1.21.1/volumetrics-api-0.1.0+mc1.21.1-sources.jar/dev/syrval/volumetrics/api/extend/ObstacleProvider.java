package dev.syrval.volumetrics.api.extend;

import dev.syrval.volumetrics.api.Experimental;
import java.util.List;
import java.util.Objects;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionfc;

/**
 * Moving solids the engine does not see as terrain (Sable's sub-levels, Create's contraptions): each step, the solids
 * in a region, as boxes or voxel sets with where they are and how fast they go. They keep gas out and push it as
 * moving terrain. Reserved for the engine's step 5 (VOL-055, VOL-085): nothing calls providers yet, and how they are
 * registered is not settled.
 *
 * <p>Called on the simulation thread from a snapshot view (clients, for cosmetic media) and on the server (gameplay
 * media), never from the game's own thread: a provider reads only state it has made safe to read there.
 */
@Experimental
@FunctionalInterface
public interface ObstacleProvider {
    /**
     * @param region  where the engine simulates, in world blocks
     * @param seconds the simulation time of the step
     * @return the solids in or touching the region; empty for none
     */
    List<Obstacle> obstacles(AABB region, double seconds);

    /** A moving solid. */
    sealed interface Obstacle permits OrientedBox, Voxels {}

    /**
     * A box turned about its centre.
     *
     * @param halfExtents half its size along its own axes, in blocks
     * @param velocity    blocks per second
     */
    record OrientedBox(Vec3 centre, Vec3 halfExtents, Quaternionfc rotation, Vec3 velocity) implements Obstacle {
        public OrientedBox {
            Objects.requireNonNull(centre, "centre");
            Objects.requireNonNull(halfExtents, "halfExtents");
            Objects.requireNonNull(rotation, "rotation");
            Objects.requireNonNull(velocity, "velocity");
        }
    }

    /**
     * Solid unit voxels in a frame of their own, placed by turning about {@code origin} and moving there.
     *
     * @param voxels   x, y, z of each solid voxel in the frame, three ints each
     * @param velocity blocks per second of the frame's origin
     */
    record Voxels(Vec3 origin, Quaternionfc rotation, int[] voxels, Vec3 velocity) implements Obstacle {
        public Voxels {
            Objects.requireNonNull(origin, "origin");
            Objects.requireNonNull(rotation, "rotation");
            Objects.requireNonNull(voxels, "voxels");
            if (voxels.length % 3 != 0) {
                throw new IllegalArgumentException("Voxels come three ints each, got " + voxels.length);
            }
            Objects.requireNonNull(velocity, "velocity");
        }
    }
}
