package dev.syrval.volumetrics.api.source;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.api.Importance;
import dev.syrval.volumetrics.api.VolumetricsCodecs;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.field.Field;
import dev.syrval.volumetrics.api.medium.Medium;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.Vec3;

/**
 * Gas fed into the simulation: a medium given off over a shape, at a rate, when its schedule and conditions say.
 *
 * <pre>{@code
 * {
 *   "medium": "verdant_deep:steam",
 *   "shape": { "type": "volumetrics:cylinder", "radius": 3, "height": 1 },
 *   "rate": 0.4,
 *   "velocity": { "y": 1.5 },
 *   "schedule": { "type": "volumetrics:pulse", "on": 2, "off": 6 },
 *   "conditions": "verdant_deep:warm"
 * }
 * }</pre>
 *
 * <ul>
 *   <li>{@code shape} is any field ({@link Field}), written relative to the attachment: a shape (a signed distance)
 *   feeds what is inside it; any other field feeds each point by its value, from 0 to 1 (so {@code inside} with an
 *   edge gives a soft rim, a noise a patchy vent). It must be bounded, and no more than {@value #MAX_EXTENT} blocks
 *   across on any axis.</li>
 *   <li>{@code rate}: density gained each second where the shape is 1, up to the most a cell holds. Or {@code flow}:
 *   the total, in blocks of pure gas a second, spread over the shape (rate = flow / the shape's volume).</li>
 *   <li>{@code velocity}: the push the gas leaves with (a chimney, a breath), in blocks per second in the
 *   attachment's frame: a force on this source's own gas over its shape, reaching {@value #JET_REACH} blocks beyond
 *   it, there while the source gives off gas.</li>
 *   <li>{@code schedule}: when ({@link Schedule}); always unless written.</li>
 *   <li>{@code conditions}: ids of conditions (one, or a list), whose values at the source's column (0 to 1) multiply
 *   its rate. An id no mod registered counts as 1.</li>
 *   <li>{@code importance}: whose medium keeps a kind of gas near the camera when there are more than the engine
 *   holds.</li>
 * </ul>
 *
 * <p>A shape too small to catch any of the points the simulation tests feeds the cell it is in, as if it caught one.
 * Data places sources with {@link SourcePlacement}; code (from VOL-082 1e) with an owner and an attachment.
 */
public record Source(ResourceKey<Medium> medium, Field shape, Amount amount, Vec3 velocity, Schedule schedule,
                     List<ResourceLocation> conditions, Importance importance) {
    /** The most a source's shape may span on any axis, in blocks. */
    public static final int MAX_EXTENT = 256;
    /** How far beyond its shape a source's velocity pushes, in blocks. */
    public static final float JET_REACH = 2f;

    private static final Codec<List<ResourceLocation>> CONDITIONS = Codec.either(ResourceLocation.CODEC, ResourceLocation.CODEC.listOf())
            .xmap(either -> either.map(List::of, list -> list),
                    list -> list.size() == 1 ? Either.left(list.getFirst()) : Either.right(list));

    private static final Codec<Vec3> VELOCITY = VolumetricsCodecs.XYZ.validate(Source::checkVelocity);

    public static final MapCodec<Source> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).fieldOf("medium").forGetter(Source::medium),
            Field.CODEC.fieldOf("shape").forGetter(Source::shape),
            Amount.MAP_CODEC.forGetter(Source::amount),
            VELOCITY.optionalFieldOf("velocity", Vec3.ZERO).forGetter(Source::velocity),
            Schedule.CODEC.optionalFieldOf("schedule", Schedule.ALWAYS).forGetter(Source::schedule),
            CONDITIONS.optionalFieldOf("conditions", List.of()).forGetter(Source::conditions),
            Importance.CODEC.optionalFieldOf("importance", Importance.NORMAL).forGetter(Source::importance)
    ).apply(instance, Source::new));

    public static final Codec<Source> CODEC = MAP_CODEC.codec();

    public Source {
        Objects.requireNonNull(medium, "medium");
        Objects.requireNonNull(shape, "shape");
        Objects.requireNonNull(amount, "amount");
        Objects.requireNonNull(velocity, "velocity");
        if (!(velocity.length() <= Limits.SPEED.max())) {
            throw new IllegalArgumentException("source.velocity must be at most " + Limits.SPEED.max() + " blocks per second, got "
                    + velocity.length());
        }
        Objects.requireNonNull(schedule, "schedule");
        conditions = List.copyOf(conditions);
        Objects.requireNonNull(importance, "importance");
    }

    /** Always on, with no push, conditions or importance of its own. */
    public static Source of(ResourceKey<Medium> medium, Field shape, Amount amount) {
        return new Source(medium, shape, amount, Vec3.ZERO, Schedule.ALWAYS, List.of(), Importance.NORMAL);
    }

    public Source withVelocity(Vec3 velocity) {
        return new Source(medium, shape, amount, velocity, schedule, conditions, importance);
    }

    public Source withSchedule(Schedule schedule) {
        return new Source(medium, shape, amount, velocity, schedule, conditions, importance);
    }

    public Source withConditions(List<ResourceLocation> conditions) {
        return new Source(medium, shape, amount, velocity, schedule, conditions, importance);
    }

    public Source withImportance(Importance importance) {
        return new Source(medium, shape, amount, velocity, schedule, conditions, importance);
    }

    private static DataResult<Vec3> checkVelocity(Vec3 velocity) {
        double length = velocity.length();
        return length <= Limits.SPEED.max() ? DataResult.success(velocity)
                : DataResult.error(() -> "source.velocity must be at most " + Limits.SPEED.max() + " blocks per second, got " + length);
    }

    /**
     * How much gas: a {@link Rate} over the shape, or a {@link Flow} in total. Written as {@code "rate"} or
     * {@code "flow"} beside the source's other fields, one of the two.
     */
    public sealed interface Amount permits Rate, Flow {
        MapCodec<Amount> MAP_CODEC = Codec.mapPair(
                Limits.RATE.codec().optionalFieldOf("rate"),
                Limits.FLOW.codec().optionalFieldOf("flow")
        ).flatXmap(Amount::read, Amount::write);

        private static DataResult<Amount> read(Pair<Optional<Float>, Optional<Float>> written) {
            Optional<Float> rate = written.getFirst();
            Optional<Float> flow = written.getSecond();
            if (rate.isPresent() == flow.isPresent()) {
                return DataResult.error(() -> "A source needs a rate or a flow, one of the two");
            }
            return DataResult.success(rate.isPresent() ? new Rate(rate.get()) : new Flow(flow.get()));
        }

        private static DataResult<Pair<Optional<Float>, Optional<Float>>> write(Amount amount) {
            return DataResult.success(switch (amount) {
                case Rate rate -> Pair.<Optional<Float>, Optional<Float>>of(Optional.of(rate.density()), Optional.empty());
                case Flow flow -> Pair.<Optional<Float>, Optional<Float>>of(Optional.empty(), Optional.of(flow.blocks()));
            });
        }
    }

    /** Density gained each second where the shape is 1, 0 to 64. */
    public record Rate(float density) implements Amount {
        public Rate {
            Limits.RATE.check(density);
        }
    }

    /** Blocks of pure gas a second in all, 0 to 65536, spread over the shape's volume. */
    public record Flow(float blocks) implements Amount {
        public Flow {
            Limits.FLOW.check(blocks);
        }
    }
}
